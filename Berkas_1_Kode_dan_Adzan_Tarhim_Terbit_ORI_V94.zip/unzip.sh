#!/bin/bash
# Skrip Ekstrak Otomatis (Unzip) & Penghubung 23 Audio Nidaul Masjid Pro V62
for z in *.zip *.ppk; do
  if [ -f "$z" ]; then
    unzip -o "$z" -d . || true
  fi
done
mkdir -p app/src/main/assets/audio/murottal
cp -f index.html style.css app.js manifest.json sw.js config.json app/src/main/assets/ || true
if [ -d "audio" ]; then
  cp -rf audio/* app/src/main/assets/audio/ || true
fi
