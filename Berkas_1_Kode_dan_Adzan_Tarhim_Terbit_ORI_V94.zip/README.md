# Nurul Masjid Pro — Versi 8.0 (versionCode 80)
**Pengembang Resmi:** Nur & Mas Yeni Setiawan

## Catatan Perubahan Versi 8.0 (Gabungan Penuh Perbaikan V7.9 + 23 Audio Asli Tertanam)
1. **Menu Tentang Aplikasi, Lisensi Resmi & Traktir Pengembang Terbaca Sempurna**:
   - Menghapus `aria-hidden="true"` yang sebelumnya membuat kartu terbaca kosong oleh TalkBack/Jieshuo.
   - Setiap judul (`<h2>`) dan paragraf (`<p>`) kini merupakan elemen nyata yang dapat difokuskan (`tabindex="0"`) dan dibaca satu per satu.
2. **Menu Traktir Pengembang (GoPay Tanpa Menampilkan Nomor di Layar)**:
   - Nomor GoPay tidak ditampilkan di layar maupun di label tombol (baik di Beranda, Tentang Aplikasi, maupun Menu Traktir).
   - Hanya berisi 2 tombol aksi (**Buka Aplikasi GoPay** dan **Salin Nomor GoPay**) ditambah tombol Kembali.
   - Dilengkapi blok `<queries>` pada `AndroidManifest.xml` untuk Android 11+ (membuka aplikasi GoPay -> fallback Gojek -> fallback Play Store dan mengumumkan hasilnya lewat suara, sembari menyalin nomor tujuan secara otomatis ke papan klip).
3. **Perbaikan Total Layanan Latar Belakang 24 Jam (`MasjidForegroundService` & `BootCompletedReceiver`)**:
   - `MainActivity.onDestroy()` kini mengosongkan `MainActivity.instance = null` sehingga saat aplikasi digeser dari *Recent Apps*, `MasjidForegroundService` langsung mengambil alih penuh kumandang Adzan dan Doa Setelah Adzan di latar belakang.
   - Menghapus tipe service `location` pada `AndroidManifest.xml` (cukup `mediaPlayback`) agar bebas risiko crash izin lokasi di Android 14.
   - Melepaskan `wakeLock` dan `bgPlayer` dengan bersih saat service berhenti serta menggunakan `PendingIntent.getForegroundService` untuk restart otomatis di Android 8 ke atas.
4. **Lengkap 23 Berkas Audio Asli Tertanam di `app/src/main/assets/audio/`**:
   - Termasuk `audio/doa_adzan.mp3` (Doa Setelah Adzan — Syekh Saad Al-Ghamidi) dan `audio/asmaul_husna.mp3` (Asmaul Husna — Hijjaz), 5 Murottal waktu salat, Surah Yasin, Surah Al-Jumu'ah, Ya Arhamarrohimin, Tarhim, Adzan, Bel, dan Iqomah.
