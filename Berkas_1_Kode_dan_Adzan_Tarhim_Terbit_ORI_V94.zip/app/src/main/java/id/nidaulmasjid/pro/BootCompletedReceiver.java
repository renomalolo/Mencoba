package id.nidaulmasjid.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootCompletedReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            try {
                Intent srv = new Intent(context, MasjidForegroundService.class);
                srv.putExtra("title", "Nurul Masjid Pro • Jam Masjid Aktif");
                srv.putExtra("text", "Siaga menjaga jadwal salat & adzan 24 jam di latar belakang");
                if (Build.VERSION.SDK_INT >= 26) {
                    context.startForegroundService(srv);
                } else {
                    context.startService(srv);
                }
            } catch (Exception ignored) {}
        }
    }
}
