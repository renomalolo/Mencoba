package id.nidaulmasjid.pro;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.Vibrator;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.KeyEvent;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    public static MainActivity instance;
    public boolean isActivityForeground = false;
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private MediaPlayer mediaPlayer;
    private MediaPlayer bellPlayer;
    private MediaPlayer geminiTtsPlayer;
    private Dialog popupHentikanDialog;
    private float currentMainVolume = 1.0f;
    private SensorManager sensorManager;
    private SensorEventListener compassListener;
    private ValueCallback<Uri[]> filePathCallback;
    private int savedNotifVolume = -1;
    private File audioCacheRoot;
    private static final int FILE_CHOOSER_REQ = 1001;
    private static final int PERMISSION_REQ_CODE = 2002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        audioCacheRoot = new File(getCacheDir(), "nidaul_audio_fastcache");
        try {
            if (audioCacheRoot.exists() && audioCacheRoot.isDirectory()) {
                File[] oldFiles = audioCacheRoot.listFiles();
                if (oldFiles != null) {
                    for (File f : oldFiles) {
                        f.delete();
                    }
                }
            }
        } catch (Exception ignored) {}

        try {
            String existingCfg = bacaConfigPermanenNative();
            if (existingCfg == null || existingCfg.isEmpty()) {
                SharedPreferences spInit = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
                spInit.edit().putString("config_json", "{\"master_aktif\":false,\"kota\":\"\",\"volAdzan\":85,\"volMurottal\":75,\"autoVolume\":false}").commit();
            }
        } catch (Exception ignored) {}
        mulaiLayananLatar("Nurul Masjid Pro • Jam Masjid Aktif", "Siaga menjaga jadwal salat & adzan 24 jam");

        tts = new TextToSpeech(getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("id", "ID"));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String utteranceId) {
                    }

                    @Override
                    public void onDone(String utteranceId) {
                        selesaikanBicaraTTS();
                    }

                    @Override
                    public void onError(String utteranceId) {
                        selesaikanBicaraTTS();
                    }
                });
                ttsReady = true;
            }
        });

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        webView = new WebView(this);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setGeolocationEnabled(true);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                try {
                    view.evaluateJavascript("if(window.pulihkanConfigDariNativeJikaPerlu) window.pulihkanConfigDariNativeJikaPerlu();", null);
                } catch (Exception ignored) {}
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/") || url.startsWith("whatsapp://") || url.startsWith("https://aistudio.google.com"))) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception ignored) {}
                    return true;
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            @Override
            public boolean onShowFileChooser(WebView vw, ValueCallback<Uri[]> filePathCb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = filePathCb;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("audio/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(intent, "Pilih Berkas Audio Masjid"), FILE_CHOOSER_REQ);
                return true;
            }
        });

        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        mintaSemuaPerizinanLengkap(false);
        periksaIntentPopupHentikan(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        periksaIntentPopupHentikan(intent);
    }

    private int dpKePx(int val) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                val,
                getResources().getDisplayMetrics()
        );
    }

    private void periksaIntentPopupHentikan(Intent intent) {
        try {
            if (intent != null && intent.getBooleanExtra("popup_hentikan_suara", false)) {
                String judul = intent.getStringExtra("judul_siaran");
                boolean simulasi = intent.getBooleanExtra("simulasi_uji", false);
                intent.removeExtra("popup_hentikan_suara");
                if (judul == null || judul.trim().isEmpty()) {
                    judul = "Siaran Jadwal Masjid";
                }
                tampilkanDialogPopupHentikanSuara(judul, !simulasi);
            }
        } catch (Exception ignored) {}
    }

    public void tutupDialogPopupHentikanSuara() {
        runOnUiThread(() -> {
            try {
                if (popupHentikanDialog != null && popupHentikanDialog.isShowing()) {
                    popupHentikanDialog.dismiss();
                }
                popupHentikanDialog = null;
            } catch (Exception ignored) {}
        });
    }

    public void tampilkanDialogPopupHentikanSuara(String judulSiaran, boolean kembaliKeLatarSaatTutup) {
        runOnUiThread(() -> {
            try {
                if (Build.VERSION.SDK_INT >= 27) {
                    setShowWhenLocked(true);
                    setTurnScreenOn(true);
                    // Jangan panggil requestDismissKeyguard agar tombol besar HENTIKAN SUARA langsung tampil di atas layar kunci tanpa terhalang PIN/Pola
                }
                getWindow().addFlags(
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                );

                if (popupHentikanDialog != null && popupHentikanDialog.isShowing()) {
                    popupHentikanDialog.dismiss();
                }

                popupHentikanDialog = new Dialog(MainActivity.this);
                popupHentikanDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                popupHentikanDialog.setCancelable(true);

                LinearLayout card = new LinearLayout(MainActivity.this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dpKePx(22), dpKePx(24), dpKePx(22), dpKePx(24));
                GradientDrawable cardBg = new GradientDrawable();
                cardBg.setColor(Color.parseColor("#0B3B2E"));
                cardBg.setCornerRadius(dpKePx(24));
                cardBg.setStroke(dpKePx(3), Color.parseColor("#FBBF24"));
                card.setBackground(cardBg);

                TextView tvHeader = new TextView(MainActivity.this);
                tvHeader.setText("JENDELA POP-UP NURUL MASJID PRO");
                tvHeader.setTextColor(Color.parseColor("#FDE68A"));
                tvHeader.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                tvHeader.setTypeface(Typeface.DEFAULT_BOLD);
                tvHeader.setGravity(Gravity.CENTER);
                tvHeader.setFocusable(true);
                card.addView(tvHeader);

                TextView tvInfo = new TextView(MainActivity.this);
                tvInfo.setText("SEDANG BERBUNYI:\n" + judulSiaran);
                tvInfo.setTextColor(Color.WHITE);
                tvInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
                tvInfo.setTypeface(Typeface.DEFAULT_BOLD);
                tvInfo.setGravity(Gravity.CENTER);
                tvInfo.setPadding(0, dpKePx(12), 0, dpKePx(18));
                tvInfo.setFocusable(true);
                tvInfo.setContentDescription("Jendela Pop Up Nurul Masjid Pro. Saat ini sedang berbunyi: " + judulSiaran + ". Ketuk tombol besar di bawah untuk menghentikan suara ini saja tanpa mematikan mesin jadwal latar belakang.");
                card.addView(tvInfo);

                Button btnStopBig = new Button(MainActivity.this);
                btnStopBig.setText("HENTIKAN SUARA SEKARANG\n(Jadwal Latar Belakang Tetap Aktif 24 Jam)");
                btnStopBig.setTextColor(Color.WHITE);
                btnStopBig.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                btnStopBig.setTypeface(Typeface.DEFAULT_BOLD);
                btnStopBig.setAllCaps(false);
                btnStopBig.setPadding(dpKePx(16), dpKePx(22), dpKePx(16), dpKePx(22));
                GradientDrawable stopBg = new GradientDrawable();
                stopBg.setColor(Color.parseColor("#DC2626"));
                stopBg.setCornerRadius(dpKePx(18));
                stopBg.setStroke(dpKePx(2), Color.WHITE);
                btnStopBig.setBackground(stopBg);
                btnStopBig.setContentDescription("Tombol Besar: Hentikan Suara Sekarang. Hanya menghentikan suara yang sedang berbunyi saat ini, sedangkan aktivitas jadwal latar belakang 24 jam tetap berjalan normal.");

                LinearLayout.LayoutParams lpStop = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                lpStop.bottomMargin = dpKePx(14);
                btnStopBig.setLayoutParams(lpStop);

                btnStopBig.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            if (MasjidForegroundService.instance != null) {
                                MasjidForegroundService.instance.hentikanSemuaSuaraDariLuarApk(true);
                            } else {
                                hentikanAudioDariLuarApk();
                            }
                            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                            if (nm != null) nm.cancel(5202);
                            if (popupHentikanDialog != null && popupHentikanDialog.isShowing()) {
                                popupHentikanDialog.dismiss();
                            }
                            if (kembaliKeLatarSaatTutup) {
                                moveTaskToBack(true);
                            }
                        } catch (Exception ignored) {}
                    }
                });
                card.addView(btnStopBig);

                Button btnKeep = new Button(MainActivity.this);
                btnKeep.setText("Biarkan Tetap Berbunyi & Tutup Pop-Up Ini");
                btnKeep.setTextColor(Color.parseColor("#ECFDF5"));
                btnKeep.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
                btnKeep.setTypeface(Typeface.DEFAULT_BOLD);
                btnKeep.setAllCaps(false);
                btnKeep.setPadding(dpKePx(14), dpKePx(16), dpKePx(14), dpKePx(16));
                GradientDrawable keepBg = new GradientDrawable();
                keepBg.setColor(Color.parseColor("#047857"));
                keepBg.setCornerRadius(dpKePx(14));
                btnKeep.setBackground(keepBg);
                btnKeep.setContentDescription("Biarkan suara tetap berbunyi dan tutup jendela pop up ini.");

                LinearLayout.LayoutParams lpKeep = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );
                btnKeep.setLayoutParams(lpKeep);
                btnKeep.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                            if (nm != null) nm.cancel(5202);
                            if (popupHentikanDialog != null && popupHentikanDialog.isShowing()) {
                                popupHentikanDialog.dismiss();
                            }
                            if (kembaliKeLatarSaatTutup) {
                                moveTaskToBack(true);
                            }
                        } catch (Exception ignored) {}
                    }
                });
                card.addView(btnKeep);

                popupHentikanDialog.setContentView(card);
                if (popupHentikanDialog.getWindow() != null) {
                    popupHentikanDialog.getWindow().addFlags(
                            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                            | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                            | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                    );
                    popupHentikanDialog.getWindow().setLayout(
                            WindowManager.LayoutParams.MATCH_PARENT,
                            WindowManager.LayoutParams.WRAP_CONTENT
                    );
                }
                popupHentikanDialog.show();

                btnStopBig.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            btnStopBig.requestFocus();
                            btnStopBig.sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_FOCUSED);
                        } catch (Exception ignored) {}
                    }
                }, 250);
            } catch (Exception ignored) {}
        });
    }


    private void selesaikanBicaraTTS() {
        runOnUiThread(() -> {
            try {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.setVolume(currentMainVolume, currentMainVolume);
                }
                if (webView != null) {
                    webView.evaluateJavascript("if(window.onNativeTTSFinished) window.onNativeTTSFinished();", null);
                }
            } catch (Exception ignored) {}
        });
    }

    private void siapkanPreCacheAudio() {
        String[] daftarAsset = new String[]{
                "audio/bel_pendek.mp3",
                "audio/bumper.mp3",
                "audio/iqomah.mp3",
                "audio/asmaul_husna.mp3",
                "audio/doa_adzan.mp3",
                "audio/tarhim.ogg",
                "audio/Tarhim Mahmud Al Hussary.ogg",
                "audio/Arhamarrohimin Tarhim.ogg",
                "audio/adzan.ogg",
                "audio/adzan_subuh.ogg",
                "audio/Azan Sbh Syahdu.ogg",
                "audio/Ajan Masjid Kampung.ogg",
                "audio/aljumuah.ogg",
                "audio/yasin.ogg",
                "audio/dhuha.ogg",
                "audio/peringatan terbit.mp3",
                "audio/timer_terbit.mp3",
                "audio/sirine_terbit.mp3",
                "audio/ya_muhaimin_ya_salam.mp3",
                "audio/terbit.mp3",
                "audio/tahajud.mp3",
                "audio/murottal/adzan_makkah_standar.mp3",
                "audio/murottal/subuh-01.ogg",
                "audio/murottal/dzuhur-01.ogg",
                "audio/murottal/ashar-01.ogg",
                "audio/murottal/maghrib-01.ogg",
                "audio/murottal/isya-01.ogg"
        };
        for (String rel : daftarAsset) {
            try {
                String safeName = rel.replace("/", "_").replace(" ", "_");
                File outF = new File(audioCacheRoot, safeName);
                if (outF.exists() && outF.length() > 1024) continue;
                InputStream is = getAssets().open(rel);
                FileOutputStream fos = new FileOutputStream(outF);
                byte[] buf = new byte[16384];
                int r;
                while ((r = is.read(buf)) != -1) {
                    fos.write(buf, 0, r);
                }
                fos.flush();
                fos.close();
                is.close();
            } catch (Exception ignored) {}
        }
    }

    public void mintaSemuaPerizinanLengkap(boolean paksaDialogBaterai) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                List<String> listIzin = new ArrayList<>();
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    listIzin.add(Manifest.permission.ACCESS_FINE_LOCATION);
                }
                if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    listIzin.add(Manifest.permission.ACCESS_COARSE_LOCATION);
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    if (checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                        listIzin.add("android.permission.POST_NOTIFICATIONS");
                    }
                    if (checkSelfPermission("android.permission.READ_MEDIA_AUDIO") != PackageManager.PERMISSION_GRANTED) {
                        listIzin.add("android.permission.READ_MEDIA_AUDIO");
                    }
                } else {
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        listIzin.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                    }
                }
                if (!listIzin.isEmpty()) {
                    requestPermissions(listIzin.toArray(new String[0]), PERMISSION_REQ_CODE);
                }

                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null && (!pm.isIgnoringBatteryOptimizations(getPackageName()) || paksaDialogBaterai)) {
                    try {
                        Intent intentBat = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                        intentBat.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intentBat);
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        isActivityForeground = true;
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
        }
    }

    @Override
    protected void onPause() {
        isActivityForeground = false;
        mulaiLayananLatar("Nurul Masjid Pro • Jam Masjid Aktif", "Siaga menjaga jadwal salat & adzan 24 jam");
        super.onPause();
        if (webView != null) {
            webView.resumeTimers();
        }
    }

    @Override
    protected void onStop() {
        isActivityForeground = false;
        mulaiLayananLatar("Nurul Masjid Pro • Jam Masjid Aktif", "Siaga menjaga jadwal salat & adzan 24 jam");
        super.onStop();
        if (webView != null) {
            webView.resumeTimers();
        }
    }

    @Override
    protected void onDestroy() {
        isActivityForeground = false;
        mulaiLayananLatar("Nurul Masjid Pro • Jam Masjid Aktif", "Siaga menjaga jadwal salat & adzan 24 jam");
        if (instance == this) {
            instance = null;
        }
        try {
            if (webView != null) {
                webView.stopLoading();
                webView.removeAllViews();
                webView.destroy();
                webView = null;
            }
        } catch (Exception ignored) {}
        try {
            if (geminiTtsPlayer != null && !geminiTtsPlayer.isPlaying()) {
                geminiTtsPlayer.release();
                geminiTtsPlayer = null;
            }
            if (bellPlayer != null && !bellPlayer.isPlaying()) {
                bellPlayer.release();
                bellPlayer = null;
            }
            if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
                mediaPlayer.release();
                mediaPlayer = null;
            }
            if (tts != null && !tts.isSpeaking()) {
                tts.shutdown();
                tts = null;
            }
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    public void picuDetakJadwalDariService() {
        runOnUiThread(() -> {
            try {
                if (webView != null) {
                    webView.resumeTimers();
                    webView.evaluateJavascript("if(window.detakMesinMasjid) window.detakMesinMasjid();", null);
                }
            } catch (Exception ignored) {}
        });
    }

    public synchronized void hentikanAudioDariLuarApk() {
        try {
            if (tts != null) {
                try { tts.stop(); } catch (Exception ignored) {}
            }
            if (geminiTtsPlayer != null) {
                try {
                    if (geminiTtsPlayer.isPlaying()) geminiTtsPlayer.stop();
                    geminiTtsPlayer.release();
                } catch (Exception ignored) {}
                geminiTtsPlayer = null;
            }
            if (bellPlayer != null) {
                try {
                    if (bellPlayer.isPlaying()) bellPlayer.stop();
                    bellPlayer.release();
                } catch (Exception ignored) {}
                bellPlayer = null;
            }
            if (mediaPlayer != null) {
                try {
                    if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                    mediaPlayer.release();
                } catch (Exception ignored) {}
                mediaPlayer = null;
            }
            runOnUiThread(() -> {
                try {
                    if (webView != null) {
                        webView.evaluateJavascript("if(window.onStoppedFromOutsideApk) window.onStoppedFromOutsideApk();", null);
                    }
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
    }

    public void hentikanAudioDariService() {
        runOnUiThread(() -> {
            try {
                if (tts != null) tts.stop();
                    if (geminiTtsPlayer != null) {
                        try {
                            if (geminiTtsPlayer.isPlaying()) geminiTtsPlayer.stop();
                            geminiTtsPlayer.release();
                        } catch (Exception ignored) {}
                        geminiTtsPlayer = null;
                    }
                if (bellPlayer != null) {
                    if (bellPlayer.isPlaying()) bellPlayer.stop();
                    bellPlayer.release();
                    bellPlayer = null;
                }
                if (mediaPlayer != null) {
                    if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
            } catch (Exception ignored) {}
        });
    }

    public boolean apakahSedangMemutarAudio() {
        try {
            return mediaPlayer != null && mediaPlayer.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            tanganiTombolKembaliHP();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        tanganiTombolKembaliHP();
    }

    private void tanganiTombolKembaliHP() {
        runOnUiThread(() -> {
            try {
                if (webView != null) {
                    webView.evaluateJavascript("if(window.onHardwareBackPressed) window.onHardwareBackPressed();", null);
                } else {
                    moveTaskToBack(true);
                }
            } catch (Exception e) {
                moveTaskToBack(true);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQ && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private boolean izinkanResetNolSementara = false;

    private boolean apakahJsonPunyaLokasiValid(String jsonStr) {
        try {
            if (jsonStr == null || jsonStr.length() < 15) return false;
            org.json.JSONObject obj = new org.json.JSONObject(jsonStr);
            double lat = obj.optDouble("latitude", 0.0);
            double lon = obj.optDouble("longitude", 0.0);
            return lat != 0.0 && lon != 0.0;
        } catch (Exception e) {
            return false;
        }
    }

    public synchronized String bacaConfigPermanenNative() {
        try {
            SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
            String spCfg = sp.getString("config_json", "");
            File permFile = new File(getFilesDir(), "nurul_config_permanent.json");
            String fileCfg = "";
            if (permFile.exists() && permFile.length() > 10) {
                FileInputStream fis = new FileInputStream(permFile);
                java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int r;
                while ((r = fis.read(buf)) != -1) {
                    baos.write(buf, 0, r);
                }
                fis.close();
                fileCfg = baos.toString("UTF-8");
            }
            boolean spPunyaLokasi = apakahJsonPunyaLokasiValid(spCfg);
            boolean filePunyaLokasi = apakahJsonPunyaLokasiValid(fileCfg);
            if (spPunyaLokasi) {
                if (!filePunyaLokasi) {
                    try {
                        FileOutputStream fos = new FileOutputStream(permFile, false);
                        fos.write(spCfg.getBytes("UTF-8"));
                        fos.flush();
                        fos.close();
                    } catch (Exception ignored) {}
                }
                return spCfg;
            }
            if (filePunyaLokasi) {
                sp.edit().putString("config_json", fileCfg).commit();
                return fileCfg;
            }
            if (spCfg != null && !spCfg.isEmpty()) return spCfg;
            if (fileCfg != null && !fileCfg.isEmpty()) return fileCfg;
        } catch (Exception ignored) {}
        return "";
    }

    public synchronized void simpanConfigPermanenNative(String jsonStr) {
        if (jsonStr == null || jsonStr.trim().isEmpty()) return;
        try {
            boolean inputKosongNol = !apakahJsonPunyaLokasiValid(jsonStr);
            if (inputKosongNol && !izinkanResetNolSementara) {
                String existing = bacaConfigPermanenNative();
                boolean existingPunyaLokasi = apakahJsonPunyaLokasiValid(existing);
                if (existingPunyaLokasi) {
                    // Jangan pernah menimpa lokasi yang sudah diatur dengan data nol/kosong!
                    return;
                }
            }
            izinkanResetNolSementara = false;
            SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
            sp.edit().putString("config_json", jsonStr).commit();
            File permFile = new File(getFilesDir(), "nurul_config_permanent.json");
            FileOutputStream fos = new FileOutputStream(permFile, false);
            fos.write(jsonStr.getBytes("UTF-8"));
            fos.flush();
            fos.close();
        } catch (Exception ignored) {}
    }

    private void mulaiLayananLatar(String title, String text) {
        try {
            Intent srv = new Intent(this, MasjidForegroundService.class);
            srv.putExtra("title", title);
            srv.putExtra("text", text);
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(srv);
            } else {
                startService(srv);
            }
        } catch (Exception ignored) {}
    }

    public int dapatkanJalurStreamAktif() {
        try {
            SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
            String rawCfg = sp.getString("config_json", "");
            if (rawCfg != null && !rawCfg.isEmpty()) {
                org.json.JSONObject obj = new org.json.JSONObject(rawCfg);
                int st = obj.optInt("audioStream", AudioManager.STREAM_MUSIC);
                if (st == AudioManager.STREAM_MUSIC
                        || st == AudioManager.STREAM_RING
                        || st == AudioManager.STREAM_NOTIFICATION
                        || st == AudioManager.STREAM_ALARM
                        || st == AudioManager.STREAM_SYSTEM) {
                    return st;
                }
            }
        } catch (Exception ignored) {}
        return AudioManager.STREAM_MUSIC;
    }

    private void pastikanVolumeMediaTidakBisu(int volPercent, boolean autoVol) {
        try {
            // Hanya sesuaikan volume sistem jika autoVol diaktifkan oleh pengguna.
            // Jangan pernah mereset volume secara paksa saat pengguna menyetel volume 0% - 6%!
            if (!autoVol) return;
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                int streamType = dapatkanJalurStreamAktif();
                int maxV = am.getStreamMaxVolume(streamType);
                int curV = am.getStreamVolume(streamType);
                int minNyaman = Math.max(1, Math.round(maxV * 0.55f));
                int targetV = Math.max(curV, Math.round(maxV * (volPercent / 100.0f) * 0.85f));
                if (targetV < minNyaman) targetV = minNyaman;
                am.setStreamVolume(streamType, Math.min(maxV, targetV), 0);
            }
        } catch (Exception ignored) {}
    }

    private void jalankanMediaPlayerSetelahSetDataSource(float v, int volPercent, boolean autoVol) throws Exception {
        currentMainVolume = v;
        int streamType = dapatkanJalurStreamAktif();
        pastikanVolumeMediaTidakBisu(volPercent, autoVol);
        mediaPlayer.setAudioStreamType(streamType);
        mediaPlayer.setOnCompletionListener(mp -> {
            runOnUiThread(() -> {
                try {
                    if (webView != null) {
                        webView.evaluateJavascript("if(window.onNativeAudioFinished) window.onNativeAudioFinished();", null);
                    }
                } catch (Exception ignored) {}
            });
        });
        mediaPlayer.prepare();
        try {
            mediaPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
        } catch (Exception ignored) {}
        mediaPlayer.setVolume(v, v);
        mediaPlayer.start();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void speak(String text, float speed, float pitch) {
            runOnUiThread(() -> {
                try {
                    if (tts != null && ttsReady) {

                        tts.setSpeechRate(speed > 0 ? speed : 1.0f);
                        tts.setPitch(pitch > 0 ? pitch : 1.0f);
                        int streamType = dapatkanJalurStreamAktif();
                        if (Build.VERSION.SDK_INT >= 21) {
                            Bundle ttsParams = new Bundle();
                            ttsParams.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, streamType);
                            tts.speak(text, TextToSpeech.QUEUE_FLUSH, ttsParams, "NIDAUL_ID");
                        } else {
                            java.util.HashMap<String, String> params = new java.util.HashMap<>();
                            params.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "NIDAUL_ID");
                            params.put(TextToSpeech.Engine.KEY_PARAM_STREAM, String.valueOf(streamType));
                            tts.speak(text, TextToSpeech.QUEUE_FLUSH, params);
                        }
                    } else {
                        selesaikanBicaraTTS();
                    }
                } catch (Exception e) {
                    selesaikanBicaraTTS();
                }
            });
        }

        @JavascriptInterface
        public void stopTTS() {
            runOnUiThread(() -> {
                try {
                    if (tts != null) tts.stop();
                    if (geminiTtsPlayer != null) {
                        try {
                            if (geminiTtsPlayer.isPlaying()) geminiTtsPlayer.stop();
                            geminiTtsPlayer.release();
                        } catch (Exception ignored) {}
                        geminiTtsPlayer = null;
                    }
                    if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                        mediaPlayer.setVolume(currentMainVolume, currentMainVolume);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public boolean isStageLocked(String key) {
            try {
                SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
                String altKey = key.replace("_202", "202");
                return sp.getBoolean("gembok_" + key, false) || sp.getBoolean("gembok_" + altKey, false);
            } catch (Exception ignored) {}
            return false;
        }

        @JavascriptInterface
        public void markStageLock(String key) {
            try {
                SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
                String altKey = key.replace("_202", "202");
                sp.edit()
                  .putBoolean("gembok_" + key, true)
                  .putBoolean("gembok_" + altKey, true)
                  .apply();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void clearAllStageLocks() {
            try {
                izinkanResetNolSementara = true;
                SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
                SharedPreferences.Editor ed = sp.edit();
                for (String k : sp.getAll().keySet()) {
                    if (k.startsWith("gembok_")) ed.remove(k);
                }
                ed.commit();
                File permFile = new File(getFilesDir(), "nurul_config_permanent.json");
                if (permFile.exists()) permFile.delete();
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void setAudioStream(int streamType) {
            try {
                String rawCfg = bacaConfigPermanenNative();
                org.json.JSONObject obj = (rawCfg != null && !rawCfg.isEmpty()) ? new org.json.JSONObject(rawCfg) : new org.json.JSONObject();
                obj.put("audioStream", streamType);
                simpanConfigPermanenNative(obj.toString());
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public int getAudioStream() {
            return dapatkanJalurStreamAktif();
        }

        @JavascriptInterface
        public void saveConfig(String jsonStr) {
            try {
                simpanConfigPermanenNative(jsonStr);
                mulaiLayananLatar("Nurul Masjid Pro • Jam Masjid Aktif", "Siaga menjaga jadwal salat & adzan 24 jam");
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String getSavedConfig() {
            try {
                return bacaConfigPermanenNative();
            } catch (Exception ignored) {}
            return "";
        }

        @JavascriptInterface
        public void showStopPopup(String title, boolean forceSimulasi) {
            runOnUiThread(() -> {
                try {
                    if (forceSimulasi) {
                        tampilkanDialogPopupHentikanSuara(title, false);
                        return;
                    }
                    KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                    boolean layarTerkunciAtauMati = (km != null && km.isKeyguardLocked()) || (pm != null && !pm.isInteractive());
                    if (MasjidForegroundService.instance != null) {
                        MasjidForegroundService.instance.munculkanPopupHentikanSuara(title, layarTerkunciAtauMati);
                    } else if (layarTerkunciAtauMati || !isActivityForeground) {
                        tampilkanDialogPopupHentikanSuara(title, true);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void closeStopPopup() {
            runOnUiThread(() -> {
                try {
                    tutupDialogPopupHentikanSuara();
                    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                    if (nm != null) nm.cancel(5202);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void updateNotification(String title, String text) {
            runOnUiThread(() -> mulaiLayananLatar(title, text));
        }

        @JavascriptInterface
        public void hideToBackground() {
            runOnUiThread(() -> moveTaskToBack(true));
        }

        @JavascriptInterface
        public void exitToPhoneHome() {
            runOnUiThread(() -> moveTaskToBack(true));
        }

        @JavascriptInterface
        public void requestAllPermissions() {
            runOnUiThread(() -> mintaSemuaPerizinanLengkap(true));
        }

        @JavascriptInterface
        public void setSilentMode(boolean silent) {
            runOnUiThread(() -> {
                try {
                    AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                    if (am == null) return;
                    if (silent) {
                        savedNotifVolume = am.getStreamVolume(AudioManager.STREAM_NOTIFICATION);
                        am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0);
                    } else if (savedNotifVolume >= 0) {
                        am.setStreamVolume(AudioManager.STREAM_NOTIFICATION, savedNotifVolume, 0);
                        savedNotifVolume = -1;
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public boolean apakahAudioAktif() {
            try {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) return true;
                if (MasjidForegroundService.instance != null && MasjidForegroundService.instance.apakahBgPlayerAktif()) return true;
            } catch (Exception ignored) {}
            return false;
        }

        @JavascriptInterface
        public int getAudioPosition() {
            try {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    return mediaPlayer.getCurrentPosition();
                }
            } catch (Exception ignored) {}
            return 0;
        }

        @JavascriptInterface
        public void seekAudioTo(int ms) {
            try {
                if (mediaPlayer != null && ms > 0 && ms < mediaPlayer.getDuration()) {
                    mediaPlayer.seekTo(ms);
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void httpGetNative(String urlStr, String cbId) {
            new Thread(() -> {
                try {
                    java.net.URL u = new java.net.URL(urlStr);
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) u.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(12000);
                    conn.setReadTimeout(15000);
                    conn.setRequestProperty("User-Agent", "NurulMasjidPro/9.2 Android");
                    int code = conn.getResponseCode();
                    if (code == 200) {
                        InputStream is = conn.getInputStream();
                        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int r;
                        while ((r = is.read(buf)) != -1) {
                            baos.write(buf, 0, r);
                        }
                        is.close();
                        String body = baos.toString("UTF-8");
                        String b64 = android.util.Base64.encodeToString(body.getBytes("UTF-8"), android.util.Base64.NO_WRAP);
                        runOnUiThread(() -> {
                            try {
                                if (webView != null) {
                                    webView.evaluateJavascript("if(window.__onNativeHttpResult) window.__onNativeHttpResult('" + cbId + "', true, '" + b64 + "');", null);
                                }
                            } catch (Exception ignored) {}
                        });
                    } else {
                        runOnUiThread(() -> {
                            try {
                                if (webView != null) {
                                    webView.evaluateJavascript("if(window.__onNativeHttpResult) window.__onNativeHttpResult('" + cbId + "', false, '');", null);
                                }
                            } catch (Exception ignored) {}
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        try {
                            if (webView != null) {
                                webView.evaluateJavascript("if(window.__onNativeHttpResult) window.__onNativeHttpResult('" + cbId + "', false, '');", null);
                            }
                        } catch (Exception ignored) {}
                    });
                }
            }).start();
        }

        @JavascriptInterface
        public void downloadOtaAudio(String audioUrl, String fileName) {
            new Thread(() -> {
                try {
                    File otaDir = new File(getFilesDir(), "ota_audio");
                    if (!otaDir.exists()) otaDir.mkdirs();
                    String cleanName = fileName.replace("/", "_").trim();
                    File outF = new File(otaDir, cleanName);
                    java.net.URL u = new java.net.URL(audioUrl);
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) u.openConnection();
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(30000);
                    InputStream is = conn.getInputStream();
                    FileOutputStream fos = new FileOutputStream(outF);
                    byte[] buf = new byte[16384];
                    int r;
                    while ((r = is.read(buf)) != -1) {
                        fos.write(buf, 0, r);
                    }
                    fos.flush();
                    fos.close();
                    is.close();
                    runOnUiThread(() -> webView.evaluateJavascript("if(window.onOtaAudioDownloaded) window.onOtaAudioDownloaded('" + cleanName + "', true);", null));
                } catch (Exception e) {
                    runOnUiThread(() -> webView.evaluateJavascript("if(window.onOtaAudioDownloaded) window.onOtaAudioDownloaded('" + fileName + "', false);", null));
                }
            }).start();
        }

        @JavascriptInterface
        public void openGoPay(String phone) {
            runOnUiThread(() -> {
                try {
                    ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cb != null) {
                        cb.setPrimaryClip(ClipData.newPlainText("GoPay Pengembang", phone));
                    }
                } catch (Exception ignored) {}
                try {
                    PackageManager pm = getPackageManager();
                    Intent iGopay = pm.getLaunchIntentForPackage("com.gojek.gopay");
                    if (iGopay != null) {
                        iGopay.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(iGopay);
                        webView.evaluateJavascript("if(window.bicaraGoogleTTS) window.bicaraGoogleTTS('Membuka aplikasi GoPay. Nomor tujuan sudah disalin otomatis ke papan klip.', true);", null);
                        return;
                    }
                    Intent iGojek = pm.getLaunchIntentForPackage("com.gojek.app");
                    if (iGojek != null) {
                        iGojek.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(iGojek);
                        webView.evaluateJavascript("if(window.bicaraGoogleTTS) window.bicaraGoogleTTS('Membuka aplikasi Gojek. Nomor GoPay sudah disalin otomatis ke papan klip.', true);", null);
                        return;
                    }
                    try {
                        Intent iMarket = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.gojek.gopay"));
                        iMarket.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(iMarket);
                    } catch (Exception eMarket) {
                        Intent iWeb = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.gojek.gopay"));
                        iWeb.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(iWeb);
                    }
                    webView.evaluateJavascript("if(window.bicaraGoogleTTS) window.bicaraGoogleTTS('Aplikasi GoPay belum terpasang, membuka halaman GoPay di Play Store. Nomor tujuan sudah disalin ke papan klip.', true);", null);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void vibrateDevice(int ms) {
            runOnUiThread(() -> {
                try {
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (v != null) v.vibrate(ms > 0 ? ms : 60);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void openWhatsApp(String phone, String message) {
            runOnUiThread(() -> {
                try {
                    String url = "https://api.whatsapp.com/send?phone=" + phone + "&text=" + URLEncoder.encode(message, "UTF-8");
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void openExternalUrl(String url) {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public String getClipboardText() {
            try {
                ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cb != null && cb.hasPrimaryClip() && cb.getPrimaryClip() != null && cb.getPrimaryClip().getItemCount() > 0) {
                    CharSequence cs = cb.getPrimaryClip().getItemAt(0).coerceToText(MainActivity.this);
                    if (cs != null) return cs.toString().trim();
                }
            } catch (Exception ignored) {}
            return "";
        }

        @JavascriptInterface
        public void httpPostJsonNative(String urlStr, String jsonBody, String cbId) {
            new Thread(() -> {
                try {
                    java.net.URL u = new java.net.URL(urlStr);
                    java.net.HttpURLConnection conn = (java.net.HttpURLConnection) u.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(25000);
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    conn.setRequestProperty("User-Agent", "NurulMasjidPro/9.7 Android");
                    byte[] payloadBytes = jsonBody.getBytes("UTF-8");
                    java.io.OutputStream os = conn.getOutputStream();
                    os.write(payloadBytes);
                    os.flush();
                    os.close();
                    int code = conn.getResponseCode();
                    InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                    if (is != null) {
                        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                        byte[] buf = new byte[8192];
                        int r;
                        while ((r = is.read(buf)) != -1) {
                            baos.write(buf, 0, r);
                        }
                        is.close();
                        String body = baos.toString("UTF-8");
                        String b64 = android.util.Base64.encodeToString(body.getBytes("UTF-8"), android.util.Base64.NO_WRAP);
                        final boolean ok = (code >= 200 && code < 300);
                        runOnUiThread(() -> {
                            try {
                                if (webView != null) {
                                    webView.evaluateJavascript("if(window.__onNativeHttpResult) window.__onNativeHttpResult('" + cbId + "', " + ok + ", '" + b64 + "');", null);
                                }
                            } catch (Exception ignored) {}
                        });
                    } else {
                        runOnUiThread(() -> {
                            try {
                                if (webView != null) {
                                    webView.evaluateJavascript("if(window.__onNativeHttpResult) window.__onNativeHttpResult('" + cbId + "', false, '');", null);
                                }
                            } catch (Exception ignored) {}
                        });
                    }
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        try {
                            if (webView != null) {
                                webView.evaluateJavascript("if(window.__onNativeHttpResult) window.__onNativeHttpResult('" + cbId + "', false, '');", null);
                            }
                        } catch (Exception ignored) {}
                    });
                }
            }).start();
        }

        @JavascriptInterface
        public boolean saveGeminiWavFile(String fileName, String base64Pcm, int sampleRate) {
            try {
                File otaDir = new File(getFilesDir(), "ota_audio");
                if (!otaDir.exists()) otaDir.mkdirs();
                String cleanName = fileName.replace("/", "_").trim();
                File outF = new File(otaDir, cleanName);
                byte[] pcmBytes = android.util.Base64.decode(base64Pcm, android.util.Base64.DEFAULT);
                if (pcmBytes == null || pcmBytes.length < 100) return false;

                boolean alreadyWavOrMp3 = (pcmBytes.length > 4 && pcmBytes[0] == 'R' && pcmBytes[1] == 'I' && pcmBytes[2] == 'F' && pcmBytes[3] == 'F')
                        || (pcmBytes.length > 3 && pcmBytes[0] == 'I' && pcmBytes[1] == 'D' && pcmBytes[2] == '3');

                FileOutputStream fos = new FileOutputStream(outF);
                if (alreadyWavOrMp3) {
                    fos.write(pcmBytes);
                } else {
                    int sRate = (sampleRate > 0) ? sampleRate : 24000;
                    int channels = 1;
                    int byteRate = sRate * channels * 2;
                    int totalDataLen = pcmBytes.length + 36;
                    int totalAudioLen = pcmBytes.length;
                    byte[] header = new byte[44];
                    header[0] = 'R'; header[1] = 'I'; header[2] = 'F'; header[3] = 'F';
                    header[4] = (byte) (totalDataLen & 0xff);
                    header[5] = (byte) ((totalDataLen >> 8) & 0xff);
                    header[6] = (byte) ((totalDataLen >> 16) & 0xff);
                    header[7] = (byte) ((totalDataLen >> 24) & 0xff);
                    header[8] = 'W'; header[9] = 'A'; header[10] = 'V'; header[11] = 'E';
                    header[12] = 'f'; header[13] = 'm'; header[14] = 't'; header[15] = ' ';
                    header[16] = 16; header[17] = 0; header[18] = 0; header[19] = 0;
                    header[20] = 1; header[21] = 0;
                    header[22] = (byte) channels; header[23] = 0;
                    header[24] = (byte) (sRate & 0xff);
                    header[25] = (byte) ((sRate >> 8) & 0xff);
                    header[26] = (byte) ((sRate >> 16) & 0xff);
                    header[27] = (byte) ((sRate >> 24) & 0xff);
                    header[28] = (byte) (byteRate & 0xff);
                    header[29] = (byte) ((byteRate >> 8) & 0xff);
                    header[30] = (byte) ((byteRate >> 16) & 0xff);
                    header[31] = (byte) ((byteRate >> 24) & 0xff);
                    header[32] = (byte) (channels * 2); header[33] = 0;
                    header[34] = 16; header[35] = 0;
                    header[36] = 'd'; header[37] = 'a'; header[38] = 't'; header[39] = 'a';
                    header[40] = (byte) (totalAudioLen & 0xff);
                    header[41] = (byte) ((totalAudioLen >> 8) & 0xff);
                    header[42] = (byte) ((totalAudioLen >> 16) & 0xff);
                    header[43] = (byte) ((totalAudioLen >> 24) & 0xff);
                    fos.write(header, 0, 44);
                    fos.write(pcmBytes);
                }
                fos.flush();
                fos.close();
                return outF.exists() && outF.length() > 512;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean hasGeminiWavFile(String fileName) {
            try {
                File otaDir = new File(getFilesDir(), "ota_audio");
                File f = new File(otaDir, fileName.replace("/", "_").trim());
                return f.exists() && f.length() > 512;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public int countGeminiWavFiles() {
            try {
                File otaDir = new File(getFilesDir(), "ota_audio");
                if (!otaDir.exists()) return 0;
                File[] list = otaDir.listFiles();
                if (list == null) return 0;
                int count = 0;
                for (File f : list) {
                    if (f.getName().startsWith("gemini_tts_") && f.length() > 512) count++;
                }
                return count;
            } catch (Exception e) {
                return 0;
            }
        }

        @JavascriptInterface
        public void clearGeminiWavFiles() {
            try {
                File otaDir = new File(getFilesDir(), "ota_audio");
                if (!otaDir.exists()) return;
                File[] list = otaDir.listFiles();
                if (list == null) return;
                for (File f : list) {
                    if (f.getName().startsWith("gemini_tts_")) f.delete();
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public synchronized boolean playGeminiWavFile(String fileName, int volPercent) {
            try {
                File otaDir = new File(getFilesDir(), "ota_audio");
                File f = new File(otaDir, fileName.replace("/", "_").trim());
                if (!f.exists() || f.length() <= 512) return false;
                if (tts != null) {
                    try { tts.stop(); } catch (Exception ignored) {}
                }
                if (geminiTtsPlayer != null) {
                    try {
                        if (geminiTtsPlayer.isPlaying()) geminiTtsPlayer.stop();
                        geminiTtsPlayer.release();
                    } catch (Exception ignored) {}
                    geminiTtsPlayer = null;
                }
                pastikanVolumeMediaTidakBisu(volPercent, false);
                float v = Math.max(0.35f, Math.min(1.0f, volPercent / 100.0f));
                FileInputStream fis = new FileInputStream(f);
                geminiTtsPlayer = new MediaPlayer();
                geminiTtsPlayer.setDataSource(fis.getFD());
                fis.close();
                geminiTtsPlayer.setAudioStreamType(dapatkanJalurStreamAktif());
                geminiTtsPlayer.setOnCompletionListener(mp -> {
                    try { mp.release(); } catch (Exception ignored) {}
                    geminiTtsPlayer = null;
                    selesaikanBicaraTTS();
                });
                geminiTtsPlayer.prepare();
                try {
                    geminiTtsPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
                } catch (Exception ignored) {}
                geminiTtsPlayer.setVolume(v, v);
                geminiTtsPlayer.start();
                return true;
            } catch (Exception e) {
                if (geminiTtsPlayer != null) {
                    try { geminiTtsPlayer.release(); } catch (Exception ig) {}
                    geminiTtsPlayer = null;
                }
                return false;
            }
        }

        @JavascriptInterface
        public void copyToClipboard(String label, String text) {
            runOnUiThread(() -> {
                try {
                    ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cb != null) {
                        cb.setPrimaryClip(ClipData.newPlainText(label, text));
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void requestGPS() {
            runOnUiThread(() -> {
                try {
                    LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                    Location loc = null;
                    if (lm != null) {
                        String[] provs = new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
                        for (String p : provs) {
                            try {
                                if (lm.isProviderEnabled(p)) {
                                    loc = lm.getLastKnownLocation(p);
                                    if (loc != null) break;
                                }
                            } catch (SecurityException ignored) {}
                        }
                    }
                    if (loc == null) {
                        webView.evaluateJavascript("window.onNativeGPSResult(0, 0, '')", null);
                        return;
                    }
                    double lat = loc.getLatitude();
                    double lon = loc.getLongitude();
                    String lbl = String.format(Locale.US, "Lokasi GPS (%.4f, %.4f)", lat, lon);
                    try {
                        Geocoder geo = new Geocoder(MainActivity.this, new Locale("id", "ID"));
                        List<Address> list = geo.getFromLocation(lat, lon, 1);
                        if (list != null && !list.isEmpty()) {
                            Address a = list.get(0);
                            StringBuilder sb = new StringBuilder();
                            if (a.getSubLocality() != null) sb.append(a.getSubLocality()).append(", ");
                            if (a.getLocality() != null) sb.append("Kec. ").append(a.getLocality()).append(", ");
                            if (a.getSubAdminArea() != null) sb.append(a.getSubAdminArea());
                            if (sb.length() > 0) lbl = sb.toString();
                        }
                    } catch (Exception ignored) {}
                    String safeLbl = lbl.replace("'", "");
                    webView.evaluateJavascript("window.onNativeGPSResult(" + lat + ", " + lon + ", '" + safeLbl + "')", null);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void startCompass(int targetKiblat) {
            runOnUiThread(() -> {
                try {
                    stopCompass();
                    if (sensorManager == null) return;
                    Sensor s = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
                    if (s == null) return;
                    compassListener = new SensorEventListener() {
                        private long lastVibrate = 0;
                        @Override
                        public void onSensorChanged(SensorEvent event) {
                            float az = event.values[0];
                            float diff = Math.abs(az - targetKiblat);
                            if (diff > 180) diff = 360 - diff;
                            if (diff <= 5 && System.currentTimeMillis() - lastVibrate > 3000) {
                                lastVibrate = System.currentTimeMillis();
                                try {
                                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                                    if (v != null) v.vibrate(400);
                                } catch (Exception ignored) {}
                            }
                            webView.evaluateJavascript("if(window.onNativeCompass) window.onNativeCompass(" + az + ");", null);
                        }
                        @Override
                        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
                    };
                    sensorManager.registerListener(compassListener, s, SensorManager.SENSOR_DELAY_UI);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void stopCompass() {
            runOnUiThread(() -> {
                try {
                    if (sensorManager != null && compassListener != null) {
                        sensorManager.unregisterListener(compassListener);
                        compassListener = null;
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void openBatterySettings() {
            runOnUiThread(() -> {
                try {
                    mintaSemuaPerizinanLengkap(true);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public synchronized void stopAudio() {
            try {
                if (tts != null) {
                    try { tts.stop(); } catch (Exception ignored) {}
                }
                if (bellPlayer != null) {
                    try {
                        if (bellPlayer.isPlaying()) bellPlayer.stop();
                        bellPlayer.release();
                    } catch (Exception ignored) {}
                    bellPlayer = null;
                }
                if (mediaPlayer != null) {
                    try {
                        if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                        mediaPlayer.release();
                    } catch (Exception ignored) {}
                    mediaPlayer = null;
                }
                if (MasjidForegroundService.instance != null) {
                    MasjidForegroundService.instance.hentikanBgPlayerDariMain();
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public String getBgStage() {
            try {
                if (MasjidForegroundService.instance != null) {
                    return MasjidForegroundService.instance.getCurrentBgStage();
                }
            } catch (Exception ignored) {}
            return "";
        }

        @JavascriptInterface
        public synchronized boolean playBell(int volPercent) {
            try {
                if (bellPlayer != null) {
                    try {
                        if (bellPlayer.isPlaying()) bellPlayer.stop();
                        bellPlayer.release();
                    } catch (Exception ignored) {}
                    bellPlayer = null;
                }
                pastikanVolumeMediaTidakBisu(volPercent, false);
                float v = Math.max(0.35f, Math.min(0.95f, volPercent / 100.0f));

                String[] bellCands = new String[]{"audio/bel_pendek.mp3", "bel_pendek.mp3"};
                for (String cand : bellCands) {
                    try {
                        AssetFileDescriptor afd = getAssets().openFd(cand);
                        bellPlayer = new MediaPlayer();
                        bellPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                        afd.close();
                        bellPlayer.setAudioStreamType(dapatkanJalurStreamAktif());
                        bellPlayer.setOnCompletionListener(mp -> {
                            try { mp.release(); } catch (Exception ignored) {}
                            bellPlayer = null;
                            runOnUiThread(() -> {
                                try {
                                    if (webView != null) {
                                        webView.evaluateJavascript("if(window.onNativeBellFinished) window.onNativeBellFinished();", null);
                                    }
                                } catch (Exception ignored) {}
                            });
                        });
                        bellPlayer.prepare();
                        bellPlayer.setVolume(v, v);
                        bellPlayer.start();
                        return true;
                    } catch (Exception ignored) {
                        if (bellPlayer != null) {
                            try { bellPlayer.release(); } catch (Exception ig) {}
                            bellPlayer = null;
                        }
                    }
                }
            } catch (Exception ignored) {}
            return false;
        }

        @JavascriptInterface
        public synchronized boolean playAudio(String assetOrPath, int volPercent) {
            try {
                if (tts != null) {
                    try { tts.stop(); } catch (Exception ignored) {}
                }
                if (MasjidForegroundService.instance != null) {
                    MasjidForegroundService.instance.hentikanBgPlayerDariMain();
                }
                if (mediaPlayer != null) {
                    try {
                        if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                        mediaPlayer.release();
                    } catch (Exception ignored) {}
                    mediaPlayer = null;
                }

                SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
                String rawCfg = sp.getString("config_json", "");
                boolean autoVol = rawCfg.contains("\"autoVolume\":true");
                float v = Math.max(0.25f, Math.min(0.95f, volPercent / 100.0f));

                String cleanAsset = assetOrPath.replace("%20", " ");
                if (cleanAsset.startsWith("./")) cleanAsset = cleanAsset.substring(2);
                if (cleanAsset.startsWith("/")) cleanAsset = cleanAsset.substring(1);
                String baseName = cleanAsset.replace("audio/murottal/", "").replace("audio/", "");
                String[] assetCandidates = new String[]{
                        cleanAsset,
                        "audio/" + cleanAsset,
                        "audio/" + baseName,
                        "audio/murottal/" + baseName,
                        baseName
                };

                // 1. Cek jika ada audio tambahan dari Server Update Otomatis (ota_audio)
                File otaDir = new File(getFilesDir(), "ota_audio");
                if (otaDir.exists()) {
                    File otaFile = new File(otaDir, baseName.replace("/", "_"));
                    if (otaFile.exists() && otaFile.length() > 1024) {
                        try {
                            FileInputStream fis = new FileInputStream(otaFile);
                            mediaPlayer = new MediaPlayer();
                            mediaPlayer.setDataSource(fis.getFD());
                            fis.close();
                            jalankanMediaPlayerSetelahSetDataSource(v, volPercent, autoVol);
                            return true;
                        } catch (Exception ignored) {
                            if (mediaPlayer != null) {
                                try { mediaPlayer.release(); } catch (Exception ig) {}
                                mediaPlayer = null;
                            }
                        }
                    }
                }

                // 2. Utama: Baca langsung dari Assets APK resmi lewat AssetFileDescriptor (Urutan Resmi Android SDK)
                for (String cand : assetCandidates) {
                    try {
                        AssetFileDescriptor afd = getAssets().openFd(cand);
                        mediaPlayer = new MediaPlayer();
                        mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                        afd.close();
                        jalankanMediaPlayerSetelahSetDataSource(v, volPercent, autoVol);
                        return true;
                    } catch (Exception ignored) {
                        if (mediaPlayer != null) {
                            try { mediaPlayer.release(); } catch (Exception ig) {}
                            mediaPlayer = null;
                        }
                    }
                }

                // 3. Cadangan InputStream dari Assets jika aset terkompresi oleh sistem
                for (String cand : assetCandidates) {
                    try {
                        InputStream is = getAssets().open(cand);
                        String ext = cand.endsWith(".mp3") ? ".mp3" : ".ogg";
                        File tempFile = new File(getCacheDir(), "nurul_active_play" + ext);
                        FileOutputStream fos = new FileOutputStream(tempFile);
                        byte[] buf = new byte[16384];
                        int read;
                        while ((read = is.read(buf)) != -1) {
                            fos.write(buf, 0, read);
                        }
                        fos.flush();
                        fos.close();
                        is.close();
                        FileInputStream fis = new FileInputStream(tempFile);
                        mediaPlayer = new MediaPlayer();
                        mediaPlayer.setDataSource(fis.getFD());
                        fis.close();
                        jalankanMediaPlayerSetelahSetDataSource(v, volPercent, autoVol);
                        return true;
                    } catch (Exception ignored) {
                        if (mediaPlayer != null) {
                            try { mediaPlayer.release(); } catch (Exception ig) {}
                            mediaPlayer = null;
                        }
                    }
                }

                // 4. Cadangan penyimpanan eksternal
                File sd = Environment.getExternalStorageDirectory();
                String[] candidates = new String[]{
                        sd.getAbsolutePath() + "/AndLua/project/Jadwal salat/" + baseName,
                        sd.getAbsolutePath() + "/AndLua/project/Jadwal salat/murottal/" + baseName,
                        sd.getAbsolutePath() + "/NidaulMasjidPro/" + baseName,
                        sd.getAbsolutePath() + "/NidaulMasjidPro/murottal/" + baseName
                };
                for (String c : candidates) {
                    File f = new File(c);
                    if (f.exists() && f.isFile()) {
                        try {
                            mediaPlayer = new MediaPlayer();
                            mediaPlayer.setDataSource(f.getAbsolutePath());
                            jalankanMediaPlayerSetelahSetDataSource(v, volPercent, autoVol);
                            return true;
                        } catch (Exception ignored) {
                            if (mediaPlayer != null) {
                                try { mediaPlayer.release(); } catch (Exception ig) {}
                                mediaPlayer = null;
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}
            return false;
        }
    }
}
