package id.nidaulmasjid.pro;

import android.app.AlarmManager;
import android.app.KeyguardManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MasjidForegroundService extends Service {
    public static MasjidForegroundService instance;
    public static final String CHANNEL_ID = "nurul_masjid_service_ch93";
    public static final String ACTION_STOP_FROM_OUTSIDE = "id.nidaulmasjid.pro.ACTION_STOP_FROM_OUTSIDE";
    public static final String ACTION_ALARM_TICK = "id.nidaulmasjid.pro.ACTION_ALARM_TICK";

    private PowerManager.WakeLock wakeLock;
    private Handler handler;
    private Runnable tickerRunnable;
    private MediaPlayer bgPlayer;
    private MediaPlayer bgBellPlayer;
    private TextToSpeech bgTts;
    private boolean bgTtsReady = false;
    private Runnable pendingBgTtsCallback = null;
    private Runnable fallbackBgTtsTimer = null;

    private String currentBgStage = "";
    private String currentBgAssetPath = "";
    private int currentBgVolPercent = 75;
    private String manualStoppedStage = "";
    private boolean sedangPengumumanMarbotLatar = false;

    private AudioManager audioManager;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NurulMasjidPro::MesinLatar24Jam");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire();
            }
        } catch (Exception ignored) {}

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        // Siapkan mesin TextToSpeech mandiri di ForegroundService agar saat aplikasi ditutup (Recent Apps),
        // seluruh pengumuman Asisten Marbot 15 menit, Peringatan Kehati-hatian 15 menit, Laporan 3 Waktu,
        // Imsak, Istiwa, Tahajud, dan Alarm Ibadah tetap berbicara 100% normal!
        try {
            bgTts = new TextToSpeech(getApplicationContext(), status -> {
                if (status == TextToSpeech.SUCCESS && bgTts != null) {
                    try {
                        bgTts.setLanguage(new Locale("id", "ID"));
                        bgTts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                            @Override
                            public void onStart(String utteranceId) {}

                            @Override
                            public void onDone(String utteranceId) {
                                selesaikanBicaraLatarTTS();
                            }

                            @Override
                            public void onError(String utteranceId) {
                                selesaikanBicaraLatarTTS();
                            }
                        });
                        bgTtsReady = true;
                    } catch (Exception ignored) {}
                }
            });
        } catch (Exception ignored) {}

        try {
            SharedPreferences spClean = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
            SharedPreferences.Editor edClean = spClean.edit();
            for (String k : spClean.getAll().keySet()) {
                if (k.startsWith("stop_manual_")) edClean.remove(k);
            }
            edClean.apply();
        } catch (Exception ignored) {}

        handler = new Handler(Looper.getMainLooper());
        tickerRunnable = new Runnable() {
            @Override
            public void run() {
                periksaJadwalLatarBelakang();
                if (handler != null) {
                    handler.postDelayed(this, 1000);
                }
            }
        };
        handler.postDelayed(tickerRunnable, 500);
        jadwalkanDetakAlarmTahanBanting();
    }

    private void selesaikanBicaraLatarTTS() {
        if (handler == null) return;
        handler.post(() -> {
            try {
                if (fallbackBgTtsTimer != null) {
                    handler.removeCallbacks(fallbackBgTtsTimer);
                    fallbackBgTtsTimer = null;
                }
                Runnable cb = pendingBgTtsCallback;
                pendingBgTtsCallback = null;
                if (cb != null) {
                    cb.run();
                }
            } catch (Exception ignored) {}
        });
    }

    private String tentukanFileGeminiLatar(String teks) {
        if (teks == null) return "";
        if (teks.contains("Pengumuman Asisten Marbot Masjid")) {
            if (teks.contains("waktu sholat Subuh")) return "gemini_tts_marbot_subuh.wav";
            if (teks.contains("waktu sholat Dzuhur")) return "gemini_tts_marbot_dzuhur.wav";
            if (teks.contains("waktu sholat Ashar")) return "gemini_tts_marbot_ashar.wav";
            if (teks.contains("waktu sholat Maghrib")) return "gemini_tts_marbot_maghrib.wav";
            if (teks.contains("waktu sholat Isya")) return "gemini_tts_marbot_isya.wav";
        }
        if (teks.contains("Peringatan kehati-hatian")) {
            if (teks.contains("sholat Subuh")) return "gemini_tts_hati_subuh.wav";
            if (teks.contains("sholat Dzuhur")) return "gemini_tts_hati_dzuhur.wav";
            if (teks.contains("sholat Ashar")) return "gemini_tts_hati_ashar.wav";
            if (teks.contains("sholat Maghrib")) return "gemini_tts_hati_maghrib.wav";
            if (teks.contains("sholat Isya")) return "gemini_tts_hati_isya.wav";
        }
        if (teks.contains("memasuki waktu Imsak")) return "gemini_tts_imsak.wav";
        if (teks.contains("memasuki waktu Istiwa")) return "gemini_tts_istiwa.wav";
        if (teks.contains("Sepertiga malam terakhir telah tiba")) return "gemini_tts_tahajud.wav";
        if (teks.contains("Dua menit lagi menuju iqomah")) return "gemini_tts_iqomah_cd2.wav";
        if (teks.contains("Satu menit lagi menuju iqomah")) return "gemini_tts_iqomah_cd1.wav";
        if (teks.contains("Matahari telah terbit sempurna")) return "gemini_tts_syuruq.wav";
        return "";
    }

    public void bicaraLatarTTS(String teks, Runnable onDone) {
        if (handler == null) {
            if (onDone != null) onDone.run();
            return;
        }
        handler.post(() -> {
            try {
                if (fallbackBgTtsTimer != null) {
                    handler.removeCallbacks(fallbackBgTtsTimer);
                    fallbackBgTtsTimer = null;
                }
                pendingBgTtsCallback = onDone;

                SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
                String rawCfg = sp.getString("config_json", "");
                float speed = 1.0f;
                float pitch = 1.0f;
                boolean geminiOn = true;
                int volAdzan = 85;
                if (rawCfg != null && !rawCfg.isEmpty()) {
                    JSONObject cfg = new JSONObject(rawCfg);
                    speed = (float) cfg.optDouble("ttsSpeed", 1.0);
                    pitch = (float) cfg.optDouble("ttsPitch", 1.0);
                    geminiOn = cfg.optBoolean("geminiTtsAktif", true);
                    volAdzan = cfg.optInt("volAdzan", 85);
                }
                int streamType = dapatkanJalurStreamLatar();

                if (geminiOn) {
                    String fGem = tentukanFileGeminiLatar(teks);
                    if (!fGem.isEmpty()) {
                        File otaFile = new File(new File(getFilesDir(), "ota_audio"), fGem);
                        if (otaFile.exists() && otaFile.length() > 512) {
                            if (putarAudioDariAsset(fGem, volAdzan, null, 0)) {
                                if (bgPlayer != null) {
                                    bgPlayer.setOnCompletionListener(mp -> {
                                        currentBgStage = "";
                                        selesaikanBicaraLatarTTS();
                                    });
                                }
                                return;
                            }
                        }
                    }
                }

                if (bgTts != null && bgTtsReady) {
                    bgTts.setSpeechRate(speed > 0 ? speed : 1.0f);
                    bgTts.setPitch(pitch > 0 ? pitch : 1.0f);
                    if (Build.VERSION.SDK_INT >= 21) {
                        Bundle ttsParams = new Bundle();
                        ttsParams.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, streamType);
                        bgTts.speak(teks, TextToSpeech.QUEUE_FLUSH, ttsParams, "BG_NIDAUL_ID");
                    } else {
                        HashMap<String, String> params = new HashMap<>();
                        params.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "BG_NIDAUL_ID");
                        params.put(TextToSpeech.Engine.KEY_PARAM_STREAM, String.valueOf(streamType));
                        bgTts.speak(teks, TextToSpeech.QUEUE_FLUSH, params);
                    }
                    long estMs = Math.max(6000L, (long) teks.length() * 115L + 2500L);
                    fallbackBgTtsTimer = this::selesaikanBicaraLatarTTS;
                    handler.postDelayed(fallbackBgTtsTimer, estMs);
                } else if (onDone != null) {
                    onDone.run();
                }
            } catch (Exception e) {
                if (onDone != null) {
                    try { onDone.run(); } catch (Exception ignored) {}
                }
            }
        });
    }

    private void ucapkanMarbotLatarDenganJedaMurottal(String teksPengumuman, boolean belOn, int volAdzan, int volMurottal) {
        try {
            final boolean tadinyaMurottal = apakahBgPlayerAktif()
                    && currentBgStage != null
                    && currentBgStage.startsWith("MUROTTAL_")
                    && currentBgAssetPath != null
                    && !currentBgAssetPath.isEmpty();
            final String fileMurottalSimpan = tadinyaMurottal ? currentBgAssetPath : "";
            final String stageMurottalSimpan = tadinyaMurottal ? currentBgStage : "";
            int posMs = 0;
            if (tadinyaMurottal && bgPlayer != null) {
                try { posMs = bgPlayer.getCurrentPosition(); } catch (Exception ignored) {}
            }
            final int posisiMurottalMs = posMs;

            if (tadinyaMurottal) {
                hentikanBgPlayerDariMain();
            }

            sedangPengumumanMarbotLatar = true;
            tampilkanNotifikasi("Pengumuman Asisten Marbot • Nurul Masjid Pro", teksPengumuman);

            Runnable selesaiBicara = () -> {
                sedangPengumumanMarbotLatar = false;
                if (tadinyaMurottal && !fileMurottalSimpan.isEmpty()) {
                    if (handler != null) {
                        handler.postDelayed(() -> {
                            currentBgStage = stageMurottalSimpan;
                            if (putarAudioDariAsset(fileMurottalSimpan, volMurottal, null, Math.max(0, posisiMurottalMs))) {
                                tampilkanNotifikasi("Murottal Pengantar • Nurul Masjid Pro", "Melanjutkan lantunan murottal setelah pengumuman asisten.");
                            }
                        }, 450);
                    }
                } else {
                    tampilkanNotifikasi("Nurul Masjid Pro • Jam Masjid Aktif", "Siaga menjaga jadwal salat, marbot 15 menit, murottal, tarhim & adzan 24 jam.");
                }
            };

            if (belOn) {
                bunyikanBelLatarDenganCallback(volAdzan, () -> bicaraLatarTTS(teksPengumuman, selesaiBicara));
            } else {
                bicaraLatarTTS(teksPengumuman, selesaiBicara);
            }
        } catch (Exception ignored) {
            sedangPengumumanMarbotLatar = false;
        }
    }

    public void munculkanPopupHentikanSuara(String judulSiaran, boolean simulasiUji) {
        try {
            if (sedangPengumumanMarbotLatar && !simulasiUji) return;

            SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
            String rawCfg = sp.getString("config_json", "");
            if (!simulasiUji && rawCfg != null && !rawCfg.isEmpty()) {
                JSONObject cfgPop = new JSONObject(rawCfg);
                if (!cfgPop.optBoolean("popupHentikanLuar", true)) return;
            }
            KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            boolean layarTerkunciAtauMati = (km != null && km.isKeyguardLocked()) || (pm != null && !pm.isInteractive());
            if (pm != null && !pm.isInteractive()) {
                try {
                    PowerManager.WakeLock screenWl = pm.newWakeLock(
                            PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE,
                            "NurulMasjidPro::PopupWakeLock"
                    );
                    screenWl.acquire(15000);
                } catch (Exception ignored) {}
            }
            if (!simulasiUji && !layarTerkunciAtauMati && MainActivity.instance != null && MainActivity.instance.isActivityForeground) {
                return;
            }

            Intent popIntent = new Intent(this, MainActivity.class);
            popIntent.putExtra("popup_hentikan_suara", true);
            popIntent.putExtra("judul_siaran", judulSiaran);
            popIntent.putExtra("simulasi_uji", simulasiUji);
            popIntent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_NO_USER_ACTION
            );

            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                String popChId = "nurul_masjid_popup_ch93";
                Notification.Builder bPop;
                if (Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel ch = new NotificationChannel(
                            popChId,
                            "Pop-Up Hentikan Suara Jadwal Masjid",
                            NotificationManager.IMPORTANCE_HIGH
                    );
                    ch.enableVibration(false);
                    ch.setSound(null, null);
                    nm.createNotificationChannel(ch);
                    bPop = new Notification.Builder(this, popChId);
                } else {
                    bPop = new Notification.Builder(this);
                    bPop.setPriority(Notification.PRIORITY_MAX);
                }
                int piFlags = Build.VERSION.SDK_INT >= 31
                        ? (PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)
                        : PendingIntent.FLAG_UPDATE_CURRENT;
                PendingIntent piFull = PendingIntent.getActivity(this, 303, popIntent, piFlags);

                Intent stopIntent = new Intent(this, MasjidForegroundService.class);
                stopIntent.setAction(ACTION_STOP_FROM_OUTSIDE);
                PendingIntent piStop = PendingIntent.getService(this, 304, stopIntent, piFlags);

                bPop.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle("Sedang Berbunyi: " + judulSiaran)
                    .setContentText("Ketuk HENTIKAN SUARA SEKARANG untuk mematikan suara tanpa menghentikan jadwal latar belakang.")
                    .setContentIntent(piFull)
                    .setFullScreenIntent(piFull, true)
                    .addAction(android.R.drawable.ic_media_pause, "HENTIKAN SUARA SEKARANG", piStop)
                    .setAutoCancel(true);
                nm.notify(5202, bPop.build());
            }

            startActivity(popIntent);
            if (MainActivity.instance != null) {
                MainActivity.instance.tampilkanDialogPopupHentikanSuara(judulSiaran, !simulasiUji);
            }
        } catch (Exception ignored) {}
    }

    public String getCurrentBgStage() {
        if (apakahBgPlayerAktif() && currentBgStage != null) {
            return currentBgStage;
        }
        return "";
    }

    public void hentikanSemuaSuaraDariLuarApk(boolean beriGetarKonfirmasi) {
        try {
            sedangPengumumanMarbotLatar = false;
            pendingBgTtsCallback = null;
            if (bgTts != null) {
                try { bgTts.stop(); } catch (Exception ignored) {}
            }
            if (currentBgStage != null && !currentBgStage.isEmpty()) {
                manualStoppedStage = currentBgStage;
            }
            hentikanBgPlayerDariMain();
            if (MainActivity.instance != null) {
                MainActivity.instance.hentikanAudioDariLuarApk();
            }
            if (MainActivity.instance != null) {
                try { MainActivity.instance.tutupDialogPopupHentikanSuara(); } catch (Exception ignored) {}
            }
            try {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.cancel(5202);
            } catch (Exception ignored) {}
            if (beriGetarKonfirmasi) {
                try {
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (v != null) v.vibrate(250);
                } catch (Exception ignored) {}
            }
            tampilkanNotifikasi("Nurul Masjid Pro • Suara Dihentikan", "Siaran audio telah dihentikan. Mesin jadwal tetap siaga 24 jam.");
        } catch (Exception ignored) {}
    }

    private String pilihFileTidakKosong(JSONObject cfg, String key, String fallbackDefault) {
        String val = cfg.optString(key, fallbackDefault);
        if (val == null || val.trim().isEmpty()) {
            return fallbackDefault;
        }
        return val.trim();
    }

    private int keMenitAbsolut(String jamStr) {
        try {
            if (jamStr == null || !jamStr.contains(":")) return -1;
            String[] p = jamStr.trim().split(":");
            return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
        } catch (Exception e) {
            return -1;
        }
    }

    private String tambahMenit(String wStr, int add) {
        try {
            int m = keMenitAbsolut(wStr);
            if (m < 0) return wStr;
            int tot = (m + add) % 1440;
            if (tot < 0) tot += 1440;
            return String.format(Locale.US, "%02d:%02d", tot / 60, tot % 60);
        } catch (Exception e) {
            return wStr;
        }
    }

    private String waktuSholatTerkoreksiBg(JSONObject jdw, JSONObject cfg, String namaWaktu) {
        if (jdw == null) return "";
        String raw = jdw.optString(namaWaktu, "");
        if (raw == null || raw.isEmpty()) return "";
        if ("Terbit".equals(namaWaktu) || "Dhuha".equals(namaWaktu)) return raw;
        int ikhtiar = cfg.optInt("ikhtiar", 0);
        int kor = cfg.optInt("kor_" + namaWaktu.toLowerCase(Locale.US), 0);
        return tambahMenit(raw, ikhtiar + kor);
    }

    private boolean sudahDigembok(SharedPreferences sp, String keyGembok) {
        if (sp.getBoolean("gembok_" + keyGembok, false)) return true;
        // Cek juga variasi tanpa garis bawah sebelum tanggal agar 100% sinkron dengan WebView app.js
        String altKey = keyGembok.replace("_202", "202");
        return sp.getBoolean("gembok_" + altKey, false);
    }

    private void tandaiGembok(SharedPreferences sp, String keyGembok) {
        String altKey = keyGembok.replace("_202", "202");
        sp.edit()
          .putBoolean("gembok_" + keyGembok, true)
          .putBoolean("gembok_" + altKey, true)
          .apply();
    }

    private boolean cekWaktuTiba(SharedPreferences sp, int menitSkrg, String jamTargetStr, String keyGembok) {
        if (jamTargetStr == null || jamTargetStr.isEmpty() || sudahDigembok(sp, keyGembok)) return false;
        int targetM = keMenitAbsolut(jamTargetStr);
        if (targetM < 0) return false;
        if (menitSkrg >= targetM && menitSkrg <= targetM + 1) {
            tandaiGembok(sp, keyGembok);
            return true;
        }
        return false;
    }

    private boolean cekDalamRentangMenit(SharedPreferences sp, int menitSkrg, String jamMulaiStr, String jamAkhirStr, String keyGembok) {
        if (jamMulaiStr == null || jamAkhirStr == null) return false;
        if (keyGembok.equals(manualStoppedStage)) return false;
        if (sudahDigembok(sp, keyGembok)) return false;
        int mMulai = keMenitAbsolut(jamMulaiStr);
        int mAkhir = keMenitAbsolut(jamAkhirStr);
        if (mMulai < 0 || mAkhir < 0) return false;
        if (menitSkrg >= mMulai && menitSkrg < mAkhir) {
            tandaiGembok(sp, keyGembok);
            return true;
        }
        return false;
    }

    private JSONObject hitungJadwalKemenagHariIniFallback(double lat, double lon, Calendar cal) {
        try {
            int dayOfYear = cal.get(Calendar.DAY_OF_YEAR);
            double gamma = (2.0 * Math.PI / 365.0) * (dayOfYear - 1);
            double eqTime = 229.18 * (0.000075 + 0.001868 * Math.cos(gamma) - 0.032077 * Math.sin(gamma)
                    - 0.014615 * Math.cos(2.0 * gamma) - 0.040849 * Math.sin(2.0 * gamma));
            double decl = 0.006918 - 0.399912 * Math.cos(gamma) + 0.070257 * Math.sin(gamma)
                    - 0.006758 * Math.cos(2.0 * gamma) + 0.000907 * Math.sin(2.0 * gamma)
                    - 0.002697 * Math.cos(3.0 * gamma) + 0.00148 * Math.sin(3.0 * gamma);
            int tz = 7;
            if (lon >= 115.0 && lon < 130.0) tz = 8;
            else if (lon >= 130.0) tz = 9;
            double rad = Math.PI / 180.0;
            double deg = 180.0 / Math.PI;
            double transit = 12.0 + tz - (lon / 15.0) - (eqTime / 60.0);

            double haSubuh = hitungSudutJamMatahari(lat, decl, -20.0, rad, deg);
            double haTerbit = hitungSudutJamMatahari(lat, decl, -0.833, rad, deg);
            double haDhuha = hitungSudutJamMatahari(lat, decl, 4.5, rad, deg);
            double altAshar = Math.atan(1.0 / (1.0 + Math.tan(Math.abs(lat * rad - decl)))) * deg;
            double haAshar = hitungSudutJamMatahari(lat, decl, altAshar, rad, deg);
            double haIsya = hitungSudutJamMatahari(lat, decl, -18.0, rad, deg);

            double ihtiyat = 2.0 / 60.0;
            double tSubuh = transit - haSubuh + ihtiyat;
            double tImsak = tSubuh - (10.0 / 60.0);
            double tTerbit = transit - haTerbit - (2.0 / 60.0);
            double tDhuha = transit - haDhuha + ihtiyat;
            double tIstiwa = transit;
            double tDzuhur = transit + (3.0 / 60.0);
            double tAshar = transit + haAshar + ihtiyat;
            double tMaghrib = transit + haTerbit + (3.0 / 60.0);
            double tIsya = transit + haIsya + ihtiyat;

            JSONObject obj = new JSONObject();
            obj.put("Imsak", formatJamDesimal(tImsak));
            obj.put("Subuh", formatJamDesimal(tSubuh));
            obj.put("Terbit", formatJamDesimal(tTerbit));
            obj.put("Dhuha", formatJamDesimal(tDhuha));
            obj.put("Istiwa", formatJamDesimal(tIstiwa));
            obj.put("Dzuhur", formatJamDesimal(tDzuhur));
            obj.put("Ashar", formatJamDesimal(tAshar));
            obj.put("Maghrib", formatJamDesimal(tMaghrib));
            obj.put("Isya", formatJamDesimal(tIsya));
            return obj;
        } catch (Exception e) {
            return null;
        }
    }

    private double hitungSudutJamMatahari(double lat, double decl, double angleDeg, double rad, double deg) {
        double cosHA = (Math.sin(angleDeg * rad) - Math.sin(lat * rad) * Math.sin(decl))
                / (Math.cos(lat * rad) * Math.cos(decl));
        if (cosHA > 1.0) cosHA = 1.0;
        if (cosHA < -1.0) cosHA = -1.0;
        return (Math.acos(cosHA) * deg) / 15.0;
    }

    private String formatJamDesimal(double jamDes) {
        int totalMenit = (int) Math.round(((jamDes % 24.0 + 24.0) % 24.0) * 60.0) % 1440;
        int h = totalMenit / 60;
        int m = totalMenit % 60;
        return String.format(Locale.US, "%02d:%02d", h, m);
    }

    private void periksaJadwalLatarBelakang() {
        try {
            if (wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire();

            // Jika sedang berbicara pengumuman Marbot di latar belakang, jangan potong pembicaraan!
            if (sedangPengumumanMarbotLatar) return;

            // Hanya delegasikan ke MainActivity jika MainActivity benar-benar sedang tampil di depan layar (foreground).
            // Saat aplikasi diminimalkan atau ditutup (layar mati / di luar aplikasi / di-swipe dari Recent Apps),
            // jalankan pemeriksaan jadwal langsung di MasjidForegroundService agar 100% pasti berbunyi!
            KeyguardManager kmScreen = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
            PowerManager pmScreen = (PowerManager) getSystemService(Context.POWER_SERVICE);
            boolean layarTerkunciAtauMati = (kmScreen != null && kmScreen.isKeyguardLocked())
                    || (pmScreen != null && !pmScreen.isInteractive());

            if (MainActivity.instance != null && MainActivity.instance.isActivityForeground && !layarTerkunciAtauMati) {
                MainActivity.instance.picuDetakJadwalDariService();
                return;
            }

            SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
            String rawCfg = sp.getString("config_json", "");
            if (rawCfg == null || rawCfg.isEmpty()) return;

            JSONObject cfg = new JSONObject(rawCfg);
            Date nowDate = new Date();
            String tglIni = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(nowDate);
            Calendar cal = Calendar.getInstance();
            int jamSkrgNum = cal.get(Calendar.HOUR_OF_DAY);
            int mntSkrgNum = cal.get(Calendar.MINUTE);
            int menitSkrg = jamSkrgNum * 60 + mntSkrgNum;
            int detikSkrg = cal.get(Calendar.SECOND);
            int hariMinggu = cal.get(Calendar.DAY_OF_WEEK);
            String hh = String.format(Locale.US, "%02d", jamSkrgNum);
            String mm = String.format(Locale.US, "%02d", mntSkrgNum);
            int volAdzan = cfg.optInt("volAdzan", 85);
            int volMurottal = cfg.optInt("volMurottal", 75);

            // Alarm Pribadi tetap diperiksa 24 jam meskipun jadwal kota sedang disinkronkan
            String alarmWaktuAwal = cfg.optString("alarm_waktu", "").trim();
            if (!alarmWaktuAwal.isEmpty() && cekWaktuTiba(sp, menitSkrg, alarmWaktuAwal, "ALARM_PRIBADI_" + tglIni + "_" + alarmWaktuAwal)) {
                hentikanBgPlayerDariMain();
                currentBgStage = "ALARM_PRIBADI_" + tglIni + "_" + alarmWaktuAwal;
                final String pesanAlarmAwal = cfg.optString("alarm_pesan", "Pengingat waktu ibadah pribadi Anda telah tiba.");
                if (putarAudioRangkaianLatar(new String[]{"audio/bumper.mp3"}, volAdzan, 0, () -> bicaraLatarTTS(pesanAlarmAwal, null))) {
                    tampilkanNotifikasi("Alarm Ibadah Pribadi • Nurul Masjid Pro", pesanAlarmAwal);
                    munculkanPopupHentikanSuara("Alarm Ibadah Pribadi (" + alarmWaktuAwal + ")", false);
                }
                return;
            }

            double latCfg = cfg.optDouble("latitude", 0.0);
            double lonCfg = cfg.optDouble("longitude", 0.0);
            String kota = cfg.optString("kota", "").trim();
            if (kota.isEmpty()) {
                kota = cfg.optString("lokasiDitemukan", cfg.optString("kecamatan", "")).trim();
            }
            if (kota.isEmpty() && (latCfg == 0.0 || lonCfg == 0.0)) return;
            if (!cfg.optBoolean("master_aktif", true)) return;

            String lokasiSebut = cfg.optString("lokasiDitemukan", kota);
            if (lokasiSebut == null || lokasiSebut.trim().isEmpty() || lokasiSebut.toLowerCase(Locale.US).contains("belum diatur")) {
                lokasiSebut = kota.isEmpty() ? "wilayah Anda" : kota;
            }

            JSONObject jadwalSebulan = cfg.optJSONObject("jadwalSebulan");
            JSONObject jdw = (jadwalSebulan != null) ? jadwalSebulan.optJSONObject(tglIni) : null;
            if (jdw == null) {
                double latHitung = (latCfg != 0.0) ? latCfg : -7.7062;
                double lonHitung = (lonCfg != 0.0) ? lonCfg : 114.0095;
                jdw = hitungJadwalKemenagHariIniFallback(latHitung, lonHitung, cal);
            }
            if (jdw == null) return;

            boolean doaOn = cfg.optBoolean("s_doa_adzan", true);
            boolean belOn = cfg.optBoolean("s_bel", true);
            String fileDoa = pilihFileTidakKosong(cfg, "doaAdzanFile", "audio/doa_adzan.mp3");
            String fileAsmaul = pilihFileTidakKosong(cfg, "asmaulFile", "audio/asmaul_husna.mp3");

            int durTarhimCfg = Math.max(1, cfg.optInt("waktuTarhim", 6));
            int durAsmaulCfg = cfg.optBoolean("s_asmaul", true) ? Math.max(0, cfg.optInt("waktuAsmaul", 4)) : 0;
            int durMurottalCfg = Math.max(0, cfg.optInt("waktuMurottal", 30));
            int durArhamCfg = cfg.optBoolean("s_arham", true) ? Math.max(0, cfg.optInt("waktuArham", 10)) : 0;
            int jedaIqomah = Math.max(6, cfg.optInt("waktuIqomah", 10));

            // -----------------------------------------------------------------
            // 0A. ESTAFET PERINGATAN TERBIT (H-10 MENIT: 3 AUDIO BERANTAI) & WAKTU TERBIT (SYURUQ) & DHUHA
            // -----------------------------------------------------------------
            String jamTerbitBg = jdw.optString("Terbit", "");
            if (jamTerbitBg != null && !jamTerbitBg.isEmpty()) {
                String jamPraTerbitBg = tambahMenit(jamTerbitBg, -10);
                String jamDhuhaBg = jdw.optString("Dhuha", "");
                if (jamDhuhaBg == null || jamDhuhaBg.isEmpty()) {
                    jamDhuhaBg = tambahMenit(jamTerbitBg, 20);
                }

                if (cfg.optBoolean("s_terbit", true) && cekWaktuTiba(sp, menitSkrg, jamTerbitBg, "TERBIT_" + tglIni)) {
                    hentikanBgPlayerDariMain();
                    currentBgStage = "TERBIT_" + tglIni;
                    String[] rantaiTerbit = new String[]{"audio/sirine_terbit.mp3", "audio/terbit.mp3"};
                    if (putarAudioRangkaianLatar(rantaiTerbit, volAdzan, 0, () -> bicaraLatarTTS("Matahari telah terbit sempurna, waktu Syuruq telah tiba.", null))) {
                        tampilkanNotifikasi("Waktu Matahari Terbit (Syuruq) • Nurul Masjid Pro", "Sirine & Pengumuman Waktu Terbit sedang berbunyi.");
                        munculkanPopupHentikanSuara("Waktu Matahari Terbit (Syuruq)", false);
                    }
                    return;
                }
                if (cfg.optBoolean("s_preterbit", true) && cekWaktuTiba(sp, menitSkrg, jamPraTerbitBg, "PRETERBIT_" + tglIni)) {
                    hentikanBgPlayerDariMain();
                    currentBgStage = "PRETERBIT_" + tglIni;
                    String[] rantaiPraTerbit = new String[]{
                            "audio/timer_terbit.mp3",
                            "audio/peringatan terbit.mp3",
                            "audio/ya_muhaimin_ya_salam.mp3"
                    };
                    if (putarAudioRangkaianLatar(rantaiPraTerbit, volAdzan, 0, null)) {
                        tampilkanNotifikasi("10 Menit Menjelang Terbit • Nurul Masjid Pro", "Timer, Peringatan Terbit & Sholawat Ya Muhaimin Ya Salam.");
                        munculkanPopupHentikanSuara("Peringatan 10 Menit Menjelang Terbit", false);
                    }
                    return;
                }
                if (cfg.optBoolean("s_dhuha", true) && cekWaktuTiba(sp, menitSkrg, jamDhuhaBg, "DHUHA_" + tglIni)) {
                    hentikanBgPlayerDariMain();
                    currentBgStage = "DHUHA_" + tglIni;
                    if (putarAudioDariAsset("audio/dhuha.ogg", volAdzan, null, 0)) {
                        tampilkanNotifikasi("Waktu Salat Sunnah Dhuha • Nurul Masjid Pro", "Pengingat Waktu Salat Sunnah Dhuha sedang berbunyi.");
                        munculkanPopupHentikanSuara("Pengingat Waktu Salat Dhuha", false);
                    }
                    return;
                }
            }

            // -----------------------------------------------------------------
            // 0B. PENGUMUMAN ASISTEN MARBOT 15 MENIT MENJELANG 5 WAKTU SHOLAT,
            //     PERINGATAN 15 MENIT WAKTU KEHATI-HATIAN AKHIR WAKTU SHOLAT,
            //     & LAPORAN 3 WAKTU PILIHAN (03:00, 05:00, 11:00) DI LATAR BELAKANG!
            // -----------------------------------------------------------------
            List<String> pesanMarbotGabungan = new ArrayList<>();
            int menitHati = Math.max(5, cfg.optInt("menitKehatihatian", 15));
            if (cfg.optBoolean("s_kehatihatian", true)) {
                String[][] daftarAkhir = new String[][]{
                        {"Subuh", jdw.optString("Terbit", ""), "matahari terbit"},
                        {"Dzuhur", waktuSholatTerkoreksiBg(jdw, cfg, "Ashar"), "masuk waktu Ashar"},
                        {"Ashar", waktuSholatTerkoreksiBg(jdw, cfg, "Maghrib"), "masuk waktu Maghrib"},
                        {"Maghrib", waktuSholatTerkoreksiBg(jdw, cfg, "Isya"), "masuk waktu Isya"},
                        {"Isya", waktuSholatTerkoreksiBg(jdw, cfg, "Subuh"), "masuk waktu Subuh"}
                };
                for (String[] item : daftarAkhir) {
                    String namaS = item[0];
                    String batas = item[1];
                    String ketBatas = item[2];
                    if (batas == null || batas.isEmpty()) continue;
                    String jamHati = tambahMenit(batas, -menitHati);
                    if (cekWaktuTiba(sp, menitSkrg, jamHati, "HATI_" + namaS + "_" + tglIni)) {
                        pesanMarbotGabungan.add(
                                "Peringatan kehati-hatian akhir waktu sholat. Waktu sholat " + namaS
                                + " tersisa " + menitHati + " menit lagi sebelum " + ketBatas
                                + " pukul " + batas.replace(":", " lewat ")
                                + ". Bagi yang belum menunaikan sholat " + namaS + ", segera dirikan sholat."
                        );
                    }
                }
            }

            int menitSebelum5 = Math.max(5, cfg.optInt("menitLaporan5Waktu", 15));
            if (cfg.optBoolean("s_jam", true) || cfg.optBoolean("s_marbot", true)) {
                String[] wajib5Nama = new String[]{"Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya"};
                for (String namaW : wajib5Nama) {
                    String jamW = waktuSholatTerkoreksiBg(jdw, cfg, namaW);
                    if (jamW == null || jamW.isEmpty()) continue;
                    String jamLap5 = tambahMenit(jamW, -menitSebelum5);
                    if (cekWaktuTiba(sp, menitSkrg, jamLap5, "LAP5WAKTU_" + namaW + "_" + tglIni)) {
                        pesanMarbotGabungan.add(
                                "Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. Sekarang pukul "
                                + hh + " lewat " + mm + " menit. " + menitSebelum5
                                + " menit lagi akan memasuki waktu sholat " + namaW + " pada pukul "
                                + jamW.replace(":", " lewat ") + " untuk " + lokasiSebut
                                + ". Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid."
                        );
                    }
                }
            }

            if (cfg.optBoolean("s_laporan3waktu", true) && ("03".equals(hh) || "05".equals(hh) || "11".equals(hh)) && mntSkrgNum >= 0 && mntSkrgNum <= 1) {
                String kunci3W = "JAM3W_" + tglIni + "_" + hh;
                if (!sudahDigembok(sp, kunci3W)) {
                    tandaiGembok(sp, kunci3W);
                    if ("03".equals(hh)) {
                        pesanMarbotGabungan.add("Pukul 03 lewat 00 dini hari. Saatnya sepertiga malam terakhir untuk sholat Tahajud dan munajat.");
                    } else if ("05".equals(hh)) {
                        String infoTerbitPagi = (jamTerbitBg != null && !jamTerbitBg.isEmpty())
                                ? (" Waktu matahari terbit hari ini pukul " + jamTerbitBg.replace(":", " lewat ") + ".")
                                : "";
                        pesanMarbotGabungan.add("Assalamu'alaikum warahmatullahi wabarakatuh. Rangkuman pagi Nurul Masjid Pro untuk wilayah " + lokasiSebut + "." + infoTerbitPagi + " Mari awali pagi dengan zikir pagi dan sedekah subuh.");
                    } else if ("11".equals(hh)) {
                        boolean isJum = (hariMinggu == Calendar.FRIDAY);
                        pesanMarbotGabungan.add("Pukul 11 lewat 00 siang. " + (isJum ? "Mari bersiap lebih awal menuju masjid untuk menunaikan ibadah sholat Jumat." : "Saatnya bersiap menjelang waktu sholat Dzuhur."));
                    }
                }
            }

            if (!pesanMarbotGabungan.isEmpty()) {
                StringBuilder sbMarbot = new StringBuilder();
                for (int i = 0; i < pesanMarbotGabungan.size(); i++) {
                    if (i > 0) sbMarbot.append(" ");
                    sbMarbot.append(pesanMarbotGabungan.get(i));
                }
                ucapkanMarbotLatarDenganJedaMurottal(sbMarbot.toString(), belOn, volAdzan, volMurottal);
                return;
            }

            // -----------------------------------------------------------------
            // 0C. ALARM IBADAH PRIBADI & SEPERTIGA MALAM (TAHAJUD NYATA) DI LATAR BELAKANG
            // -----------------------------------------------------------------
            String alarmWaktu = cfg.optString("alarm_waktu", "").trim();
            if (!alarmWaktu.isEmpty() && cekWaktuTiba(sp, menitSkrg, alarmWaktu, "ALARM_PRIBADI_" + tglIni + "_" + alarmWaktu)) {
                String alarmPesan = cfg.optString("alarm_pesan", "Saatnya bangun untuk ibadah dan zikir.").trim();
                if (alarmPesan.isEmpty()) alarmPesan = "Alarm ibadah pribadi berbunyi.";
                final String pesanAlarmFinal = alarmPesan;
                hentikanBgPlayerDariMain();
                currentBgStage = "ALARM_KHUSUS";
                if (putarAudioRangkaianLatar(new String[]{"audio/bumper.mp3"}, volAdzan, 0, () -> bicaraLatarTTS(pesanAlarmFinal, null))) {
                    tampilkanNotifikasi("Pengingat Jam Khusus • Nurul Masjid Pro", pesanAlarmFinal);
                    munculkanPopupHentikanSuara("Pengingat Jam Khusus: " + pesanAlarmFinal, false);
                }
                return;
            }

            if (cfg.optBoolean("s_tahajud", true)) {
                String jamMaghribThj = waktuSholatTerkoreksiBg(jdw, cfg, "Maghrib");
                String jamSubuhThj = waktuSholatTerkoreksiBg(jdw, cfg, "Subuh");
                int tm = keMenitAbsolut(jamMaghribThj);
                int ts = keMenitAbsolut(jamSubuhThj);
                if (tm >= 0 && ts >= 0) {
                    if (ts < tm) ts += 1440;
                    int thj = (tm + (2 * (ts - tm) / 3)) % 1440;
                    String jamTahajudNyata = String.format(Locale.US, "%02d:%02d", thj / 60, thj % 60);
                    if (cekWaktuTiba(sp, menitSkrg, jamTahajudNyata, "THJ_" + tglIni)) {
                        hentikanBgPlayerDariMain();
                        currentBgStage = "TAHAJUD_NYATA";
                        tampilkanNotifikasi("Qiyamul Lail / Salat Tahajud • Nurul Masjid Pro", "Sepertiga malam terakhir telah tiba. Bangunlah untuk sholat Tahajud.");
                        munculkanPopupHentikanSuara("Pengingat Salat Tahajud (Sepertiga Malam)", false);
                        bicaraLatarTTS("Sepertiga malam terakhir telah tiba. Bangunlah untuk sholat Tahajud.", () -> {
                            putarAudioDariAsset("audio/tahajud.mp3", volAdzan, null, 0);
                        });
                        return;
                    }
                }
            }

            // -----------------------------------------------------------------
            // 1-6. RANGKAIAN JADWAL SALAT 5 WAKTU LENGKAP DI LATAR BELAKANG
            // -----------------------------------------------------------------
            String[][] waktuWajib = new String[][]{
                    {"Subuh", jdw.optString("Subuh", ""), "adzan_subuh_on", "tarhim_subuh_on", pilihFileTidakKosong(cfg, "adzanSubuhFile", "audio/adzan_subuh.ogg"), pilihFileTidakKosong(cfg, "tarhimSubuhFile", "audio/tarhim.ogg"), "audio/murottal/subuh-01.ogg", "kor_subuh"},
                    {"Dzuhur", jdw.optString("Dzuhur", ""), "adzan_dzuhur_on", "tarhim_dzuhur_on", pilihFileTidakKosong(cfg, "adzanDzuhurFile", "audio/adzan.ogg"), pilihFileTidakKosong(cfg, "tarhimDzuhurFile", "audio/tarhim.ogg"), "audio/murottal/dzuhur-01.ogg", "kor_dzuhur"},
                    {"Ashar", jdw.optString("Ashar", ""), "adzan_ashar_on", "tarhim_ashar_on", pilihFileTidakKosong(cfg, "adzanAsharFile", "audio/murottal/adzan_makkah_standar.mp3"), pilihFileTidakKosong(cfg, "tarhimAsharFile", "audio/tarhim.ogg"), "audio/murottal/ashar-01.ogg", "kor_ashar"},
                    {"Maghrib", jdw.optString("Maghrib", ""), "adzan_maghrib_on", "tarhim_maghrib_on", pilihFileTidakKosong(cfg, "adzanMaghribFile", "audio/adzan.ogg"), pilihFileTidakKosong(cfg, "tarhimMaghribFile", "audio/tarhim.ogg"), "audio/murottal/maghrib-01.ogg", "kor_maghrib"},
                    {"Isya", jdw.optString("Isya", ""), "adzan_isya_on", "tarhim_isya_on", pilihFileTidakKosong(cfg, "adzanIsyaFile", "audio/Ajan Masjid Kampung.ogg"), pilihFileTidakKosong(cfg, "tarhimIsyaFile", "audio/tarhim.ogg"), "audio/murottal/isya-01.ogg", "kor_isya"}
            };

            int ikhtiar = cfg.optInt("ikhtiar", 0);

            for (String[] w : waktuWajib) {
                String nama = w[0];
                String jamDasar = w[1];
                if (jamDasar == null || jamDasar.isEmpty()) continue;
                boolean adzanOn = cfg.optBoolean(w[2], true);
                boolean tarhimOn = cfg.optBoolean(w[3], true);
                String fileAdzan = w[4];
                String fileTarhim = w[5];
                String fileMurottal = w[6];
                int korKhusus = cfg.optInt(w[7], 0);

                String jamAdzan = tambahMenit(jamDasar, ikhtiar + korKhusus);
                int dTarhim = tarhimOn ? durTarhimCfg : 0;
                int dAsmaul = !"Subuh".equals(nama) ? durAsmaulCfg : 0;
                int dArham = "Subuh".equals(nama) ? durArhamCfg : 0;

                String jamTarhim = tambahMenit(jamAdzan, -dTarhim);
                String jamAsmaul = tambahMenit(jamTarhim, -dAsmaul);
                String jamMurottal = tambahMenit(jamAsmaul, -durMurottalCfg);
                String jamArham = tambahMenit(jamMurottal, -dArham);
                String jamIqomah = tambahMenit(jamAdzan, jedaIqomah);
                String jamIqomahCd2 = tambahMenit(jamIqomah, -2);
                String jamIqomahCd1 = tambahMenit(jamIqomah, -1);

                // 1A. HITUNG MUNDUR IQOMAH 2 MENIT & 1 MENIT DI LATAR BELAKANG
                boolean sedangAdzanLatar = apakahBgPlayerAktif() && currentBgStage != null && currentBgStage.startsWith("ADZAN_");
                if (adzanOn && !sedangAdzanLatar && cfg.optBoolean("s_countdown_iqomah", true)) {
                    if (jedaIqomah >= 3 && cekWaktuTiba(sp, menitSkrg, jamIqomahCd2, "IQ_CD2_" + nama + tglIni)) {
                        bunyikanBelLatarDenganCallback(volAdzan, () -> bicaraLatarTTS("Dua menit lagi menuju iqomah " + nama + ".", null));
                        return;
                    }
                    if (jedaIqomah >= 2 && cekWaktuTiba(sp, menitSkrg, jamIqomahCd1, "IQ_CD1_" + nama + tglIni)) {
                        bunyikanBelLatarDenganCallback(volAdzan, () -> bicaraLatarTTS("Satu menit lagi menuju iqomah " + nama + ". Mari luruskan dan rapatkan shaf.", null));
                        return;
                    }
                }

                // 1B. PANGGILAN IQOMAH DI LATAR BELAKANG
                if (adzanOn && cekWaktuTiba(sp, menitSkrg, jamIqomah, "IQ_MAIN_" + nama + "_" + tglIni)) {
                    currentBgStage = "IQOMAH_" + nama;
                    if (belOn) bunyikanBelLatar(volAdzan);
                    String[] rantaiIqomah = new String[]{"audio/iqomah.mp3"};
                    if (putarAudioRangkaianLatar(rantaiIqomah, volAdzan, 0, () -> bicaraLatarTTS("Panggilan iqomah " + nama + " telah selesai dikumandangkan. Mari berdiri, luruskan dan rapatkan barisan salat berjamaah.", null))) {
                        tampilkanNotifikasi("Panggilan Iqomah " + nama + " • Nurul Masjid Pro", "Ketuk HENTIKAN SUARA jika ingin mematikan suara dari luar aplikasi.");
                        munculkanPopupHentikanSuara("Panggilan Iqomah " + nama, false);
                    }
                    return;
                }

                // 2. KUMANDANG ADZAN 5 WAKTU + DOA HABIS ADZAN DI LATAR BELAKANG
                if (adzanOn && cekWaktuTiba(sp, menitSkrg, jamAdzan, "ADZAN_" + nama + "_" + tglIni)) {
                    currentBgStage = "ADZAN_" + nama;
                    String[] rantaiAdzan = doaOn ? new String[]{fileAdzan, fileDoa} : new String[]{fileAdzan};
                    final boolean rawatibOn = cfg.optBoolean("s_rawatib", true);
                    final boolean musafirOn = cfg.optBoolean("s_musafir", false);
                    if (putarAudioRangkaianLatar(rantaiAdzan, volAdzan, 0, () -> {
                        StringBuilder sbBakda = new StringBuilder();
                        if (rawatibOn) {
                            if ("Subuh".equals(nama) || "Ashar".equals(nama)) {
                                sbBakda.append("Mari bersiap merapatkan barisan untuk mendirikan salat berjamaah. ");
                            } else {
                                sbBakda.append("Dirikanlah salat sunnah rawatib sebelum iqomah dikumandangkan. ");
                            }
                        }
                        if (musafirOn && !"Subuh".equals(nama)) {
                            sbBakda.append("Bagi Anda yang sedang dalam perjalanan jauh atau musafir, tersedia keringanan rukhsoh salat jamak dan qashar.");
                        }
                        if (sbBakda.length() > 0) {
                            bicaraLatarTTS(sbBakda.toString(), null);
                        }
                    })) {
                        tampilkanNotifikasi("Kumandang Adzan " + nama + " • Nurul Masjid Pro", "Ketuk HENTIKAN SUARA SEKARANG untuk menghentikan adzan.");
                        munculkanPopupHentikanSuara("Kumandang Adzan " + nama, false);
                    }
                    return;
                }

                // 3. LANTUNAN TARHIM + BEL PENDEK DI LATAR BELAKANG
                if (tarhimOn && dTarhim > 0 && cekDalamRentangMenit(sp, menitSkrg, jamTarhim, jamAdzan, "TARHIM_" + nama + "_" + tglIni)) {
                    currentBgStage = "TARHIM_" + nama + "_" + tglIni;
                    int menitLewat = Math.max(0, menitSkrg - keMenitAbsolut(jamTarhim));
                    int seekMs = (menitLewat > 0) ? ((menitLewat * 60 + detikSkrg) * 1000) : 0;
                    if (belOn) bunyikanBelLatar(volAdzan);
                    if (putarAudioDariAsset(fileTarhim, volMurottal, null, seekMs)) {
                        tampilkanNotifikasi("Lantunan Tarhim " + nama + " • Nurul Masjid Pro", "Ketuk HENTIKAN SUARA di bawah untuk menghentikan tarhim.");
                        munculkanPopupHentikanSuara("Lantunan Tarhim " + nama, false);
                    }
                    return;
                }

                // 3B. PENGINGAT IMSAK (10 MENIT PRA-SUBUH) & PERINGATAN WAKTU ISTIWA (8 MENIT PRA-DZUHUR) DI LATAR BELAKANG
                if ("Subuh".equals(nama) && cfg.optBoolean("s_imsak", true)) {
                    String jamImsak = tambahMenit(jamAdzan, -10);
                    if (cekWaktuTiba(sp, menitSkrg, jamImsak, "IMSAK_" + tglIni)) {
                        final String teksImsak = "Perhatian, pukul " + jamImsak.replace(":", " lewat ") + " telah memasuki waktu Imsak, sepuluh menit menjelang kumandang adzan Subuh pukul " + jamAdzan.replace(":", " lewat ") + ".";
                        bunyikanBelLatarDenganCallback(volAdzan, () -> bicaraLatarTTS(teksImsak, null));
                        return;
                    }
                }
                if ("Dzuhur".equals(nama) && cfg.optBoolean("s_istiwa", true) && hariMinggu != Calendar.FRIDAY) {
                    String jamIstiwa = tambahMenit(jamAdzan, -Math.max(8, dTarhim + dAsmaul));
                    if (cekWaktuTiba(sp, menitSkrg, jamIstiwa, "ISTIWA_" + tglIni)) {
                        final String teksIstiwa = "Perhatian, pukul " + jamIstiwa.replace(":", " lewat ") + " memasuki waktu Istiwa menjelang waktu Dzuhur pukul " + jamAdzan.replace(":", " lewat ") + ". Waktu dilarang mendirikan salat sunnah hingga kumandang adzan Dzuhur.";
                        bunyikanBelLatarDenganCallback(volAdzan, () -> bicaraLatarTTS(teksIstiwa, null));
                        return;
                    }
                }

                // 4. LANTUNAN ASMAUL HUSNA — HIJJAZ DI LATAR BELAKANG
                if (!"Subuh".equals(nama) && dAsmaul > 0 && cekDalamRentangMenit(sp, menitSkrg, jamAsmaul, jamTarhim, "ASMAUL_" + nama + "_" + tglIni)) {
                    currentBgStage = "ASMAUL_" + nama + "_" + tglIni;
                    if (putarAudioDariAsset(fileAsmaul, volMurottal, null, 0)) {
                        tampilkanNotifikasi("Lantunan Asmaul Husna • Nurul Masjid Pro", "Ketuk HENTIKAN SUARA di bawah untuk menghentikan Asmaul Husna.");
                        munculkanPopupHentikanSuara("Lantunan Asmaul Husna (" + nama + ")", false);
                    }
                    return;
                }

                // 5. LANTUNAN MUROTTAL AL-QUR'AN / SURAH YASIN MALAM JUMAT / AL-JUMU'AH DI LATAR BELAKANG
                if (durMurottalCfg > 0 && cekDalamRentangMenit(sp, menitSkrg, jamMurottal, jamAsmaul, "MUROTTAL_" + nama + "_" + tglIni)) {
                    currentBgStage = "MUROTTAL_" + nama + "_" + tglIni;
                    String targetMurottal = fileMurottal;
                    if (hariMinggu == Calendar.FRIDAY && "Dzuhur".equals(nama) && cfg.optBoolean("s_jumat", true)) {
                        targetMurottal = "audio/aljumuah.ogg";
                    } else if (hariMinggu == Calendar.THURSDAY && ("Maghrib".equals(nama) || "Isya".equals(nama)) && (cfg.optBoolean("s_jumat", true) || cfg.optBoolean("s_yasin_malam_jumat", true))) {
                        targetMurottal = "audio/yasin.ogg";
                    }
                    int menitLewatMur = Math.max(0, menitSkrg - keMenitAbsolut(jamMurottal));
                    int seekMurMs = (menitLewatMur > 0) ? ((menitLewatMur * 60 + detikSkrg) * 1000) : 0;
                    if (belOn) bunyikanBelLatar(volAdzan);
                    if (putarAudioDariAsset(targetMurottal, volMurottal, null, seekMurMs)) {
                        tampilkanNotifikasi("Murottal Pengantar " + nama + " • Nurul Masjid Pro", "Ketuk HENTIKAN SUARA di bawah untuk menghentikan murottal.");
                        munculkanPopupHentikanSuara("Murottal Pengantar " + nama, false);
                    }
                    return;
                }

                // 6. LANTUNAN YA ARHAMARROHIMIN PRA-MUROTTAL KHUSUS SUBUH DI LATAR BELAKANG
                if ("Subuh".equals(nama) && dArham > 0 && cekDalamRentangMenit(sp, menitSkrg, jamArham, jamMurottal, "ARHAM_SUBUH_" + tglIni)) {
                    currentBgStage = "ARHAM_SUBUH_" + tglIni;
                    int menitLewatArh = Math.max(0, menitSkrg - keMenitAbsolut(jamArham));
                    int seekArhMs = (menitLewatArh > 0) ? ((menitLewatArh * 60 + detikSkrg) * 1000) : 0;
                    if (belOn) bunyikanBelLatar(volAdzan);
                    if (putarAudioDariAsset("audio/Arhamarrohimin Tarhim.ogg", volMurottal, null, seekArhMs)) {
                        tampilkanNotifikasi("Ya Arhamarrohimin Pra-Subuh • Nurul Masjid Pro", "Ketuk HENTIKAN SUARA di bawah untuk menghentikan suara.");
                        munculkanPopupHentikanSuara("Ya Arhamarrohimin Pra-Subuh", false);
                    }
                    return;
                }
            }
        } catch (Exception ignored) {}
    }

    public boolean apakahBgPlayerAktif() {
        try {
            return bgPlayer != null && bgPlayer.isPlaying();
        } catch (Exception e) {
            return false;
        }
    }

    public void hentikanBgPlayerDariMain() {
        try {
            if (bgBellPlayer != null) {
                if (bgBellPlayer.isPlaying()) bgBellPlayer.stop();
                bgBellPlayer.release();
                bgBellPlayer = null;
            }
            if (bgPlayer != null) {
                if (bgPlayer.isPlaying()) bgPlayer.stop();
                bgPlayer.release();
                bgPlayer = null;
            }
            currentBgStage = "";
        } catch (Exception ignored) {}
    }

    private int dapatkanJalurStreamLatar() {
        try {
            SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
            String rawCfg = sp.getString("config_json", "");
            if (rawCfg != null && !rawCfg.isEmpty()) {
                JSONObject obj = new JSONObject(rawCfg);
                int st = obj.optInt("audioStream", AudioManager.STREAM_MUSIC);
                if (st == AudioManager.STREAM_MUSIC
                        || st == AudioManager.STREAM_RING
                        || st == AudioManager.STREAM_NOTIFICATION
                        || st == AudioManager.STREAM_ALARM
                        || st == AudioManager.STREAM_SYSTEM) {
                    return st;
                }
            }
        } catch (Exception ignored) {}
        return AudioManager.STREAM_MUSIC;
    }

    private void pastikanVolumeMediaLatarTidakBisu() {
        try {
            SharedPreferences sp = getSharedPreferences("nidaul_prefs", MODE_PRIVATE);
            String rawCfg = sp.getString("config_json", "");
            boolean autoVol = false;
            if (rawCfg != null && !rawCfg.isEmpty()) {
                JSONObject obj = new JSONObject(rawCfg);
                autoVol = obj.optBoolean("autoVolume", false);
            }
            if (!autoVol) return;
            if (audioManager == null) {
                audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            }
            if (audioManager != null) {
                int streamType = dapatkanJalurStreamLatar();
                int maxV = audioManager.getStreamMaxVolume(streamType);
                int curV = audioManager.getStreamVolume(streamType);
                if (curV < Math.max(1, Math.round(maxV * 0.55f))) {
                    audioManager.setStreamVolume(streamType, Math.min(maxV, Math.max(1, Math.round(maxV * 0.65f))), 0);
                }
            }
        } catch (Exception ignored) {}
    }

    private void bunyikanBelLatar(int volPercent) {
        bunyikanBelLatarDenganCallback(volPercent, null);
    }

    private void bunyikanBelLatarDenganCallback(int volPercent, Runnable onBellDone) {
        try {
            if (bgBellPlayer != null) {
                try {
                    if (bgBellPlayer.isPlaying()) bgBellPlayer.stop();
                    bgBellPlayer.release();
                } catch (Exception ignored) {}
                bgBellPlayer = null;
            }
            pastikanVolumeMediaLatarTidakBisu();
            AssetFileDescriptor afd = getAssets().openFd("audio/bel_pendek.mp3");
            bgBellPlayer = new MediaPlayer();
            bgBellPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            bgBellPlayer.setAudioStreamType(dapatkanJalurStreamLatar());
            final boolean[] sudahPanggil = new boolean[]{false};
            Runnable panggilSekali = () -> {
                if (sudahPanggil[0]) return;
                sudahPanggil[0] = true;
                if (onBellDone != null) {
                    try { onBellDone.run(); } catch (Exception ignored) {}
                }
            };
            if (onBellDone != null && handler != null) {
                handler.postDelayed(panggilSekali, 2900);
            }
            bgBellPlayer.setOnCompletionListener(mp -> {
                try { mp.release(); } catch (Exception ignored) {}
                bgBellPlayer = null;
                if (handler != null) {
                    handler.postDelayed(panggilSekali, 200);
                } else {
                    panggilSekali.run();
                }
            });
            bgBellPlayer.prepare();
            try {
                bgBellPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            } catch (Exception ignored) {}
            float v = Math.max(0.35f, Math.min(0.95f, volPercent / 100.0f));
            bgBellPlayer.setVolume(v, v);
            bgBellPlayer.start();
        } catch (Exception ignored) {
            if (onBellDone != null) {
                try { onBellDone.run(); } catch (Exception ig) {}
            }
        }
    }

    private synchronized boolean putarAudioRangkaianLatar(String[] daftarAsset, int volPercent, int seekMsPertama, Runnable onAllDone) {
        if (daftarAsset == null || daftarAsset.length == 0) {
            if (onAllDone != null) onAllDone.run();
            return false;
        }
        return putarTahapRangkaianInternal(daftarAsset, 0, volPercent, seekMsPertama, onAllDone);
    }

    private synchronized boolean putarTahapRangkaianInternal(String[] daftarAsset, int indexSekarang, int volPercent, int seekMs, Runnable onAllDone) {
        if (daftarAsset == null || indexSekarang >= daftarAsset.length) {
            currentBgStage = "";
            currentBgAssetPath = "";
            tampilkanNotifikasi("Nurul Masjid Pro • Jam Masjid Aktif", "Siaga menjaga jadwal salat, marbot 15 menit, murottal, tarhim & adzan 24 jam.");
            if (onAllDone != null) {
                try { onAllDone.run(); } catch (Exception ignored) {}
            }
            return true;
        }
        String assetPath = daftarAsset[indexSekarang];
        if (assetPath == null || assetPath.trim().isEmpty()) {
            return putarTahapRangkaianInternal(daftarAsset, indexSekarang + 1, volPercent, 0, onAllDone);
        }
        try {
            if (MainActivity.instance != null) {
                try { MainActivity.instance.hentikanAudioDariService(); } catch (Exception ignored) {}
            }
            if (bgPlayer != null) {
                try {
                    if (bgPlayer.isPlaying()) bgPlayer.stop();
                    bgPlayer.release();
                } catch (Exception ignored) {}
                bgPlayer = null;
            }
            String cleanAsset = assetPath.replace("%20", " ");
            if (cleanAsset.startsWith("./")) cleanAsset = cleanAsset.substring(2);
            if (cleanAsset.startsWith("/")) cleanAsset = cleanAsset.substring(1);
            String baseName = cleanAsset.replace("audio/murottal/", "").replace("audio/", "");

            currentBgAssetPath = cleanAsset;
            currentBgVolPercent = volPercent;
            float v = Math.max(0.25f, Math.min(0.95f, volPercent / 100.0f));

            File otaFile = new File(new File(getFilesDir(), "ota_audio"), baseName.replace("/", "_"));
            if (otaFile.exists() && otaFile.length() > 1024) {
                try {
                    FileInputStream fis = new FileInputStream(otaFile);
                    bgPlayer = new MediaPlayer();
                    bgPlayer.setDataSource(fis.getFD());
                    fis.close();
                    siapkanBgPlayerRangkaian(v, daftarAsset, indexSekarang, volPercent, seekMs, onAllDone);
                    return true;
                } catch (Exception ignored) {
                    if (bgPlayer != null) {
                        try { bgPlayer.release(); } catch (Exception ig) {}
                        bgPlayer = null;
                    }
                }
            }

            String[] assetCandidates = new String[]{
                    cleanAsset,
                    "audio/" + cleanAsset,
                    "audio/" + baseName,
                    "audio/murottal/" + baseName,
                    baseName
            };

            for (String cand : assetCandidates) {
                try {
                    AssetFileDescriptor afd = getAssets().openFd(cand);
                    bgPlayer = new MediaPlayer();
                    bgPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                    afd.close();
                    siapkanBgPlayerRangkaian(v, daftarAsset, indexSekarang, volPercent, seekMs, onAllDone);
                    return true;
                } catch (Exception ignored) {
                    if (bgPlayer != null) {
                        try { bgPlayer.release(); } catch (Exception ig) {}
                        bgPlayer = null;
                    }
                }
            }

            for (String cand : assetCandidates) {
                try {
                    InputStream is = getAssets().open(cand);
                    String ext = cand.endsWith(".mp3") ? ".mp3" : ".ogg";
                    File tempFile = new File(getCacheDir(), "nurul_bg_audio" + ext);
                    FileOutputStream fos = new FileOutputStream(tempFile);
                    byte[] buf = new byte[16384];
                    int read;
                    while ((read = is.read(buf)) != -1) {
                        fos.write(buf, 0, read);
                    }
                    fos.flush();
                    fos.close();
                    is.close();
                    FileInputStream fis = new FileInputStream(tempFile);
                    bgPlayer = new MediaPlayer();
                    bgPlayer.setDataSource(fis.getFD());
                    fis.close();
                    siapkanBgPlayerRangkaian(v, daftarAsset, indexSekarang, volPercent, seekMs, onAllDone);
                    return true;
                } catch (Exception ignored) {
                    if (bgPlayer != null) {
                        try { bgPlayer.release(); } catch (Exception ig) {}
                        bgPlayer = null;
                    }
                }
            }

            File sd = Environment.getExternalStorageDirectory();
            String[] sdCandidates = new String[]{
                    sd.getAbsolutePath() + "/AndLua/project/Jadwal salat/" + baseName,
                    sd.getAbsolutePath() + "/AndLua/project/Jadwal salat/murottal/" + baseName,
                    sd.getAbsolutePath() + "/NidaulMasjidPro/" + baseName,
                    sd.getAbsolutePath() + "/NidaulMasjidPro/murottal/" + baseName
            };
            for (String c : sdCandidates) {
                File f = new File(c);
                if (f.exists() && f.isFile()) {
                    try {
                        bgPlayer = new MediaPlayer();
                        bgPlayer.setDataSource(f.getAbsolutePath());
                        siapkanBgPlayerRangkaian(v, daftarAsset, indexSekarang, volPercent, seekMs, onAllDone);
                        return true;
                    } catch (Exception ignored) {
                        if (bgPlayer != null) {
                            try { bgPlayer.release(); } catch (Exception ig) {}
                            bgPlayer = null;
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void siapkanBgPlayerRangkaian(float v, String[] daftarAsset, int indexSekarang, int volPercent, int seekMs, Runnable onAllDone) throws Exception {
        pastikanVolumeMediaLatarTidakBisu();
        bgPlayer.setAudioStreamType(dapatkanJalurStreamLatar());
        bgPlayer.setOnCompletionListener(mp -> {
            if (indexSekarang + 1 < daftarAsset.length) {
                putarTahapRangkaianInternal(daftarAsset, indexSekarang + 1, volPercent, 0, onAllDone);
            } else {
                currentBgStage = "";
                currentBgAssetPath = "";
                tampilkanNotifikasi("Nurul Masjid Pro • Jam Masjid Aktif", "Siaga menjaga jadwal salat, marbot 15 menit, murottal, tarhim & adzan 24 jam.");
                if (onAllDone != null) {
                    try { onAllDone.run(); } catch (Exception ignored) {}
                }
            }
        });
        bgPlayer.prepare();
        try {
            bgPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
        } catch (Exception ignored) {}
        bgPlayer.setVolume(v, v);
        if (seekMs > 0 && seekMs < bgPlayer.getDuration()) {
            bgPlayer.seekTo(seekMs);
        }
        bgPlayer.start();
    }

    private synchronized boolean putarAudioDariAsset(String assetPath, int volPercent, String nextAssetAfterDone, int seekMs) {
        if (nextAssetAfterDone != null && !nextAssetAfterDone.isEmpty()) {
            return putarAudioRangkaianLatar(new String[]{assetPath, nextAssetAfterDone}, volPercent, seekMs, null);
        }
        return putarAudioRangkaianLatar(new String[]{assetPath}, volPercent, seekMs, null);
    }

    private void jadwalkanDetakAlarmTahanBanting() {
        try {
            Intent tickIntent = new Intent(getApplicationContext(), MasjidForegroundService.class);
            tickIntent.setAction(ACTION_ALARM_TICK);
            tickIntent.setPackage(getPackageName());
            int piFlags = Build.VERSION.SDK_INT >= 31
                    ? (PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent tickPI;
            if (Build.VERSION.SDK_INT >= 26) {
                tickPI = PendingIntent.getForegroundService(getApplicationContext(), 102, tickIntent, piFlags);
            } else {
                tickPI = PendingIntent.getService(getApplicationContext(), 102, tickIntent, piFlags);
            }
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                long triggerAt = SystemClock.elapsedRealtime() + 30000L;
                if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, tickPI);
                } else {
                    am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, tickPI);
                }
            }
        } catch (Exception ignored) {}
    }

    private void jadwalkanHidupKembaliOtomatis() {
        try {
            Intent restartIntent = new Intent(getApplicationContext(), MasjidForegroundService.class);
            restartIntent.setPackage(getPackageName());
            int piFlags = Build.VERSION.SDK_INT >= 31
                    ? (PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_ONE_SHOT)
                    : PendingIntent.FLAG_ONE_SHOT;
            PendingIntent restartPI;
            if (Build.VERSION.SDK_INT >= 26) {
                restartPI = PendingIntent.getForegroundService(getApplicationContext(), 101, restartIntent, piFlags);
            } else {
                restartPI = PendingIntent.getService(getApplicationContext(), 101, restartIntent, piFlags);
            }
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                long triggerAt = SystemClock.elapsedRealtime() + 1000L;
                if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, restartPI);
                } else {
                    am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, restartPI);
                }
            }
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            if (wakeLock != null && !wakeLock.isHeld()) {
                wakeLock.acquire();
            }
        } catch (Exception ignored) {}
        jadwalkanDetakAlarmTahanBanting();

        if (intent != null && intent.getAction() != null) {
            String act = intent.getAction();
            if ("STOP_BG_AUDIO".equals(act)) {
                hentikanBgPlayerDariMain();
                return START_STICKY;
            }
            if (ACTION_STOP_FROM_OUTSIDE.equals(act)) {
                hentikanSemuaSuaraDariLuarApk(true);
                return START_STICKY;
            }
            if (ACTION_ALARM_TICK.equals(act)) {
                periksaJadwalLatarBelakang();
                return START_STICKY;
            }
        }
        String title = "Nurul Masjid Pro • Jam Masjid Aktif";
        String text = "Mesin jadwal salat, marbot 15 menit, murottal, tarhim & adzan berjalan 24 jam di latar belakang.";
        if (intent != null) {
            if (intent.hasExtra("title")) title = intent.getStringExtra("title");
            if (intent.hasExtra("text")) text = intent.getStringExtra("text");
        }
        tampilkanNotifikasi(title, text);
        periksaJadwalLatarBelakang();
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        try {
            tampilkanNotifikasi("Nurul Masjid Pro • Jam Masjid Aktif 24 Jam", "Tetap siaga menjaga jadwal salat, marbot 15 menit, tarhim & adzan walau aplikasi ditutup.");
            jadwalkanHidupKembaliOtomatis();
            jadwalkanDetakAlarmTahanBanting();
        } catch (Exception ignored) {}
        super.onTaskRemoved(rootIntent);
    }

    private void tampilkanNotifikasi(String title, String text) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            Notification.Builder builder;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(
                        CHANNEL_ID,
                        "Siaran & Jadwal Nurul Masjid Pro",
                        NotificationManager.IMPORTANCE_LOW
                );
                nm.createNotificationChannel(ch);
                builder = new Notification.Builder(this, CHANNEL_ID);
            } else {
                builder = new Notification.Builder(this);
            }
            Intent openIntent = new Intent(this, MainActivity.class);
            openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int piFlags = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent piOpen = PendingIntent.getActivity(this, 0, openIntent, piFlags);

            Intent stopIntent = new Intent(this, MasjidForegroundService.class);
            stopIntent.setAction(ACTION_STOP_FROM_OUTSIDE);
            int piStopFlags = Build.VERSION.SDK_INT >= 31
                    ? (PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT)
                    : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent piStop = PendingIntent.getService(this, 202, stopIntent, piStopFlags);

            builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                   .setContentTitle(title)
                   .setContentText(text)
                   .setContentIntent(piOpen)
                   .addAction(android.R.drawable.ic_media_pause, "HENTIKAN SUARA SEKARANG", piStop)
                   .setOngoing(true);

            Notification notif = builder.build();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(5201, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(5201, notif);
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        try {
            if (handler != null && tickerRunnable != null) {
                handler.removeCallbacks(tickerRunnable);
            }
            hentikanBgPlayerDariMain();
            if (bgTts != null) {
                try {
                    bgTts.stop();
                    bgTts.shutdown();
                } catch (Exception ignored) {}
                bgTts = null;
            }
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
            jadwalkanHidupKembaliOtomatis();
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
