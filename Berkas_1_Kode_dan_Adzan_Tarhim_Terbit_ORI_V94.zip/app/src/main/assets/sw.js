const CACHE_NAME = "nidaul-masjid-pro-v70-full-audio";
const ASSETS = [
  "./",
  "./index.html",
  "./style.css",
  "./app.js",
  "./manifest.json",
  "./config.json",
  "./audio/asmaul_husna.mp3",
  "./audio/doa_adzan.mp3",
  "./audio/Ajan Masjid Kampung.ogg",
  "./audio/Arhamarrohimin Tarhim.ogg",
  "./audio/Azan Sbh Syahdu.ogg",
  "./audio/Tarhim Mahmud Al Hussary.ogg",
  "./audio/adzan.ogg",
  "./audio/adzan_subuh.ogg",
  "./audio/aljumuah.ogg",
  "./audio/bel_pendek.mp3",
  "./audio/bumper.mp3",
  "./audio/dhuha.ogg",
  "./audio/iqomah.mp3",
  "./audio/peringatan terbit.mp3",
  "./audio/tahajud.mp3",
  "./audio/tarhim.ogg",
  "./audio/terbit.mp3",
  "./audio/yasin.ogg",
  "./audio/murottal/adzan_makkah_standar.mp3",
  "./audio/murottal/ashar-01.ogg",
  "./audio/murottal/dzuhur-01.ogg",
  "./audio/murottal/isya-01.ogg",
  "./audio/murottal/maghrib-01.ogg",
  "./audio/murottal/subuh-01.ogg"
];

self.addEventListener("install", e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(async c => {
      for (const url of ASSETS) {
        try { await c.add(encodeURI(url)); } catch (err) {}
      }
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", e => {
  e.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
