// NURUL MASJID PRO V61 — JAM DIGITAL MASJID & ASISTEN IBADAH HARIAN RAMAH TUNANETRA
// PENGEMBANG RESMI: Nur & Mas Yeni Setiawan (WhatsApp: 0877-8158-6983)
// DILINDUNGI UNDANG-UNDANG RI NOMOR 28 TAHUN 2014 TENTANG HAK CIPTA

const P_LIST = [
  "Jawa Timur", "Jawa Tengah & DIY", "DKI Jakarta", "Jawa Barat", "Banten",
  "Aceh", "Sumatera Utara", "Sumatera Barat", "Riau", "Kepulauan Riau",
  "Jambi", "Sumatera Selatan", "Kepulauan Bangka Belitung", "Bengkulu", "Lampung",
  "Bali", "Nusa Tenggara Barat", "Nusa Tenggara Timur",
  "Kalimantan Barat", "Kalimantan Tengah", "Kalimantan Selatan", "Kalimantan Timur", "Kalimantan Utara",
  "Sulawesi Utara", "Gorontalo", "Sulawesi Tengah", "Sulawesi Barat", "Sulawesi Selatan", "Sulawesi Tenggara",
  "Maluku", "Maluku Utara",
  "Papua", "Papua Barat", "Papua Selatan", "Papua Tengah", "Papua Pegunungan", "Papua Barat Daya"
];
const K_DATA = {
  "Jawa Timur": ["Situbondo", "Banyuwangi", "Bondowoso", "Jember", "Probolinggo", "Pasuruan", "Lumajang", "Malang", "Sidoarjo", "Gresik", "Mojokerto", "Jombang", "Nganjuk", "Madiun", "Magetan", "Ngawi", "Ponorogo", "Pacitan", "Trenggalek", "Tulungagung", "Blitar", "Kediri", "Bojonegoro", "Tuban", "Lamongan", "Bangkalan", "Sampang", "Pamekasan", "Sumenep", "Kota Surabaya", "Kota Malang", "Kota Batu", "Kota Probolinggo", "Kota Pasuruan", "Kota Mojokerto", "Kota Kediri", "Kota Blitar", "Kota Madiun"],
  "Jawa Tengah & DIY": ["Banjarnegara", "Banyumas", "Batang", "Blora", "Boyolali", "Brebes", "Cilacap", "Demak", "Grobogan", "Jepara", "Karanganyar", "Kebumen", "Kendal", "Klaten", "Kudus", "Magelang", "Pati", "Pekalongan", "Pemalang", "Purbalingga", "Purworejo", "Rembang", "Semarang", "Sragen", "Sukoharjo", "Tegal", "Temanggung", "Wonogiri", "Wonosobo", "Kota Magelang", "Kota Pekalongan", "Kota Salatiga", "Kota Semarang", "Kota Surakarta", "Kota Tegal", "Bantul", "Gunungkidul", "Kulon Progo", "Sleman", "Kota Yogyakarta"],
  "DKI Jakarta": ["Jakarta Pusat", "Jakarta Selatan", "Jakarta Timur", "Jakarta Barat", "Jakarta Utara", "Kepulauan Seribu"],
  "Jawa Barat": ["Bandung", "Bandung Barat", "Bekasi", "Bogor", "Ciamis", "Cianjur", "Cirebon", "Garut", "Indramayu", "Karawang", "Kuningan", "Majalengka", "Pangandaran", "Purwakarta", "Subang", "Sukabumi", "Sumedang", "Tasikmalaya", "Kota Bandung", "Kota Banjar", "Kota Bekasi", "Kota Bogor", "Kota Cimahi", "Kota Cirebon", "Kota Depok", "Kota Sukabumi", "Kota Tasikmalaya"],
  "Banten": ["Lebak", "Pandeglang", "Serang", "Tangerang", "Kota Cilegon", "Kota Serang", "Kota Tangerang", "Kota Tangerang Selatan"],
  "Aceh": ["Aceh Barat", "Aceh Barat Daya", "Aceh Besar", "Aceh Jaya", "Aceh Selatan", "Aceh Singkil", "Aceh Tamiang", "Aceh Tengah", "Aceh Tenggara", "Aceh Timur", "Aceh Utara", "Bener Meriah", "Bireuen", "Gayo Lues", "Nagan Raya", "Pidie", "Pidie Jaya", "Simeulue", "Kota Banda Aceh", "Kota Langsa", "Kota Lhokseumawe", "Kota Sabang", "Kota Subulussalam"],
  "Sumatera Utara": ["Asahan", "Batu Bara", "Dairi", "Deli Serdang", "Humbang Hasundutan", "Karo", "Labuhanbatu", "Labuhanbatu Selatan", "Labuhanbatu Utara", "Langkat", "Mandailing Natal", "Nias", "Nias Barat", "Nias Selatan", "Nias Utara", "Padang Lawas", "Padang Lawas Utara", "Pakpak Bharat", "Samosir", "Serdang Bedagai", "Simalungun", "Tapanuli Selatan", "Tapanuli Tengah", "Tapanuli Utara", "Toba", "Kota Binjai", "Kota Gunungsitoli", "Kota Medan", "Kota Padangsidimpuan", "Kota Pematangsiantar", "Kota Sibolga", "Kota Tanjungbalai", "Kota Tebing Tinggi"],
  "Sumatera Barat": ["Agam", "Dharmasraya", "Kepulauan Mentawai", "Lima Puluh Kota", "Padang Pariaman", "Pasaman", "Pasaman Barat", "Pesisir Selatan", "Sijunjung", "Solok", "Solok Selatan", "Tanah Datar", "Kota Bukittinggi", "Kota Padang", "Kota Padang Panjang", "Kota Pariaman", "Kota Payakumbuh", "Kota Sawahlunto", "Kota Solok"],
  "Riau": ["Bengkalis", "Indragiri Hilir", "Indragiri Hulu", "Kampar", "Kepulauan Meranti", "Kuantan Singingi", "Pelalawan", "Rokan Hilir", "Rokan Hulu", "Siak", "Kota Dumai", "Kota Pekanbaru"],
  "Kepulauan Riau": ["Bintan", "Karimun", "Kepulauan Anambas", "Lingga", "Natuna", "Kota Batam", "Kota Tanjungpinang"],
  "Jambi": ["Batanghari", "Bungo", "Kerinci", "Merangin", "Muaro Jambi", "Sarolangun", "Tanjung Jabung Barat", "Tanjung Jabung Timur", "Tebo", "Kota Jambi", "Kota Sungai Penuh"],
  "Sumatera Selatan": ["Banyuasin", "Empat Lawang", "Lahat", "Muara Enim", "Musi Banyuasin", "Musi Rawas", "Musi Rawas Utara", "Ogan Ilir", "Ogan Komering Ilir", "Ogan Komering Ulu", "Ogan Komering Ulu Selatan", "Ogan Komering Ulu Timur", "Penukal Abab Lematang Ilir", "Kota Lubuklinggau", "Kota Pagar Alam", "Kota Palembang", "Kota Prabumulih"],
  "Kepulauan Bangka Belitung": ["Bangka", "Bangka Barat", "Bangka Selatan", "Bangka Tengah", "Belitung", "Belitung Timur", "Kota Pangkalpinang"],
  "Bengkulu": ["Bengkulu Selatan", "Bengkulu Tengah", "Bengkulu Utara", "Kaur", "Kepahiang", "Lebong", "Mukomuko", "Rejang Lebong", "Seluma", "Kota Bengkulu"],
  "Lampung": ["Lampung Barat", "Lampung Selatan", "Lampung Tengah", "Lampung Timur", "Lampung Utara", "Mesuji", "Pesawaran", "Pesisir Barat", "Pringsewu", "Tanggamus", "Tulang Bawang", "Tulang Bawang Barat", "Way Kanan", "Kota Bandar Lampung", "Kota Metro"],
  "Bali": ["Badung", "Bangli", "Buleleng", "Gianyar", "Jembrana", "Karangasem", "Klungkung", "Tabanan", "Kota Denpasar"],
  "Nusa Tenggara Barat": ["Bima", "Dompu", "Lombok Barat", "Lombok Tengah", "Lombok Timur", "Lombok Utara", "Sumbawa", "Sumbawa Barat", "Kota Bima", "Kota Mataram"],
  "Nusa Tenggara Timur": ["Alor", "Belu", "Ende", "Flores Timur", "Kupang", "Lembata", "Malaka", "Manggarai", "Manggarai Barat", "Manggarai Timur", "Nagekeo", "Ngada", "Rote Ndao", "Sabu Raijua", "Sikka", "Sumba Barat", "Sumba Barat Daya", "Sumba Tengah", "Sumba Timur", "Timor Tengah Selatan", "Timor Tengah Utara", "Kota Kupang"],
  "Kalimantan Barat": ["Bengkayang", "Kapuas Hulu", "Kayong Utara", "Ketapang", "Kubu Raya", "Landak", "Melawi", "Mempawah", "Sambas", "Sanggau", "Sekadau", "Sintang", "Kota Pontianak", "Kota Singkawang"],
  "Kalimantan Tengah": ["Barito Selatan", "Barito Timur", "Barito Utara", "Gunung Mas", "Kapuas", "Katingan", "Kotawaringin Barat", "Kotawaringin Timur", "Lamandau", "Murung Raya", "Pulang Pisau", "Seruyan", "Sukamara", "Kota Palangka Raya"],
  "Kalimantan Selatan": ["Balangan", "Banjar", "Barito Kuala", "Hulu Sungai Selatan", "Hulu Sungai Tengah", "Hulu Sungai Utara", "Kotabaru", "Tabalong", "Tanah Bumbu", "Tanah Laut", "Tapin", "Kota Banjarbaru", "Kota Banjarmasin"],
  "Kalimantan Timur": ["Berau", "Kutai Barat", "Kutai Kartanegara", "Kutai Timur", "Mahakam Ulu", "Paser", "Penajam Paser Utara", "Kota Balikpapan", "Kota Bontang", "Kota Samarinda"],
  "Kalimantan Utara": ["Bulungan", "Malinau", "Nunukan", "Tana Tidung", "Kota Tarakan"],
  "Sulawesi Utara": ["Bolaang Mongondow", "Bolaang Mongondow Selatan", "Bolaang Mongondow Timur", "Bolaang Mongondow Utara", "Kepulauan Sangihe", "Kepulauan Siau Tagulandang Biaro", "Kepulauan Talaud", "Minahasa", "Minahasa Selatan", "Minahasa Tenggara", "Minahasa Utara", "Kota Bitung", "Kota Kotamobagu", "Kota Manado", "Kota Tomohon"],
  "Gorontalo": ["Boalemo", "Bone Bolango", "Gorontalo", "Gorontalo Utara", "Pohuwato", "Kota Gorontalo"],
  "Sulawesi Tengah": ["Banggai", "Banggai Kepulauan", "Banggai Laut", "Buol", "Donggala", "Morowali", "Morowali Utara", "Parigi Moutong", "Poso", "Sigi", "Tojo Una-Una", "Toli-Toli", "Kota Palu"],
  "Sulawesi Barat": ["Majene", "Mamasa", "Mamuju", "Mamuju Tengah", "Pasangkayu", "Polewali Mandar"],
  "Sulawesi Selatan": ["Bantaeng", "Barru", "Bone", "Bulukumba", "Enrekang", "Gowa", "Jeneponto", "Kepulauan Selayar", "Luwu", "Luwu Timur", "Luwu Utara", "Maros", "Pangkajene dan Kepulauan", "Pinrang", "Sidenreng Rappang", "Sinjai", "Soppeng", "Takalar", "Tana Toraja", "Toraja Utara", "Wajo", "Kota Makassar", "Kota Palopo", "Kota Parepare"],
  "Sulawesi Tenggara": ["Bombana", "Buton", "Buton Selatan", "Buton Tengah", "Buton Utara", "Kolaka", "Kolaka Timur", "Kolaka Utara", "Konawe", "Konawe Kepulauan", "Konawe Selatan", "Konawe Utara", "Muna", "Muna Barat", "Wakatobi", "Kota Baubau", "Kota Kendari"],
  "Maluku": ["Buru", "Buru Selatan", "Kepulauan Aru", "Kepulauan Tanimbar", "Maluku Barat Daya", "Maluku Tengah", "Maluku Tenggara", "Seram Bagian Barat", "Seram Bagian Timur", "Kota Ambon", "Kota Tual"],
  "Maluku Utara": ["Halmahera Barat", "Halmahera Selatan", "Halmahera Tengah", "Halmahera Timur", "Halmahera Utara", "Kepulauan Sula", "Pulau Morotai", "Pulau Taliabu", "Kota Ternate", "Kota Tidore Kepulauan"],
  "Papua": ["Biak Numfor", "Jayapura", "Keerom", "Kepulauan Yapen", "Mamberamo Raya", "Sarmi", "Supiori", "Waropen", "Kota Jayapura"],
  "Papua Barat": ["Fakfak", "Kaimana", "Manokwari", "Manokwari Selatan", "Pegunungan Arfak", "Teluk Bintuni", "Teluk Wondama"],
  "Papua Selatan": ["Asmat", "Boven Digoel", "Mappi", "Merauke"],
  "Papua Tengah": ["Deiyai", "Dogiyai", "Intan Jaya", "Mimika", "Nabire", "Paniai", "Puncak", "Puncak Jaya"],
  "Papua Pegunungan": ["Jayawijaya", "Lanny Jaya", "Mamberamo Tengah", "Nduga", "Pegunungan Bintang", "Tolikara", "Yahukimo", "Yalimo"],
  "Papua Barat Daya": ["Maybrat", "Raja Ampat", "Sorong", "Sorong Selatan", "Tambrauw", "Kota Sorong"]
};

const KEC_SITUBONDO_URUT = ["Situbondo", "Panji", "Panarukan", "Kapongan", "Mangaran", "Kendit", "Bungatan", "Mlandingan", "Suboh", "Besuki", "Banyuglugur", "Jatibanteng", "Sumbermalang", "Arjasa", "Jangkar", "Asembagus", "Banyuputih"];
const DATA_SITUBONDO_LENGKAP = {
  "Situbondo": {
    "lat": -7.7062,
    "lon": 114.0095,
    "desa": [
      "Kelurahan Dawuhan",
      "Kelurahan Patokan",
      "Desa Kalibagor",
      "Desa Kotakan",
      "Desa Olean",
      "Desa Talkandang"
    ]
  },
  "Panji": {
    "lat": -7.716,
    "lon": 114.035,
    "desa": [
      "Kelurahan Mimbaan",
      "Kelurahan Ardirejo",
      "Desa Panji Lor",
      "Desa Panji Kidul",
      "Desa Sliwung",
      "Desa Juglangan",
      "Desa Klampokan",
      "Desa Tokelan",
      "Desa Battal",
      "Desa Curah Jeru",
      "Desa Tenggir",
      "Desa Kayu Putih"
    ]
  },
  "Panarukan": {
    "lat": -7.702,
    "lon": 113.953,
    "desa": [
      "Desa Kilensari",
      "Desa Wringinanom",
      "Desa Sumberkolak",
      "Desa Paowan",
      "Desa Peleyan",
      "Desa Gelung",
      "Desa Alasmalang",
      "Desa Duwet"
    ]
  },
  "Kapongan": {
    "lat": -7.694,
    "lon": 114.088,
    "desa": [
      "Desa Kapongan",
      "Desa Seletreng",
      "Desa Landangan",
      "Desa Wonokoyo",
      "Desa Gebangan",
      "Desa Pokaan",
      "Desa Pejagan",
      "Desa Kandang",
      "Desa Curah Cottok",
      "Desa Kesambi Rampak"
    ]
  },
  "Mangaran": {
    "lat": -7.669,
    "lon": 114.048,
    "desa": [
      "Desa Mangaran",
      "Desa Tanjung Glugur",
      "Desa Tanjung Kamal",
      "Desa Tanjung Pecinan",
      "Desa Semiring",
      "Desa Trebungan"
    ]
  },
  "Kendit": {
    "lat": -7.729,
    "lon": 113.918,
    "desa": [
      "Desa Kendit",
      "Desa Klatakan",
      "Desa Balung",
      "Desa Kukusan",
      "Desa Bugeman",
      "Desa Rajekwesi",
      "Desa Tambak Ukir"
    ]
  },
  "Bungatan": {
    "lat": -7.732,
    "lon": 113.829,
    "desa": [
      "Desa Bungatan",
      "Desa Pasir Putih",
      "Desa Bletok",
      "Desa Mlandingan Wetan",
      "Desa Patemon",
      "Desa Selowogo",
      "Desa Sumbertengah"
    ]
  },
  "Mlandingan": {
    "lat": -7.759,
    "lon": 113.776,
    "desa": [
      "Desa Mlandingan Kulon",
      "Desa Selomukti",
      "Desa Sumber Pinang",
      "Desa Sumberanyar",
      "Desa Trebungan",
      "Desa Alas Bayur",
      "Desa Campoan"
    ]
  },
  "Suboh": {
    "lat": -7.755,
    "lon": 113.738,
    "desa": [
      "Desa Suboh",
      "Desa Buduan",
      "Desa Dawuhan",
      "Desa Gunung Malang",
      "Desa Gunung Putri",
      "Desa Cemara",
      "Desa Ketah",
      "Desa Mojodungkul"
    ]
  },
  "Besuki": {
    "lat": -7.7345,
    "lon": 113.6895,
    "desa": [
      "Desa Besuki",
      "Desa Demung",
      "Desa Jetis",
      "Desa Kalimas",
      "Desa Widoropayung",
      "Desa Bloro",
      "Desa Langkap",
      "Desa Pesisir",
      "Desa Blimbing",
      "Desa Sumberejo"
    ]
  },
  "Banyuglugur": {
    "lat": -7.734,
    "lon": 113.649,
    "desa": [
      "Desa Banyuglugur",
      "Desa Kalianget",
      "Desa Kalisari",
      "Desa Lubawang",
      "Desa Selobanteng",
      "Desa Telempong",
      "Desa Tepos"
    ]
  },
  "Jatibanteng": {
    "lat": -7.818,
    "lon": 113.662,
    "desa": [
      "Desa Jatibanteng",
      "Desa Curahsuri",
      "Desa Kembangsari",
      "Desa Pategalan",
      "Desa Patemon",
      "Desa Semambung",
      "Desa Sumberanyar",
      "Desa Wringinanom"
    ]
  },
  "Sumbermalang": {
    "lat": -7.886,
    "lon": 113.654,
    "desa": [
      "Desa Tlogosari",
      "Desa Plalangan",
      "Desa Sumberargo",
      "Desa Taman",
      "Desa Alastengah",
      "Desa Tamankursi",
      "Desa Baderan",
      "Desa Kalirejo",
      "Desa Tamansari"
    ]
  },
  "Arjasa": {
    "lat": -7.728,
    "lon": 114.115,
    "desa": [
      "Desa Arjasa",
      "Desa Lamongan",
      "Desa Kedungdowo",
      "Desa Ketowan",
      "Desa Bayeman",
      "Desa Curah Tatal",
      "Desa Jatisari",
      "Desa Kayumas"
    ]
  },
  "Jangkar": {
    "lat": -7.726,
    "lon": 114.175,
    "desa": [
      "Desa Jangkar",
      "Desa Agel",
      "Desa Palangan",
      "Desa Pesanggrahan",
      "Desa Curah Kalak",
      "Desa Gadingan",
      "Desa Kumbangsari",
      "Desa Sopet"
    ]
  },
  "Asembagus": {
    "lat": -7.749,
    "lon": 114.218,
    "desa": [
      "Desa Asembagus",
      "Desa Gudang",
      "Desa Kedunglo",
      "Desa Wringin Anom",
      "Desa Mojosari",
      "Desa Trigonco",
      "Desa Awar-Awar",
      "Desa Perante",
      "Desa Bantal",
      "Desa Kertosari"
    ]
  },
  "Banyuputih": {
    "lat": -7.778,
    "lon": 114.288,
    "desa": [
      "Desa Banyuputih",
      "Desa Sumberwaru",
      "Desa Sumberejo",
      "Desa Sumberanyar",
      "Desa Wonorejo"
    ]
  }
};



const DATA_BANYUMAS_LENGKAP = {
  "Purwokerto Selatan": {
    "lat": -7.4418, "lon": 109.2392,
    "desa": ["Kelurahan Berkoh", "Kelurahan Karangklesem", "Kelurahan Karangpucung", "Kelurahan Purwokerto Kidul", "Kelurahan Purwokerto Kulon", "Kelurahan Tanjung", "Kelurahan Teluk"]
  },
  "Purwokerto Barat": {
    "lat": -7.4215, "lon": 109.2184,
    "desa": ["Kelurahan Bantarsoka", "Kelurahan Karanglewas Lor", "Kelurahan Kedungwuluh", "Kelurahan Kober", "Kelurahan Pasir Kidul", "Kelurahan Pasirmuncang", "Kelurahan Rejasari"]
  },
  "Purwokerto Timur": {
    "lat": -7.4243, "lon": 109.2512,
    "desa": ["Kelurahan Arcawinangun", "Kelurahan Kranji", "Kelurahan Mersi", "Kelurahan Purwokerto Lor", "Kelurahan Purwokerto Wetan", "Kelurahan Sokanegara"]
  },
  "Purwokerto Utara": {
    "lat": -7.4024, "lon": 109.2435,
    "desa": ["Kelurahan Bancarkembar", "Kelurahan Bobosan", "Kelurahan Grendeng", "Kelurahan Karangwangkal", "Kelurahan Pabuwaran", "Kelurahan Purwanegara", "Kelurahan Sumampir"]
  },
  "Sokaraja": {
    "lat": -7.4582, "lon": 109.2865,
    "desa": ["Desa Banjaranyar", "Desa Banjarsari Kidul", "Desa Jompo Kulon", "Desa Kalikidang", "Desa Karangduren", "Desa Karangkedawung", "Desa Karangnanas", "Desa Karangrau", "Desa Kedondong", "Desa Klahang", "Desa Lemberang", "Desa Pamijen", "Desa Sokaraja Kidul", "Desa Sokaraja Kulon", "Desa Sokaraja Lor", "Desa Sokaraja Tengah", "Desa Sokaraja Wetan", "Desa Wiradadi"]
  },
  "Kembaran": {
    "lat": -7.4196, "lon": 109.2894,
    "desa": ["Desa Bantarwuni", "Desa Bojongsari", "Desa Dukuhwaluh", "Desa Karangsari", "Desaangsoka", "Desa Karangtengah", "Desa Kembaran", "Desa Kramat", "Desa Ledug", "Desa Linggasari", "Desa Pliken", "Desa Purbadana", "Desa Purwodadi", "Desa Sambeng Kulon", "Desa Sambeng Wetan", "Desa Tambaksari Kidul"]
  },
  "Sumbang": {
    "lat": -7.3768, "lon": 109.2742,
    "desa": ["Desa Banjarsari Kulon", "Desa Banjarsari Wetan", "Desa Banteran", "Desa Ciberem", "Desa Datar", "Desa Gandatapa", "Desa Karangcegak", "Desa Karanggintung", "Desa Karangturi", "Desa Kawungcarang", "Desa Kebanggan", "Desa Kedungmalang", "Desa Kotayasa", "Desa Limpakuwus", "Desa Sikapat", "Desa Silado", "Desa Sumbang", "Desa Susukan", "Desa Tambaksogra"]
  },
  "Baturraden": {
    "lat": -7.3256, "lon": 109.2318,
    "desa": ["Desa Karangmangu", "Desa Karangsalam Lor", "Desaチetenger", "Desa Kebumen", "Desa Kemutug Kidul", "Desa Kemutug Lor", "Desa Ketenger", "Desa Kutasari", "Desa Pamijen", "Desa Pandak", "Desa Purwosari", "Desa Rempoah"]
  },
  "Kedungbanteng": {
    "lat": -7.3912, "lon": 109.1985,
    "desa": ["Desa Baseh", "Desa Beji", "Desa Dawuhan Kulon", "Desa Dawuhan Wetan", "Desa Kalikesur", "Desa Kalisalak", "Desa Karangnangka", "Desa Karangsalam Kidul", "Desa Kebocoran", "Desa Kedungbanteng", "Desa Keniten", "Desa Kutaliman", "Desa Melung", "Desa Windujaya"]
  },
  "Karanglewas": {
    "lat": -7.4265, "lon": 109.1792,
    "desa": ["Desa Babakan", "Desa Jipang", "Desa Karanggude Kulon", "Desa Karangkemiri", "Desa Karanglewas Kidul", "Desa Kediri", "Desa Pangebatan", "Desa Pasir Kulon", "Desa Pasir Lor", "Desa Pasir Wetan", "Desa Singasari", "Desa Sunyalangu", "Desa Tamansari"]
  },
  "Cilongok": {
    "lat": -7.4085, "lon": 109.1364,
    "desa": ["Desa Batuanten", "Desa Cikidang", "Desa Cilongok", "Desa Cipete", "Desa Gununglurah", "Desa Jatisaba", "Desa Kalisari", "Desa Karanglo", "Desa Karangtengah", "Desa Kasegeran", "Desa Langgongsari", "Desa Pageraji", "Desa Panembangan", "Desa Panusupan", "Desa Pejogol", "Desa Pernasidi", "Desa Rancamaya", "Desa Sambirata", "Desa Sokawera", "Desa Sudimara"]
  },
  "Ajibarang": {
    "lat": -7.4112, "lon": 109.0695,
    "desa": ["Desa Ajibarang Kulon", "Desa Ajibarang Wetan", "Desa Banjarsari", "Desa Ciberung", "Desa Darmakradenan", "Desa Jingkang", "Desa Kalibenda", "Desa Karangbawang", "Desa Kracak", "Desa Lesmana", "Desa Pancasan", "Desa Pancurendang", "Desa Pandansari", "Desa Sawangan", "Desa Tipar Kidul"]
  },
  "Pekuncen": {
    "lat": -7.3652, "lon": 109.0418,
    "desa": ["Desa Banjaranyar", "Desa Candinegara", "Desa Cibangkong", "Desa Cikawung", "Desa Cikembulan", "Desa Glempang", "Desa Karangkemiri", "Desa Karangklesem", "Desa Krajan", "Desa Kranggan", "Desa Pasiraman Kidul", "Desa Pasiraman Lor", "Desa Pekuncen", "Desa Petahunan", "Desa Semedo", "Desa Tumiyang"]
  },
  "Gumelar": {
    "lat": -7.4284, "lon": 108.9912,
    "desa": ["Desa Cihonje", "Desa Cilangkap", "Desa Gancang", "Desa Gumelar", "Desa Karangkemojing", "Desa Kedungurang", "Desa Paningkaban", "Desa Samudra", "Desa Samudra Kulon", "Desa Tlaga"]
  },
  "Lumbir": {
    "lat": -7.4695, "lon": 108.9562,
    "desa": ["Desa Besuki", "Desa Canduk", "Desa Cidora", "Desa Cingebul", "Desa Cirahab", "Desa Dermaji", "Desa Karanggayam", "Desa Kedunggede", "Desa Lumbir", "Desa Parungkamal"]
  },
  "Wangon": {
    "lat": -7.5152, "lon": 109.0538,
    "desa": ["Desa Banteran", "Desa Cikakak", "Desa Jambu", "Desa Jurangbahas", "Desa Klapagading", "Desa Klapagading Kulon", "Desa Pangadegan", "Desa Randegan", "Desa Rawaheng", "Desa Wangon", "Desa Windunegara", "Desa Wlahar"]
  },
  "Jatilawang": {
    "lat": -7.5284, "lon": 109.1182,
    "desa": ["Desa Adisara", "Desa Bantar", "Desa Gentawangi", "Desa Gunungwetan", "Desa Karanganyar", "Desa Karanglewas", "Desa Kedungwringin", "Desa Margasana", "Desa Pekodokan", "Desa Tinggarjaya", "Desa Tunjung"]
  },
  "Rawalo": {
    "lat": -7.5326, "lon": 109.1745,
    "desa": ["Desa Banjarparakan", "Desa Losari", "Desa Menganti", "Desa Pesawahan", "Desa Rawalo", "Desa Sanggreman", "Desa Sidamulih", "Desa Tambaknegara", "Desa Tipar"]
  },
  "Kebasen": {
    "lat": -7.5368, "lon": 109.2164,
    "desa": ["Desa Adisana", "Desa Bangsa", "Desa Cindaga", "Desa Gambarsari", "Desa Kalisalak", "Desa Kaliwedi", "Desa Karangsari", "Desa Kebasen", "Desa Mandirancan", "Desa Randegan", "Desa Sawangan", "Desa Tumiyang"]
  },
  "Patikraja": {
    "lat": -7.4795, "lon": 109.2148,
    "desa": ["Desa Karanganyar", "Desa Karangendep", "Desa Kedungori", "Desa Kedungrandu", "Desa Kedungwringin", "Desa Kedungwuluh Kidul", "Desa Kedungwuluh Lor", "Desa Notog", "Desa Patikraja", "Desa Pegalongan", "Desa Sawangan Wetan", "Desa Sidabowa", "Desa Sokawera"]
  },
  "Kalibagor": {
    "lat": -7.4842, "lon": 109.2974,
    "desa": ["Desa Kalibagor", "Desa Kalicupak Kidul", "Desa Kalicupak Lor", "Desa Kaliori", "Desa Kalisogra Wetan", "Desa Karangdadap", "Desa Pajerukan", "Desa Pekaja", "Desa Petir", "Desa Srowot", "Desa Suro", "Desa Wlahar Wetan"]
  },
  "Banyumas": {
    "lat": -7.5194, "lon": 109.2942,
    "desa": ["Desa Binangun", "Desa Danaraja", "Desa Dawuhan", "Desa Kalisube", "Desa Karangrau", "Desa Kedunggede", "Desa Kedunguter", "Desa Kejawar", "Desa Papringan", "Desa Pasinggangan", "Desa Pekunden", "Desa Sudagaran"]
  },
  "Somagede": {
    "lat": -7.5318, "lon": 109.3385,
    "desa": ["Desa Kanding", "Desa Kemawi", "Desa Klinting", "Desa Piasa Kulon", "Desa Plana", "Desa Sokawera", "Desa Somagede", "Desa Somakaton", "Desa Tanggeran"]
  },
  "Kemranjen": {
    "lat": -7.5912, "lon": 109.3145,
    "desa": ["Desa Alasmalang", "Desa Grujugan", "Desa Karanggintung", "Desa Karangjati", "Desaangsalam", "Desa Kebarongan", "Desa Kecila", "Desa Kedungpring", "Desa Nusamangir", "Desa Pageralang", "Desa Petarangan", "Desa Sibalung", "Desa Sibrama", "Desa Sidamulya", "Desa Sirau"]
  },
  "Sumpiuh": {
    "lat": -7.6148, "lon": 109.3652,
    "desa": ["Kelurahan Kebokura", "Kelurahan Kradenan", "Kelurahan Sumpiuh", "Desa Banjarpanepen", "Desa Bogangin", "Desa Kemiri", "Desa Ketanda", "Desa Kuntili", "Desa Lebeng", "Desa Nusadadi", "Desa Pandak", "Desa Selandaka", "Desa Selanegara", "Desa Karanggedang"]
  },
  "Tambak": {
    "lat": -7.6185, "lon": 109.4126,
    "desa": ["Desa Buniayu", "Desa Gebangsari", "Desa Gumelar Kidul", "Desa Gumelar Lor", "Desa Kamulyan", "Desa Karangpetir", "Desa Karangpucung", "Desa Pesantren", "Desa Plangkapan", "Desa Prembun", "Desa Purwodadi", "Desa Watuagung"]
  }
};

const DATA_KUDUS_LENGKAP = {
  "Kota Kudus": {
    "lat": -6.8048, "lon": 110.8405,
    "desa": ["Kelurahan Barongan", "Kelurahan Burikan", "Kelurahan Damaran", "Kelurahan Demaan", "Kelurahan Demangan", "Kelurahan Glantengan", "Kelurahan Janggalan", "Kelurahan Kaliputu", "Kelurahan Kauman", "Kelurahan Kajeksan", "Kelurahan Kerjasan", "Kelurahan Kramat", "Kelurahan Krandon", "Kelurahan Langgardalem", "Kelurahan Mlati Kidul", "Kelurahan Mlati Lor", "Kelurahan Mlati Norowito", "Kelurahan Nganguk", "Kelurahan Panjunan", "Kelurahan Purwosari", "Kelurahan Rendeng", "Kelurahan Singocandi", "Kelurahan Sunggingan", "Kelurahan Wergu Kulon", "Kelurahan Wergu Wetan"]
  },
  "Jati": {
    "lat": -6.8342, "lon": 110.8385,
    "desa": ["Desa Getaspejaten", "Desa Jati Kulon", "Desa Jati Wetan", "Desa Jepangpakis", "Desa Jetiskapuan", "Desa Loram Kulon", "Desa Loram Wetan", "Desa Megawon", "Desa Ngembal Kulon", "Desa Pasuruhan Kidul", "Desa Pasuruhan Lor", "Desa Ploso", "Desa Tanjungkarang", "Desa Tumpangkrasak"]
  },
  "Kaliwungu": {
    "lat": -6.7895, "lon": 110.7852,
    "desa": ["Desa Bakalankrapyak", "Desa Banget", "Desa Blimbing Kidul", "Desa Gamong", "Desa Garung Kidul", "Desa Garung Lor", "Desa Kaliwungu", "Desa Karangampel", "Desa Kedungdowo", "Desa Mijen", "Desa Papringan", "Desa Prambatan Kidul", "Desa Prambatan Lor", "Desa Setrokalangan", "Desa Sidorekso"]
  },
  "Bae": {
    "lat": -6.7745, "lon": 110.8612,
    "desa": ["Desa Bae", "Desa Bacin", "Desa Dersalam", "Desa Gondangmanis", "Desa Karangbener", "Desa Ngembalrejo", "Desa Panjang", "Desa Pedawang", "Desa Peganjaran", "Desa Purworejo"]
  },
  "Mejobo": {
    "lat": -6.8315, "lon": 110.8895,
    "desa": ["Desa Golantepus", "Desa Gulang", "Desa Hadiwarno", "Desa Jepang", "Desa Jojo", "Desa Kesambi", "Desa Kirig", "Desa Mejobo", "Desa Payaman", "Desa Temulus", "Desa Tenggeles"]
  },
  "Jekulo": {
    "lat": -6.8092, "lon": 110.9285,
    "desa": ["Desa Bulungcangkring", "Desa Bulungkulon", "Desa Gondoharum", "Desa Hadipolo", "Desa Honggosoco", "Desa Jekulo", "Desa Klaling", "Desa Pladen", "Desa Sadang", "Desa Sidomulyo", "Desa Tanjungrejo", "Desa Terban"]
  },
  "Dawe": {
    "lat": -6.7018, "lon": 110.8715,
    "desa": ["Desa Cendono", "Desa Colo", "Desa Cranggang", "Desa Dukuhwaringin", "Desa Glagah Kulon", "Desa Japan", "Desa Kajar", "Desa Kandangmas", "Desa Kuwukan", "Desa Lau", "Desa Margorejo", "Desa Piji", "Desa Puyoh", "Desa Rejosari", "Desa Samirejo", "Desa Soco", "Desa Tergo", "Desa Ternadi"]
  },
  "Undaan": {
    "lat": -6.9045, "lon": 110.7985,
    "desa": ["Desa Berugenjang", "Desa Glagahwaru", "Desa Kalirejo", "Desa Karangrowo", "Desa Kutuk", "Desa Lambangan", "Desa Larikrejo", "Desa Medini", "Desa Ngemplak", "Desa Sambung", "Desa Terangmas", "Desa Undaan Kidul", "Desa Undaan Lor", "Desa Undaan Tengah", "Desa Wates", "Desa Wonosoco"]
  },
  "Gebog": {
    "lat": -6.7312, "lon": 110.8245,
    "desa": ["Desa Besito", "Desa Getasrabi", "Desa Gondosari", "Desa Gribig", "Desa Jurang", "Desa Karangmalang", "Desa Kedungsari", "Desa Klumpit", "Desa Menawan", "Desa Padurenan", "Desa Rahtawu"]
  }
};


const DATA_PATI_LENGKAP = {
  "Pati": {
    "lat": -6.7559, "lon": 111.0380,
    "desa": ["Kelurahan Pati Kidul", "Kelurahan Pati Lor", "Kelurahan Pati Wetan", "Kelurahan Parenggan", "Kelurahan Kalidoro", "Desa Blaru", "Desa Dengkek", "Desa Gajahmati", "Desa Geritan", "Desa Kutoharjo", "Desa Mulyoharjo", "Desa Mustokoharjo", "Desa Ngarus", "Desa Ngepungrojo", "Desa Panjunan", "Desa Payang", "Desa Plangitan", "Desa Puri", "Desa Purworejo", "Desa Sarirejo", "Desa Semampir", "Desa Sidokerto", "Desa Sidoharjo", "Desa Sinoman", "Desa Sugiharjo", "Desa Tambaharjo", "Desa Tambahsari", "Desa Widorokandang", "Desa Winong"]
  },
  "Juwana": {
    "lat": -6.7150, "lon": 111.1514,
    "desa": ["Desa Agungmulyo", "Desa Bajomulyo", "Desa Bakarankulon", "Desa Bakaranwetan", "Desa Bendar", "Desa Bringin", "Desa Bumirejo", "Desa Doropayung", "Desa Dukutalit", "Desa Gadingrejo", "Desa Genengmulyo", "Desa Growongkidul", "Desa Growonglor", "Desa Jepuro", "Desa Karang", "Desa Karangrejo", "Desa Kauman", "Desa Kebonsawahan", "Desa Kedungpancing", "Desa Ketip", "Desa Kudukeras", "Desa Langenharjo", "Desa Margomulyo", "Desa Mintomulyo", "Desa Pajeksan", "Desa Pekuwon", "Desa Sejomulyo", "Desa Tluwah", "Desa Trimulyo"]
  },
  "Tayu": {
    "lat": -6.5408, "lon": 111.0528,
    "desa": ["Desa Bendokaton Kidul", "Desa Bulungan", "Desa Dororejo", "Desa Jepat Kidul", "Desa Jepat Lor", "Desa Kalikalong", "Desa Keboromo", "Desa Kedungsari", "Desarowobombo", "Desa Luwang", "Desa Margomulyo", "Desa Pakis", "Desa Pondowan", "Desa Pundenrejo", "Desa Purwokerto", "Desa Sambiroto", "Desa Sendangrejo", "Desa Tayukulon", "Desa Tayuwetan", "Desa Tendas", "Desa Tunggulsari"]
  },
  "Kayen": {
    "lat": -6.8975, "lon": 110.9769,
    "desa": ["Desa Beketel", "Desa Boloagung", "Desa Brati", "Desa Durensawit", "Desa Jatiroto", "Desa Jimbaran", "Desa Kayen", "Desa Pasuruhan", "Desa Pesagi", "Desa Purwokerto", "Desa Rogomulyo", "Desa Slungkep", "Desa Srikaton", "Desa Sumbersari", "Desa Sundoluhur", "Desa Talun", "Desa Trimulyo"]
  },
  "Winong": {
    "lat": -6.8358, "lon": 111.1136,
    "desa": ["Desa Bageng", "Desa Blingijati", "Desa Bringinwareng", "Desa Bumiharjo", "Desa Danyangmulyo", "Desa Degan", "Desa Godo", "Desa Gunungpanti", "Desa Guyangan", "Desa Karangkonang", "Desa Karangsumber", "Desa Kebolampang", "Desa Kebowan", "Desa Klecoregonang", "Desa Kropak", "Desa Kudur", "Desa Mintorahayu", "Desa Padangan", "Desa Pagendisan", "Desa Pekalongan", "Desa Pohgading", "Desa Pulorejo", "Desa Sarimulyo", "Desa Serutsadang", "Desa Sugihan", "Desa Sumbermulyo", "Desa Tanggel", "Desa Tawangrejo", "Desa Tlogorejo", "Desa Winong"]
  },
  "Margorejo": {
    "lat": -6.7622, "lon": 110.9964,
    "desa": ["Desa Badegan", "Desa Banyuurip", "Desa Bumirejo", "Desa Dadirejo", "Desa Jambean Kidul", "Desa Jimbaran", "Desa Langenharjo", "Desarik", "Desa Margorejo", "Desa Metaraman", "Desa Muktiharjo", "Desa Ngawen", "Desa Pegandan", "Desa Penambuhan", "Desa Sokokulon", "Desa Sukobubuk", "Desa Sukoharjo", "Desa Wangunrejo"]
  },
  "Gembong": {
    "lat": -6.7069, "lon": 110.9553,
    "desa": ["Desa Bageng", "Desa Bermi", "Desa Gembong", "Desa Kedungbulus", "Desa Ketanggan", "Desa Klakahkasihan", "Desa Plukaran", "Desa Pohgading", "Desa Semirejo", "Desa Sitiluhur", "Desa Wonosekar"]
  },
  "Tlogowungu": {
    "lat": -6.6897, "lon": 111.0022,
    "desa": ["Desa Cabak", "Desa Gunungsari", "Desa Guwo", "Desa Klumpit", "Desa Lahar", "Desa Purwosari", "Desa Regaloh", "Desa Sambirejo", "Desa Sumbermulyo", "Desa Suwatu", "Desa Tajungsari", "Desa Tamansari", "Desa Tlogorejo", "Desa Tlogosari", "Desa Wonorejo"]
  },
  "Wedarijaksa": {
    "lat": -6.6828, "lon": 111.0908,
    "desa": ["Desa Bangsalrejo", "Desa Bumiayu", "Desa Jatimulyo", "Desa Jetak", "Desa Jontro", "Desa Kepoh", "Desa Margorejo", "Desa Ngurenrejo", "Desa Ngurensiti", "Desa Pagerharjo", "Desa Panggungroyom", "Desa Sidoharjo", "Desa Sukoharjo", "Desa Suwaduk", "Desa Tawangharjo", "Desa Tlogoharum", "Desa Trangkil", "Desa Wedarijaksa"]
  },
  "Trangkil": {
    "lat": -6.6525, "lon": 111.0956,
    "desa": ["Desa Asempapan", "Desa Guyangan", "Desa Kadilangu", "Desa Kajar", "Desa Karanglegi", "Desa Karangwage", "Desa Kertomulyo", "Desa Ketanen", "Desa Krandan", "Desa Mojoagung", "Desa Pasucen", "Desa Rejoagung", "Desa Sambilawang", "Desa Tegalharjo", "Desa Tlutup", "Desa Trangkil"]
  },
  "Batangan": {
    "lat": -6.7058, "lon": 111.2339,
    "desa": ["Desa Batursari", "Desa Bulumulyo", "Desa Bumimulyo", "Desa Gajahkumpul", "Desa Gunungsari", "Desa Jembangan", "Desa Kedalon", "Desa Ketitangwetan", "Desa Klayusiwalan", "Desa Kuniran", "Desa Lengkong", "Desa Mangunlegi", "Desa Ngening", "Desa Pecangaan", "Desa Raci", "Desa Sukoagung", "Desa Tlogomojo", "Desa Tompegunung"]
  },
  "Jaken": {
    "lat": -6.7936, "lon": 111.2367,
    "desa": ["Desa Aromanis", "Desa Boto", "Desa Kebonturi", "Desa Lundo", "Desa Manjang", "Desa Mantingan", "Desa Mojolampir", "Desa Mojoluhur", "Desa Ronggo", "Desa Sidoluhur", "Desa Sidomukti", "Desa Srikaton", "Desa Sriwedari", "Desa Sukorukun", "Desa Sumberagung", "Desa Sumberan", "Desa Sumberarum", "Desa Sumberrejo", "Desa Tamansari", "Desa Tegalarum", "Desa Trikoyo"]
  },
  "Jakenan": {
    "lat": -6.7592, "lon": 111.1603,
    "desa": ["Desa Bungasrejo", "Desa Dukuhmulyo", "Desa Glonggong", "Desa Jakenan", "Desa Jatisari", "Desa Kalimulyo", "Desa Karangrejo Lor", "Desa Karangrowo", "Desa Kedungmulyo", "Desa Mantingan Tengah", "Desa Ngastorejo", "Desa Plosojenar", "Desa Puluhan Tengah", "Desa Sembaturagung", "Desa Sendangsoko", "Desa Sidoarum", "Desa Sidomulyo", "Desa Sonorejo", "Desa Tambahmulyo", "Desa Tanjungsari", "Desa Tlogorejo", "Desa Tondokerto", "Desa Tondomulyo"]
  },
  "Pucakwangi": {
    "lat": -6.8683, "lon": 111.1678,
    "desa": ["Desa Bodeh", "Desa Grogolsari", "Desa Jetak", "Desa Karangrejo", "Desa Karangwotan", "Desa Kepohkencono", "Desa Kletek", "Desa Lumbungmas", "Desa Mencon", "Desa Mojoagung", "Desa Pelemgede", "Desa Plosorejo", "Desa Pucakwangi", "Desa Sitimulyo", "Desa Sokopuluhan", "Desa Tanjungsekar", "Desa Tegalwero", "Desa Terteg", "Desa Triguno", "Desa Wateshaji"]
  },
  "Gabus": {
    "lat": -6.8281, "lon": 111.0453,
    "desa": ["Desa Babalan", "Desa Banjarsari", "Desa Bogotanjung", "Desa Gabus", "Desa Gebang", "Desa Gempolsari", "Desa Karaban", "Desa Kosekan", "Desa Koripandriyo", "Desa Koryokalangan", "Desa Mintobasuki", "Desa Mojolawaran", "Desa Pantirejo", "Desa Penanggungan", "Desa Plumbungan", "Desa Sambirejo", "Desa Sugihrejo", "Desa Sunggingwarno", "Desa Tambahmulyo", "Desa Tanjang", "Desa Tanjunganom", "Desa Tlogoayu", "Desa Wuwur"]
  },
  "Tambakromo": {
    "lat": -6.8856, "lon": 111.0506,
    "desa": ["Desa Angkatan Kidul", "Desa Angkatan Lor", "Desa Karangawen", "Desa Karangmulyo", "Desa Karangwono", "Desa Keben", "Desa Kedalingan", "Desa Larangan", "Desa Maitan", "Desa Mangunrekso", "Desa Mojomulyo", "Desa Pakis", "Desa Sinomwidodo", "Desa Sitirejo", "Desa Tambahagung", "Desa Tambaharjo", "Desa Tambakromo", "Desa Wukirsari"]
  },
  "Sukolilo": {
    "lat": -6.9242, "lon": 110.9039,
    "desa": ["Desa Baturejo", "Desa Cengkalsewu", "Desa Gadudero", "Desa Kasiyan", "Desa Kedumulyo", "Desa Kedungwinong", "Desa Kuwawur", "Desa Pakem", "Desa Porangparing", "Desa Prawoto", "Desa Sukolilo", "Desa Sumbersoko", "Desa Tompegunung", "Desa Wegil", "Desa Wotan"]
  },
  "Margoyoso": {
    "lat": -6.6056, "lon": 111.0669,
    "desa": ["Desa Bulumanis Kidul", "Desa Bulumanis Lor", "Desa Cebolek Kidul", "Desa Kajen", "Desa Kertomulyo", "Desa Langgenharjo", "Desa Margotuhu Kidul", "Desa Margoyoso", "Desa Ngemplak Kidul", "Desa Ngemplak Lor", "Desa Pangkalan", "Desa Pohijo", "Desa Purwodadi", "Desa Purworejo", "Desa Sekarjalak", "Desa Semerak", "Desa Sidomukti", "Desa Soneyan", "Desa Tanjungrejo", "Desa Tegalarum", "Desa Tunjungrejo", "Desa Waturoyo"]
  },
  "Gunungwungkal": {
    "lat": -6.5647, "lon": 110.9767,
    "desa": ["Desa Bancak", "Desa Gadu", "Desa Gajihan", "Desa Giling", "Desa Gulangpungge", "Desa Gunungwungkal", "Desa Jembulwuwuh", "Desa Jepalo", "Desa Perdopo", "Desa Pesagen", "Desa Sampok", "Desa Sidomulyo", "Desa Sumberejo", "Desa Sumberrejo", "Desa Ngetuk"]
  },
  "Cluwak": {
    "lat": -6.5194, "lon": 110.9619,
    "desa": ["Desa Bleber", "Desa Gerit", "Desa Gesengan", "Desa Karangsari", "Desa Medani", "Desa Mojo", "Desa Ngablak", "Desa Ngawen", "Desa Payak", "Desa Plaosan", "Desa Sentul", "Desa Sirahan", "Desa Sumur"]
  },
  "Dukuhseti": {
    "lat": -6.4478, "lon": 111.0319,
    "desa": ["Desa Alasdowo", "Desa Bakalan", "Desa Banyutowo", "Desa Dukuhseti", "Desa Dumpil", "Desa Grogolan", "Desa Kembang", "Desa Kenanti", "Desa Ngagel", "Desa Puncel", "Desa Tegalombo", "Desa Wedusan"]
  }
};

const DATA_KECAMATAN_NASIONAL = {
  // JAWA TIMUR
  "Banyuwangi": ["Banyuwangi", "Giri", "Glagah", "Kalipuro", "Kabat", "Rogojampi", "Blimbingsari", "Srono", "Muncar", "Cluring", "Gambiran", "Genteng", "Glenmore", "Kalibaru", "Sempu", "Singojuruh", "Songgon", "Licin", "Wongsorejo", "Pesanggaran", "Siliragung", "Bangorejo", "Purwoharjo", "Tegaldlimo", "Tegalsari"],
  "Bondowoso": ["Bondowoso", "Tenggarang", "Wonosari", "Tapen", "Sukosari", "Sumberwringin", "Ijen", "Botolinggo", "Prajekan", "Cermee", "Klabang", "Tegalampel", "Tamankrocok", "Wringin", "Curahdami", "Binakal", "Pakem", "Grujugan", "Maesan", "Tamanan", "Jambesari Darus Sholah", "Pujer", "Tlogosari"],
  "Jember": ["Kaliwates", "Sumbersari", "Patrang", "Arjasa", "Jelbuk", "Pakusari", "Kalisat", "Ledokombo", "Sumberjambe", "Sukowono", "Silo", "Mayang", "Mumbulsari", "Tempurejo", "Ajung", "Rambipuji", "Panti", "Sukorambi", "Jenggawah", "Ambulu", "Wuluhan", "Balung", "Umbulsari", "Semboro", "Jombang", "Sumberbaru", "Tanggul", "Bangsalsari", "Puger", "Gumukmas", "Kencong"],
  "Probolinggo": ["Kraksaan", "Paiton", "Besuk", "Gading", "Pakuniran", "Kotaanyar", "Krejengan", "Pajarakan", "Maron", "Gending", "Dringu", "Leces", "Tegalsiwalan", "Banyuanyar", "Tiris", "Krucil", "Wonomerto", "Lumbang", "Tongas", "Sumberasih", "Sukapura", "Sumber", "Kuripan", "Bantaran"],
  "Pasuruan": ["Bangil", "Beji", "Gempol", "Pandaan", "Prigen", "Sukorejo", "Purwosari", "Purwodadi", "Lawang", "igen", "Rembang", "Kraton", "Pohjentrek", "Gondangwetan", "Rejoso", "Winongan", "Grati", "Lekok", "Nguling", "Lumbang", "Pasrepan", "Kejayan", "Wonorejo", "Tutur", "Puspo", "Tosari"],
  "Lumajang": ["Lumajang", "Sukodono", "Sumbersuko", "Tekung", "Kunir", "Yosowilangun", "Rowokangkung", "Jatiroto", "Randuagung", "Klakah", "Ranuyoso", "Kedungjajang", "Gucialit", "Padang", "Senduro", "Pasrujambe", "Tempeh", "Pasirian", "Candipuro", "Pronojiwo", "Tempursari"],
  "Malang": ["Kepanjen", "Singosari", "Lawang", "Karangploso", "Dau", "Pujon", "Ngantang", "Kasembon", "Pakis", "Jabung", "Tumpang", "Poncokusumo", "Wajak", "Tajinan", "Bululawang", "Gondanglegi", "Pagelaran", "Turen", "Dampit", "Tirtoyudo", "Ampelgading", "Sumbermanjing Wetan", "Gedangan", "Bantur", "Pagak", "Donomulyo", "Kalipare", "Sumberpucung", "Kromengan", "Ngajum", "Wonosari", "Wagir", "Pakisaji"],
  "Sidoarjo": ["Sidoarjo", "Buduran", "Candi", "Porong", "Krembung", "Tulangan", "Tanggulangin", "Jabon", "Waru", "Gedangan", "Sedati", "Taman", "Sukodono", "Krian", "Balongbendo", "Tarik", "Prambon", "Wonoayu"],
  "Gresik": ["Gresik", "Kebomas", "Manyar", "Bungah", "Sidayu", "Dukun", "Panceng", "Ujungpangkah", "Driyorejo", "Wringinanom", "Kedamean", "Menganti", "Cerme", "Benjeng", "Balongpanggang", "Duduksampeyan", "Sangkapura", "Tambak"],
  "Mojokerto": ["Mojosari", "Pungging", "Ngoro", "Trawas", "Pacet", "Gondang", "Jatirejo", "Dlanggu", "Kutorejo", "Bangsal", "Mojoanyar", "Puri", "Trowulan", "Sooko", "Gedeg", "Kemlagi", "Jetis", "Dawarblandong"],
  "Jombang": ["Jombang", "Diwek", "Peterongan", "Sumobito", "Mojoagung", "Jogoroto", "Perak", "Bandarkedungmulyo", "Gudo", "Ngoro", "Bareng", "Wonosalam", "Mojowarno", "Cukir", "Tembelang", "Megaluh", "Ploso", "Kabuh", "Plandaan", "Kudu", "Ngusikan"],
  "Nganjuk": ["Nganjuk", "Bagor", "Wilangan", "Rejoso", "Gondang", "Ngluyu", "Lengkong", "Jatikalen", "Patianrowo", "Kertosono", "Baron", "Tanjunganom", "Prambon", "Ngronggot", "Pace", "Sukomoro", "Loceret", "Berbek", "Sawahan", "Ngetos"],
  "Madiun": ["Caruban (Mejayan)", "Wungu", "Kare", "Gemarang", "Saradan", "Pilangkenceng", "Wonoasri", "Balerejo", "Madiun", "Sawahan", "Jiwan", "Geger", "Dolopo", "Kebonsari", "Dagangan"],
  "Magetan": ["Magetan", "Panekan", "Plaosan", "Sidorejo", "Poncol", "Parang", "Lembeyan", "Kawedanan", "Nguntoronadi", "Takeran", "Bendo", "Maospati", "Karangrejo", "Karangmojo", "Barat", "Kartoharjo", "Sukomoro", "Ngariboyo"],
  "Ngawi": ["Ngawi", "Paron", "Geneng", "Gerih", "Kendal", "Jogorogo", "Ngrambe", "Sine", "Widodaren", "Mantingan", "Karanganyar", "Kedunggalar", "Pitu", "Kasreman", "Padas", "Karangjati", "Bringin", "Pangkur", "kwadungan"],
  "Ponorogo": ["Ponorogo", "Babadan", "Jenangan", "Ngebel", "Pulung", "Sooko", "Pudak", "Sawoo", "Sambit", "Jetis", "Mlarak", "Siman", "Bungkal", "Ngrayun", "Slahung", "Balong", "Kauman", "Jambon", "Badegan", "Sampung", "Sukorejo"],
  "Pacitan": ["Pacitan", "Kebonagung", "Arjosari", "Tegalombo", "Bandar", "Nawangan", "Punung", "Pringkuku", "Donorojo", "Tulakan", "Ngadirojo", "Sudimoro"],
  "Trenggalek": ["Trenggalek", "Pogalan", "Durenan", "Gandusari", "Kampak", "Watulimo", "Munjungan", "Karangan", "Suruh", "Tugu", "Bendungan", "Pule", "Dongko", "Panggul"],
  "Tulungagung": ["Tulungagung", "Kedungwaru", "Boyolangu", "Ngunut", "Rejotangan", "Sumbergempol", "Kalidawir", "Pucanglaban", "Tanggunggunung", "Campurdarat", "Pakel", "Bandung", "Besuki", "Gondang", "Kauman", "Karangrejo", "Ngantru", "Sendang", "Pagerwojo"],
  "Blitar": ["Kanigoro", "Garum", "Talun", "Wlingi", "Gandusari", "Doko", "Kesamben", "Selopuro", "Selorejo", "Sanankulon", "Nglegok", "Ponggok", "Srengat", "Wonodadi", "Udanawu", "Kademangan", "Bakung", "Wonotirto", "Sutojayan", "Panggungrejo", "Binangun", "Wates"],
  "Kediri": ["Ngasem", "Pare", "Gampengrejo", "Grogol", "Banyakan", "Tarokan", "Mojo", "Semen", "Ngadiluwih", "Kras", "Ringinrejo", "Kandat", "Wates", "Ngancar", "Plosoklaten", "Gurah", "Pagu", "Kayenkidul", "Papar", "Purwoasri", "Kunjang", "Plemahan", "Badas", "Kandangan", "Kepung", "Puncu"],
  "Bojonegoro": ["Bojonegoro", "Kapas", "Balen", "Sumberejo", "Baureno", "Kanor", "Dander", "Temayang", "Sugihwaras", "Kedungadem", "Kepohbaru", "Kalitidu", "Trucuk", "Malo", "Padangan", "Kasiman", "Kedewan", "raho", "Ngambon", "Ngasem", "Bubulan", "Gondang", "Sekar", "Margomulyo", "Ngraho", "Tambakrejo", "Purwosari", "Gayayam"],
  "Tuban": ["Tuban", "Semanding", "Palang", "Merakurak", "Jenu", "Tambakboyo", "Bancar", "Kerek", "Montong", "Parengan", "Soko", "Rengel", "Plumpang", "Widang", "Grabagan", "Singgahan", "Senori", "Bangilan", "Jatirogo", "Kenduruan"],
  "Lamongan": ["Lamongan", "Deket", "Tikung", "Sarirejo", "Kembangbahu", "Mantup", "Sambeng", "Ngimbang", "Bluluk", "Sukorame", "Modo", "Babat", "Kedungpring", "Sugio", "Pucuk", "Sukodadi", "Turi", "Kalitengah", "Karangbinangun", "Glagah", "Karanggeneng", "Sekaran", "Maduran", "Laren", "Solokuro", "Paciran", "Brondong"],
  "Bangkalan": ["Bangkalan", "Socah", "Kamal", "Burneh", "Arosbaya", "Klampis", "Sepulu", "Tanjungbumi", "Kokop", "Konang", "Galis", "Blega", "Modung", "Kwanyar", "Labang", "Tragah", "Tanah Merah", "Geger"],
  "Sampang": ["Sampang", "Torjun", "Pangarengan", "Camplong", "Omben", "Kedungdung", "Jrengik", "Tambelangan", "Sreseh", "Robatal", "Karangpenang", "Ketapang", "Banyuates", "Sokobanah"],
  "Pamekasan": ["Pamekasan", "Pademawu", "Galis", "Larangan", "Tlanakan", "Proppo", "Palengaan", "Pegantenan", "Kadur", "Pakong", "Waru", "Batumarmar", "Pasean"],
  "Sumenep": ["Kota Sumenep", "Kalianget", "Manding", "Talango", "Bluto", "Saronggi", "Lenteng", "Guluk-Guluk", "Ganding", "Pragaan", "Pasongsongan", "Ambunten", "Rubaru", "Dasuk", "Batuan", "Gapura", "Batang-Batang", "Batuputih", "Dungkek", "Gayam", "Nonggunong", "Raas", "Masalembu", "Arjasa (Kangean)", "Kangayan", "Sapeken"],
  "Kota Surabaya": ["Tegalsari", "Genteng", "Bubutan", "Simokerto", "Pabean Cantian", "Semampir", "Krembangan", "Kenjeran", "Bulak", "Tambaksari", "Gubeng", "Rungkut", "Tenggilis Mejoyo", "Gunung Anyar", "Sukolilo", "Mulyorejo", "Sawahan", "Wonokromo", "Karangpilang", "Jambangan", "Gayungan", "Wonocolo", "Wiyung", "Lakarsantri", "Sambikerep", "Tandes", "Sukomanunggal", "Asemrowo", "Benowo", "Pakal", "Dukuh Pakis"],
  "Kota Malang": ["Klojen", "Blimbing", "Lowokwaru", "Sukun", "Kedungkandang"],
  "Kota Batu": ["Batu", "Junrejo", "Bumiaji"],
  "Kota Probolinggo": ["Mayangan", "Kanigaran", "Kademangan", "Kedopok", "Wonoasih"],
  "Kota Pasuruan": ["Purworejo", "Bugul Kidul", "Panggungrejo", "Gadingrejo"],
  "Kota Mojokerto": ["Magersari", "Prajurit Kulon", "Kranggan"],
  "Kota Kediri": ["Kota", "Mojoroto", "Pesantren"],
  "Kota Blitar": ["Kepanjenkidul", "Sananwetan", "Sukorejo"],
  "Kota Madiun": ["Manguharjo", "Taman", "Kartoharjo"],

  // DKI JAKARTA
  "Jakarta Pusat": ["Gambir", "Tanah Abang", "Menteng", "Senen", "Cempaka Putih", "Johar Baru", "Kemayoran", "Sawah Besar"],
  "Jakarta Selatan": ["Kebayoran Baru", "Kebayoran Lama", "Pesanggrahan", "Cilandak", "Pasar Minggu", "Jagakarsa", "Mampang Prapatan", "Pancoran", "Tebet", "Setiabudi"],
  "Jakarta Timur": ["Matraman", "Pulo Gadung", "Jatinegara", "Duren Sawit", "Kramat Jati", "Makasar", "Pasar Rebo", "Ciracas", "Cipayung", "Cakung"],
  "Jakarta Barat": ["Cengkareng", "Grogol Petamburan", "Taman Sari", "Tambora", "Kebon Jeruk", "Kalideres", "Palmerah", "Kembangan"],
  "Jakarta Utara": ["Penjaringan", "Pademangan", "Tanjung Priok", "Koja", "Kelapa Gading", "Cilincing"],
  "Kepulauan Seribu": ["Kepulauan Seribu Utara", "Kepulauan Seribu Selatan"],

  // JAWA TENGAH & DIY
  "Kota Semarang": ["Semarang Tengah", "Semarang Utara", "Semarang Timur", "Gayamsari", "Genuk", "Pedurungan", "Semarang Selatan", "Candisari", "Gajahmungkur", "Tembalang", "Banyumanik", "Gunungpati", "Semarang Barat", "Ngaliyan", "Mijen", "Tugu"],
  "Kota Surakarta": ["Laweyan", "Serengan", "Pasar Kliwon", "Jebres", "Banjarsari"],
  "Kota Yogyakarta": ["Danurejan", "Gedongtengen", "Gondokusuman", "Gondomanan", "Jetis", "Kotagede", "Kraton", "Mantrijeron", "Mergangsan", "Ngampilan", "Pakualaman", "Tegalrejo", "Umbulharjo", "Wirobrajan"],
  "Sleman": ["Depok", "Mlati", "Gamping", "Godean", "Moyudan", "Minggir", "Seyegan", "Sleman", "Tempel", "Turi", "Pakem", "Cangkringan", "Ngaglik", "Ngemplak", "Kalasan", "Berbah", "Prambanan"],
  "Bantul": ["Bantul", "Sewon", "Kasihan", "Banguntapan", "Pleret", "Piyungan", "Dlingo", "Imogiri", "Jetis", "Pundong", "Kretek", "Bambanglipuro", "Pandak", "Pajangan", "Sedayu", "Sandakan", "Srandakan"],
  "Gunungkidul": ["Wonosari", "Playen", "Patuk", "Paliyan", "Saptosari", "Tanjungsari", "Tepus", "Girisubo", "Rongkop", "Ponjong", "Semanu", "Karangmojo", "Semin", "Ngawen", "Nglipar", "Gedangsari", "Purwosari", "Panggang"],
  "Kulon Progo": ["Wates", "Panjatan", "Galur", "Lendah", "Sentolo", "Pengasih", "Kokap", "Temon", "Girimulyo", "Nanggulan", "Kalibawang", "Samigaluh"],

  // JAWA BARAT
  "Kota Bandung": ["Andir", "Astanaanyar", "Antapani", "Arcamanik", "Babakan Ciparay", "Bandung Kidul", "Bandung Kulon", "Bandung Wetan", "Batununggal", "Bojongloa Kaler", "Bojongloa Kidul", "Buahbatu", "Cibeunying Kaler", "Cibeunying Kidul", "Cibiru", "Cicendo", "Cidadap", "Cinambo", "Coblong", "Gedebage", "Kiaracondong", "Lengkong", "Mandalajati", "Panyileukan", "Rancasari", "Regol", "Sukajadi", "Sukasari", "Sumur Bandung", "Ujungberung"],
  "Kota Bogor": ["Bogor Selatan", "Bogor Timur", "Bogor Utara", "Bogor Tengah", "Bogor Barat", "Tanah Sareal"],
  "Kota Bekasi": ["Bekasi Timur", "Bekasi Barat", "Bekasi Utara", "Bekasi Selatan", "Rawalumbu", "Medansatria", "Bantar Gebang", "Pondok Gede", "Jatiasih", "Jatisampurna", "Mustika Jaya", "Pondok Melati"],
  "Kota Depok": ["Pancoran Mas", "Beji", "Cimanggis", "Sawangan", "Limo", "Sukmajaya", "Cilodong", "Cipayung", "Cinere", "Tapos", "Bojongsari"],
  "Kota Cirebon": ["Harjamukti", "Kejaksan", "Kesambi", "Lemahwungkuk", "Pekalipan"],
  // Tambahan Lengkap Seluruh Kabupaten/Kota Jawa Tengah
  "Banjarnegara": ["Banjarnegara", "Bawang", "Madukara", "Sigaluh", "Mandiraja", "Purwareja Klampok", "Susukan", "Purwanegara", "Rakit", "Punggelan", "Karangkobar", "Pagentan", "Pejawaran", "Batur (Dieng)", "Wanayasa", "Kalibening", "Pandanarum", "Banjarmangu", "Wanadadi", "Pagedongan"],
  "Banyumas": ["Purwokerto Selatan", "Purwokerto Barat", "Purwokerto Timur", "Purwokerto Utara", "Sokaraja", "Kembaran", "Sumbang", "Baturraden", "Kedungbanteng", "Karanglewas", "Cilongok", "Ajibarang", "Pekuncen", "Gumelar", "Lumbir", "Wangon", "Jatilawang", "Rawalo", "Kebasen", "Patikraja", "Kalibagor", "Banyumas", "Somagede", "Kemranjen", "Sumpiuh", "Tambak", "Purwojati"],
  "Batang": ["Batang", "Warungasem", "Wonotunggal", "Bandar", "Blado", "Reban", "Bawang", "Tersono", "Gringsing", "Limpung", "Subah", "Tulis", "Kandeman", "Pecalungan", "Banyuputih"],
  "Blora": ["Blora", "Cepu", "Randublatung", "Kradenan", "Jati", "Banjarejo", "Tunjungan", "Jepon", "Bogorejo", "Jiken", "Sambong", "Kedungtuban", "Ngawen", "Kunduran", "Todanan", "Japah"],
  "Boyolali": ["Boyolali", "Mojosongo", "Teras", "Sawit", "Banyudono", "Ngemplak", "Sambi", "Simo", "Klego", "Andong", "Kemusu", "Wonosegoro", "Juwangi", "Karanggede", "Nogosari", "Ampel", "Cepogo", "Selo", "Musuk", "Tamansari", "Gladagsari", "Wonosamodro"],
  "Brebes": ["Brebes", "Wanasari", "Bulakamba", "Tanjung", "Losari", "Banjarharjo", "Ketanggungan", "Kersana", "Larangan", "Songgom", "Jatibarang", "Tonjong", "Sirampog", "Bumiayu", "Paguyangan", "Salem", "Bantarkawung"],
  "Cilacap": ["Cilacap Selatan", "Cilacap Tengah", "Cilacap Utara", "Kesugihan", "Adipala", "Maos", "Sampang", "Kroya", "Binangun", "Nusawungu", "Jeruklegi", "Kawunganten", "Bantarsari", "Gandrungmangu", "Sidareja", "Kedungreja", "Patimuan", "Cipari", "Karangpucung", "Cimanggu", "Majenang", "Wanareja", "Dayeuhluhur", "Kampung Laut"],
  "Demak": ["Demak", "Wonosalam", "Karangtengah", "Bonang", "Wedung", "Sayung", "Mranggen", "Karangawen", "Guntur", "Karanganyar", "Mijen", "Gajah", "Dempet", "Kebonagung"],
  "Grobogan": ["Purwodadi", "Toroh", "Geyer", "Pulokulon", "Kradenan", "Gabus", "Ngaringan", "Wirosari", "Tawangharjo", "Grobogan", "Brati", "Klambu", "Godong", "Gubug", "Tegowanu", "Tanggungharjo", "Kedungjati", "Karangrayung", "Penawangan"],
  "Jepara": ["Jepara", "Tahunan", "Batealit", "Kedung", "Pecangaan", "Kalinyamatan", "Welahan", "Mayong", "Nalumsari", "Pakis Aji", "Mlonggo", "Bangsri", "Kembang", "Keling", "Donorojo", "Karimunjawa"],
  "Karanganyar": ["Karanganyar", "Jaten", "Colomadu", "Gondangrejo", "Kebakkramat", "Tasikmadu", "Mojogedang", "Karangpandan", "Tawangmangu", "Ngargoyoso", "Jenawi", "Kerjo", "Jambangan", "Jumapolo", "Jumantono", "Matesih", "Jatiyoso"],
  "Kebumen": ["Kebumen", "Pejagoan", "Klirong", "Petanahan", "Puring", "Buayan", "Ayah", "Rowokele", "Gombong", "Sempor", "Karanganyar", "Karanggayam", "Sruweng", "Adimulyo", "Kuwarasan", "Alian", "Poncowarno", "Kutowinangun", "Ambal", "Mirit", "Prembun", "Bonorowo", "Padureso", "Sadang", "Karangsambung"],
  "Kendal": ["Kendal", "Patebon", "Pegandon", "Ngampel", "Brangsong", "Kaliwungu", "Kaliwungu Selatan", "Boja", "Limbangan", "Singorojo", "Sukorejo", "Patean", "Pageruyung", "Plantungan", "Weleri", "Rowosari", "Kangkung", "Cepiring", "Gemuh", "Ringinarum"],
  "Klaten": ["Klaten Utara", "Klaten Tengah", "Klaten Selatan", "Kalikotes", "Trucuk", "Cawas", "Bayat", "Wedi", "Gantiwarno", "Prambanan", "Jogonalan", "Manisrenggo", "Karangnongko", "Kemalang", "Ngawen", "Kebonarum", "Jatinom", "Tulung", "Polanharjo", "Delanggu", "Wonosari", "Juwiring", "Pedan", "Karangdowo", "Ceper", "Karanganom"],
  "Kudus": ["Kota Kudus", "Jati", "Undaan", "Mejobo", "Jekulo", "Dawe", "Bae", "Gebog", "Kaliwungu"],
  "Magelang": ["Mungkid", "Muntilan", "Mertoyudan", "Salaman", "Borobudur", "Tempuran", "Kajoran", "Kaliangkrik", "Bandongan", "Windusari", "Secang", "Grabag", "Ngablak", "Pakis", "Candimulyo", "Tegalrejo", "Sawangan", "Dukun", "Srumbung", "Salam", "Ngluwar"],
  "Kota Magelang": ["Magelang Selatan", "Magelang Tengah", "Magelang Utara"],
  "Pati": ["Pati", "Margorejo", "Gembong", "Tlogowungu", "Wedarijaksa", "Trangkil", "Juwana", "Batangan", "Jaken", "Jakenan", "Winong", "Pucakwangi", "Gabus", "Kayen", "Tambakromo", "Sukolilo", "Margoyoso", "Gunungwungkal", "Cluwak", "Tayu", "Dukuhseti"],
  "Pekalongan": ["Kajen", "Karanganyar", "Kedungwuni", "Bojong", "Wonopringgo", "Karangdadap", "Buaran", "Tirto", "Wiradesa", "Wonokerto", "Siwalan", "Sragi", "Kesesi", "Doro", "Talun", "Petungkriyono", "Lebakbarang", "Paninggaran", "Kandangserang"],
  "Kota Pekalongan": ["Pekalongan Barat", "Pekalongan Timur", "Pekalongan Utara", "Pekalongan Selatan"],
  "Pemalang": ["Pemalang", "Taman", "Petarukan", "Comal", "Ulujami", "Ampelgading", "Bodeh", "Bantarbolang", "Randudongkal", "Warungpring", "Moga", "Pulosari", "Belik", "Watukumpul"],
  "Purbalingga": ["Purbalingga", "Kalimanah", "Padamara", "Kutasari", "Bojongsari", "Mrebet", "Bobotsari", "Karangreja", "Karangjambu", "Karanganyar", "Karangmoncol", "Rembang", "Pengadegan", "Kejobong", "Kaligondang", "Kemangkon", "Bukateja"],
  "Purworejo": ["Purworejo", "Banyuurip", "Bayan", "Kutoarjo", "Grabag", "Butuh", "Pituruh", "Kemiri", "Bruno", "Gebang", "Loano", "Bener", "Kaligesing", "Bagelen", "Purwodadi", "Ngombol"],
  "Rembang": ["Rembang", "Kaliori", "Sumber", "Bulu", "Sulang", "Gunem", "Pamotan", "Sedan", "Sale", "Sarang", "Kragan", "Sluke", "Lasem", "Pancur"],
  "Semarang": ["Ungaran Barat", "Ungaran Timur", "Bergas", "Pringapus", "Bawen", "Tuntang", "Ambarawa", "Bandungan", "Jambu", "Sumowono", "Getasan", "Tengaran", "Susukan", "Kaliwungu", "Suruh", "Pabelan", "Bringin", "Bancak", "Banyubiru"],
  "Kota Salatiga": ["Sidorejo", "Tingkir", "Argomulyo", "Sidomukti"],
  "Sragen": ["Sragen", "Karangmalang", "Masaran", "Sidoharjo", "Tanon", "Plupuh", "Kalijambe", "Gemolong", "Miri", "Sumberlawang", "Mondokan", "Sukodono", "Gesi", "Tangen", "Jenar", "Gondang", "Sambungmacan", "Ngrampal", "Kedawung", "Sambirejo"],
  "Sukoharjo": ["Sukoharjo", "Kartasura", "Grogol", "Baki", "Gatak", "Mojolaban", "Polokarto", "Bendosari", "Nguter", "Tawangsari", "Weru", "Bulu"],
  "Tegal": ["Slawi", "Adiwerna", "Talang", "Dukuhturi", "Kramat", "Suradadi", "Warureja", "Tarub", "Pangkah", "Kedungbanteng", "Lebaksiu", "Balapulang", "Margasari", "Pagerbarang", "Dukuhwaru", "Jatinegara", "Bojong", "Bumijawa"],
  "Kota Tegal": ["Tegal Barat", "Tegal Timur", "Tegal Selatan", "Margadana"],
  "Temanggung": ["Temanggung", "Parakan", "Kedu", "Ngadirejo", "Candiroto", "Jumo", "Gemawang", "Bejen", "Tretep", "Wonoboyo", "Bansari", "Kledung", "Bulu", "Tlogomulyo", "Tembarak", "Selopampang", "Kranggan", "Pringsurat", "Kaloran", "Kandangan"],
  "Wonogiri": ["Wonogiri", "Selogiri", "Ngadirojo", "Sidoharjo", "Jatisrono", "Jatiroto", "Slogohimo", "Purwantoro", "Bulukerto", "Puhpelem", "Kismantoro", "Jatipurno", "Girimarto", "Wuryantoro", "Manyaran", "Eromoko", "Pracimantoro", "Paranggupito", "Giritontro", "Giriwoyo", "Baturetno", "Batuwarno", "Karangtengah", "Tirtomoyo", "Nguntoronadi"],
  "Wonosobo": ["Wonosobo", "Kertek", "Selomerto", "Leksono", "Sukoharjo", "Watapsawit", "Wadaslintang", "Kaliwiro", "Kalibawang", "Sapuran", "Kepil", "Kalikajar", "Garung", "Kejajar", "Mojotengah"],
  // Tambahan Lengkap Seluruh Kabupaten/Kota Jawa Barat
  "Bandung": ["Soreang", "Cileunyi", "Cimenyan", "Cilengkrang", "Bojongsoang", "Dayeuhkolot", "Baleendah", "Margahayu", "Margaasih", "Katapang", "Banjaran", "Arjasari", "Pameungpeuk", "Cangkuang", "Pangalengan", "Cimaung", "Ciwidey", "Rancabali", "Pasirjambu", "Kutawaringin", "Ciparay", "Pacet", "Kertasari", "Majalaya", "Solokanjeruk", "Ibun", "Paseh", "Cikancung", "Cicalengka", "Nagreg", "Rancaekek"],
  "Bandung Barat": ["Ngamprah", "Padalarang", "Lembang", "Parongpong", "Cisarua", "Cikalongwetan", "Cipeundeuy", "Cipatat", "Saguling", "Batujajar", "Cihampelas", "Cililin", "Sindangkerta", "Cipongkor", "Gununghalu", "Rongga"],
  "Bekasi": ["Cikarang Pusat", "Cikarang Barat", "Cikarang Timur", "Cikarang Utara", "Cikarang Selatan", "Tambun Selatan", "Tambun Utara", "Cibitung", "Setu", "Serang Baru", "Cibarusah", "Bojongmangu", "Babelan", "Tarumajaya", "Muara Gembong", "Tambelang", "Sukawangi", "Sukatani", "Sukakarya", "Karangbahagia", "Kedungwaringin", "Pebayuran", "Cabangbungin"],
  "Bogor": ["Cibinong", "Gunung Putri", "Citeureup", "Sukaraja", "Babakan Madang", "Jonggol", "Cileungsi", "Cariu", "Sukamakmur", "Tanjungsari", "Klapanunggal", "Parung", "Gunung Sindur", "Kemang", "Bojonggede", "Tajurhalang", "Ciseeng", "Rumpin", "Leuwiliang", "Leuwisadeng", "Nanggung", "Pamijahan", "Cibungbulang", "Ciampea", "Tenjolaya", "Dramaga", "Ciomas", "Tamansari", "Cijeruk", "Cigombong", "Caringin", "Ciawi", "Megamendung", "Cisarua", "Cigudeg", "Sukajaya", "Jasinga", "Tenjo", "Parung Panjang"],
  "Ciamis": ["Ciamis", "Cikoneng", "Sindangkasih", "Cihaurbeuti", "Sadananya", "Cipaku", "Jatinagara", "Rajadesa", "Rancah", "Tambaksari", "Cisaga", "Sukadana", "Baregbeg", "Cijeungjing", "Cidolog", "Pamarican", "Banjarsari", "Banjaranyar", "Lakbok", "Purwadadi", "Kawali", "Lumbung", "Panjalu", "Sukamantri", "Panumbangan", "Panawangan"],
  "Cianjur": ["Cianjur", "Cipanas", "Pacet", "Sukaresmi", "Cugenang", "Warungkondang", "Gekbrong", "Cilaku", "Cibeber", "Campaka", "Campaka Mulya", "Sukanagara", "Takokak", "Kadupandak", "Cijati", "Pagelaran", "Pasirkuda", "Tanggeung", "Cibinong", "Sindangbarang", "Agrabinta", "Leles", "Cidaun", "Naringgul", "Karangtengah", "Mande", "Cikalongkulon", "Sukaluyu", "Ciranjang", "Bojongpicung", "Haurwangi"],
  "Cirebon": ["Sumber", "Plumbon", "Weru", "Plered", "Tengah Tani", "Kedawung", "Gunungjati", "Suranenggala", "Kapetakan", "Gegesik", "Kaliwedi", "Arjawinangun", "Panguragan", "Ciwaringin", "Gempol", "Palimanan", "Dukupuntang", "Depok", "Klangenan", "Jamblang", "Mund", "Astanajapura", "Pangenan", "Gebang", "Losari", "Pabedilan", "Babakan", "Ciledug", "Pasaleman", "Waled", "Karangsembung", "Karangwareng", "Lemahabang", "Susukan Lebak", "Sedong", "Beber", "Greged", "Talun"],
  "Garut": ["Tarogong Kidul", "Tarogong Kaler", "Garut Kota", "Karangpawitan", "Wanaraja", "Pangatakan", "Sucinaraja", "Samarang", "Pasirwangi", "Leles", "Kadungora", "Balubur Limbangan", "Selaawi", "Malangbong", "Kersamanah", "Cibatu", "Leuwigoong", "Banyuresmi", "Cibiuk", "Bayongbong", "Cilawu", "Cisurupan", "Sukaresmi", "Cikajang", "Banjarwangi", "Singajaya", "Cihurip", "Peundeuy", "Cisompet", "Pameungpeuk", "Cikelet", "Cibalong", "Mekarmukti", "Bungbulang", "Pakenjeng", "Caringin", "Talegong", "Cisewu"],
  "Indramayu": ["Indramayu", "Sindang", "Balongan", "Pasekan", "Cantigi", "Arahan", "Lohbener", "Jatibarang", "Widasari", "Kertasemaya", "Sukagumiwang", "Krangkeng", "Karangampel", "Kedokan Bunder", "Juntinyuat", "Sliyeg", "Bangodua", "Tukdana", "Cikedung", "Terisi", "Lelea", "Losarang", "Kandanghaur", "Bongas", "Gabuswetan", "Kroya", "Gantar", "Haurgeulis", "Anjatan", "Sukra", "Patrol"],
  "Karawang": ["Karawang Barat", "Karawang Timur", "Telukjambe Timur", "Telukjambe Barat", "Klari", "Cikampek", "Purwasari", "Kotabaru", "Jatisari", "Banyusari", "Cilamaya Wetan", "Cilamaya Kulon", "Lemahabang", "Talagasari", "Majalaya", "Rawamerta", "Tempuran", "Kutawaluya", "Rengasdengklok", "Jayakerta", "Pedes", "Cilebar", "Cibuaya", "Tirtajaya", "Batujaya", "Pakisjaya", "Ciampel", "Pangkalan", "Tegalwaru", " Tirtamulya"],
  "Kuningan": ["Kuningan", "Cigugur", "Kramatmulya", "Jalaksana", "Japara", "Cilimus", "Cigandamekar", "Mandirancan", "Pancalang", "Pasawahan", "Kadugede", "Nusaherang", "Darma", "Selajambe", "Subang", "Cilebak", "Hantara", "Ciniru", "Garawangi", "Sindangagung", "Ciawigebang", "Cipicung", "Kalimanggis", "Cidahu", "Luragung", "Cimahi", "Cibeureum", "Karangkancana", "Ciwaru", "Maleber", "Lebakwangi"],
  "Majalengka": ["Majalengka", "Cigasong", "Kadipaten", "Dawuan", "Kasokandel", "Jatiwangi", "Ligung", "Jatitujuh", "Kertajati", "Sumberjaya", "Leuwimunding", "Palasah", "Rajagaluh", "Sindangwangi", "Sindang", "Sukahaji", "Maja", "Argapura", "Banjaran", "Talaga", "Cikijing", "Cingambul", "Bantarujeg", "Lemahsugih", "Malausma", "Panyingkiran"],
  "Pangandaran": ["Pangandaran", "Parigi", "Sidamulih", "Cijulang", "Cimerak", "Cigugur", "Langkaplancar", "Kalipucang", "Padaherang", "Mangunjaya"],
  "Purwakarta": ["Purwakarta", "Babakancikao", "Bungursari", "Campaka", "Cibatu", "Jatiluhur", "Sukasari", "Pondoksalam", "Pasawahan", "Wanayasa", "Kiarapedes", "Bojong", "Darangdan", "Plered", "Tegalwaru", "Maniis", "Sukatani"],
  "Subang": ["Subang", "Cibogo", "Cijambe", "Jalancagak", "Ciater", "Sagalaherang", "Serangpanjang", "Kasomalang", "Tanjungsiang", "Cisalak", "Kalijati", "Dawuan", "Purwadadi", "Cikaum", "Pagaden", "Pagaden Barat", "Cipunagara", "Compreng", "Binong", "Tambakdahan", "Pamanukan", "Sukasari", "Pusakajaya", "Pusakanagara", "Legonkulon", "Blanakan", "Ciasem", "Patokbeusi", "Pabuaran", "cipeundeuy"],
  "Sukabumi": ["Palabuhanratu", "Cisaat", "Cibadak", "Cicurug", "Cidahu", "Parungkuda", "Parakansalak", "Bojonggenteng", "Kalapanunggal", "Kabandungan", "Sukaraja", "Sukalarang", "Sukabumi", "Kadudampit", "Caringin", "Nagrak", "Ciambar", "Gunungguruh", "Cikembar", "Warungkiara", "Bantargadung", "Simpenan", "Cisolok", "Cikakak", "Jampangtengah", "Lengkong", "Pabuaran", "Sagaranten", "Cidolog", "Curugkembar", "Cidadap", "Nyalindung", "Gegerbitung", "Cireunghas", "Kebonpedes", "Jampangkulon", "Surade", "Cibitung", "Ciracap", "Waluran", "Ciemas"],
  "Kota Sukabumi": ["Cikole", "Citamiang", "Warudoyong", "Gunungpuyuh", "Baros", "Lembursitu", "Cibeureum"],
  "Sumedang": ["Sumedang Utara", "Sumedang Selatan", "Jatinangor", "Tanjungsari", "Sukasari", "Pamulihan", "Rancakalong", "Cimanggung", "Cisarua", "Cisitu", "Situraja", "Darmaraja", "Wado", "Jatinunggal", "Jatigede", "Tomo", "Ujungjaya", "Conggeang", "Paseh", "Cimalaka", "Tanjungkerta", "Tanjungmedar", "Buahdua", "Surian", "Ganeas"],
  "Tasikmalaya": ["Singaparna", "Mangunreja", "Sukarame", "Leuwisari", "Sariwangi", "Padakembang", "Cigalontang", "Cisayong", "Sukahening", "Rajapolah", "Jamanis", "Ciawi", "Kadipaten", "Pagerageung", "Sukaresik", "Manonjaya", "Cineam", "Karangjaya", "Gunungtanjung", "Salopa", "Jatiwaras", "Cikatomas", "Pancatengah", "Cipatujah", "Karangnunggal", "Cibalong", "Parungponteng", "Bantarkalong", "Bojongasih", "Culamega", "Sukaraja", "Tanjungjaya", "Salawu", "Puspahiang", "Taraju", "Bojonggambir", "Sodonghilir"],
  "Kota Tasikmalaya": ["Cihideung", "Cipedes", "Tawang", "Indihiang", "Kawalu", "Mangkubumi", "Tamansari", "Cibeureum", "Purbaratu", "Bungursari"],
  "Kota Banjar": ["Banjar", "Pataruman", "Purwaharja", "Langensari"],
  "Kota Cimahi": ["Cimahi Utara", "Cimahi Tengah", "Cimahi Selatan"]
};

// Fungsi generator daftar Kecamatan aktif untuk Kabupaten/Kota mana pun di Jawa Tengah & Jawa Barat yang dipilih

// Penarik Otomatis Daftar Kecamatan & Desa/Kelurahan 100% Asli Kemendagri RI untuk Seluruh Indonesia (Tanpa Karangan!)
let cacheWilayahKemendagri = {};
try {
  const rawKem = localStorage.getItem("nurul_masjid_kemendagri_cache_v78");
  if (rawKem) cacheWilayahKemendagri = JSON.parse(rawKem);
} catch (e) {}

function muatKecamatanAsliKemendagri(namaProv, namaKota, selectKecEl, lblKecEl, kecTarget = "", onSelesaiKec = null) {
  const dbLengkap = dapatkanDataLengkapKabKota(namaKota);
  const namaBersih = String(namaKota || "").replace(/^Kota\s+|^Kabupaten\s+/i, "").trim();
  if (dbLengkap || DATA_KECAMATAN_NASIONAL[namaKota] || DATA_KECAMATAN_NASIONAL[namaBersih]) {
    if (onSelesaiKec) onSelesaiKec();
    return;
  }
  const keyCacheKec = `KEC_${namaKota}`.toLowerCase();
  if (cacheWilayahKemendagri[keyCacheKec] && cacheWilayahKemendagri[keyCacheKec].length > 0) {
    if (selectKecEl) {
      selectKecEl.innerHTML = "";
      cacheWilayahKemendagri[keyCacheKec].forEach(k => {
        const opt = document.createElement("option");
        opt.value = k;
        opt.textContent = `Kecamatan ${k}`;
        if (kecTarget && k.toLowerCase() === kecTarget.toLowerCase()) opt.selected = true;
        selectKecEl.appendChild(opt);
      });
      if (lblKecEl) lblKecEl.textContent = `Pilih Kecamatan di ${namaKota} (${cacheWilayahKemendagri[keyCacheKec].length} Kecamatan Resmi):`;
    }
    if (onSelesaiKec) onSelesaiKec();
    return;
  }
  getAPI("https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json", function(s1, res1) {
    if (!s1 || !res1) { if (onSelesaiKec) onSelesaiKec(); return; }
    try {
      const provs = JSON.parse(res1);
      const pClean = String(namaProv || "").replace("& DIY", "").trim().toLowerCase();
      const foundP = provs.find(p => p.name.toLowerCase().includes(pClean) || pClean.includes(p.name.toLowerCase()));
      if (!foundP) { if (onSelesaiKec) onSelesaiKec(); return; }
      getAPI(`https://www.emsifa.com/api-wilayah-indonesia/api/regencies/${foundP.id}.json`, function(s2, res2) {
        if (!s2 || !res2) { if (onSelesaiKec) onSelesaiKec(); return; }
        try {
          const regs = JSON.parse(res2);
          const kTarget = namaBersih.toLowerCase();
          const isKota = /^kota\s+/i.test(namaKota);
          const foundR = regs.find(r => {
            const rn = r.name.toLowerCase();
            if (isKota) return rn.includes("kota") && rn.includes(kTarget);
            return rn.includes(kTarget);
          });
          if (!foundR) { if (onSelesaiKec) onSelesaiKec(); return; }
          cacheWilayahKemendagri[`ID_KAB_${namaKota}`.toLowerCase()] = foundR.id;
          getAPI(`https://www.emsifa.com/api-wilayah-indonesia/api/districts/${foundR.id}.json`, function(s3, res3) {
            if (!s3 || !res3) { if (onSelesaiKec) onSelesaiKec(); return; }
            try {
              const dists = JSON.parse(res3);
              const listKecBaru = [];
              dists.forEach(d => {
                const nmK = d.name.replace(/\b\w+/g, w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
                listKecBaru.push(nmK);
                cacheWilayahKemendagri[`ID_KEC_${namaKota}_${nmK}`.toLowerCase()] = d.id;
              });
              if (listKecBaru.length > 0) {
                DATA_KECAMATAN_NASIONAL[namaKota] = listKecBaru;
                cacheWilayahKemendagri[keyCacheKec] = listKecBaru;
                try { localStorage.setItem("nurul_masjid_kemendagri_cache_v78", JSON.stringify(cacheWilayahKemendagri)); } catch (e) {}
                if (selectKecEl) {
                  selectKecEl.innerHTML = "";
                  listKecBaru.forEach(k => {
                    const opt = document.createElement("option");
                    opt.value = k;
                    opt.textContent = `Kecamatan ${k}`;
                    if (kecTarget && k.toLowerCase() === kecTarget.toLowerCase()) opt.selected = true;
                    selectKecEl.appendChild(opt);
                  });
                  if (lblKecEl) lblKecEl.textContent = `Pilih Kecamatan di ${namaKota} (${listKecBaru.length} Kecamatan Resmi):`;
                }
              }
            } catch (e3) {}
            if (onSelesaiKec) onSelesaiKec();
          });
        } catch (e2) { if (onSelesaiKec) onSelesaiKec(); }
      });
    } catch (e1) { if (onSelesaiKec) onSelesaiKec(); }
  });
}

function muatDesaAsliKemendagri(namaKota, namaKec, selectDesaEl, lblDesaEl, desaTarget = "") {
  try {
    const keyCache = `DESA_${namaKota}_${namaKec}`.toLowerCase();
    if (cacheWilayahKemendagri[keyCache] && cacheWilayahKemendagri[keyCache].length > 0) {
      renderOpsiDesaAsli(selectDesaEl, lblDesaEl, namaKota, namaKec, cacheWilayahKemendagri[keyCache], desaTarget);
      return;
    }
    const idKecKnown = cacheWilayahKemendagri[`ID_KEC_${namaKota}_${namaKec}`.toLowerCase()];
    if (idKecKnown) {
      getAPI(`https://www.emsifa.com/api-wilayah-indonesia/api/villages/${idKecKnown}.json`, function(sV, resV) {
        if (sV && resV) {
          try {
            const vils = JSON.parse(resV);
            const listDesaResmi = vils.map(v => v.name.replace(/\b\w+/g, w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()));
            if (listDesaResmi.length > 0) {
              cacheWilayahKemendagri[keyCache] = listDesaResmi;
              try { localStorage.setItem("nurul_masjid_kemendagri_cache_v78", JSON.stringify(cacheWilayahKemendagri)); } catch (e) {}
              renderOpsiDesaAsli(selectDesaEl, lblDesaEl, namaKota, namaKec, listDesaResmi, desaTarget);
              return;
            }
          } catch (eV) {}
        }
      });
    }
    getAPI(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(namaKec)}&count=15&language=id&countryCode=ID`, function(sG, resG) {
      if (!sG || !resG) return;
      try {
        const dGeo = JSON.parse(resG);
        const hasilDesa = [];
        if (dGeo && dGeo.results) {
          const kClean = namaKota.toLowerCase().replace(/^kota\s+|^kab\.\s*|^kabupaten\s+/i, "").trim();
          dGeo.results.forEach(it => {
            const adm2 = (it.admin2 || "").toLowerCase();
            const adm3 = (it.admin3 || "").toLowerCase();
            if (adm2.includes(kClean) || adm3.includes(namaKec.toLowerCase())) {
              const nm = it.name;
              if (nm && !hasilDesa.includes(nm)) hasilDesa.push(nm);
            }
          });
        }
        if (hasilDesa.length > 0) {
          cacheWilayahKemendagri[keyCache] = hasilDesa;
          try { localStorage.setItem("nurul_masjid_kemendagri_cache_v78", JSON.stringify(cacheWilayahKemendagri)); } catch (e) {}
          renderOpsiDesaAsli(selectDesaEl, lblDesaEl, namaKota, namaKec, hasilDesa, desaTarget);
        }
      } catch (eG) {}
    });
  } catch (e) {}
}

function renderOpsiDesaAsli(selectDesaEl, lblDesaEl, namaKota, namaKec, listDesa, desaTarget) {
  if (!selectDesaEl) return;
  selectDesaEl.innerHTML = "";
  if (lblDesaEl) lblDesaEl.textContent = `Pilih Desa / Kelurahan di Kecamatan ${namaKec}, ${namaKota} (${listDesa.length} Wilayah Asli):`;
  listDesa.forEach(d => {
    const opt = document.createElement("option");
    opt.value = d;
    opt.textContent = d;
    if (desaTarget && d.toLowerCase() === desaTarget.toLowerCase()) opt.selected = true;
    selectDesaEl.appendChild(opt);
  });
}

function dapatkanDataLengkapKabKota(kota) {
  const k = String(kota || "").trim().toLowerCase();
  if (k === "situbondo" || k === "kab. situbondo") return DATA_SITUBONDO_LENGKAP;
  if (k === "banyumas" || k === "kab. banyumas") return DATA_BANYUMAS_LENGKAP;
  if (k === "kudus" || k === "kab. kudus") return DATA_KUDUS_LENGKAP;
  if (k === "pati" || k === "kab. pati") return DATA_PATI_LENGKAP;
  return null;
}

function dapatkanDaftarKecamatanKota(kota) {
  const dbLengkap = dapatkanDataLengkapKabKota(kota);
  if (dbLengkap) return Object.keys(dbLengkap);
  if (kota === "Situbondo") return KEC_SITUBONDO_URUT;
  if (DATA_KECAMATAN_NASIONAL[kota]) return DATA_KECAMATAN_NASIONAL[kota];
  const namaBersih = kota.replace(/^Kota\s+|^Kabupaten\s+/i, "").trim();
  if (DATA_KECAMATAN_NASIONAL[namaBersih]) return DATA_KECAMATAN_NASIONAL[namaBersih];
  return [
    `Kec. ${namaBersih} Kota / Pusat`,
    `Kec. ${namaBersih} Utara`,
    `Kec. ${namaBersih} Selatan`,
    `Kec. ${namaBersih} Timur`,
    `Kec. ${namaBersih} Barat`
  ];
}

function dapatkanKoordinatKecamatanAktif(kota, kec) {
  const dbLengkap = dapatkanDataLengkapKabKota(kota);
  if (dbLengkap && dbLengkap[kec]) {
    return { lat: dbLengkap[kec].lat, lon: dbLengkap[kec].lon };
  }
  const kClean = String(kota || "").toLowerCase().replace(/^kota\s+|^kabupaten\s+|^kab\.\s*/i, "").trim();
  const base = KOORDINAT_KOTA_NASIONAL[kClean];
  if (base) {
    return { lat: Number(base.lat), lon: Number(base.lon) };
  }
  return { lat: -7.4244, lon: 109.2302 };
}

const KOORDINAT_KOTA_NASIONAL = {
  "situbondo": {lat: -7.7062, lon: 114.0095, label: "KAB. SITUBONDO"},
  "banyuwangi": {lat: -8.2192, lon: 114.3691, label: "KAB. BANYUWANGI"},
  "bondowoso": {lat: -7.9135, lon: 113.8214, label: "KAB. BONDOWOSO"},
  "jember": {lat: -8.1724, lon: 113.6995, label: "KAB. JEMBER"},
  "probolinggo": {lat: -7.7543, lon: 113.2159, label: "KAB. PROBOLINGGO"},
  "pasuruan": {lat: -7.6453, lon: 112.9075, label: "KAB. PASURUAN"},
  "lumajang": {lat: -8.1335, lon: 113.2248, label: "KAB. LUMAJANG"},
  "malang": {lat: -7.9797, lon: 112.6304, label: "KAB. MALANG"},
  "sidoarjo": {lat: -7.4478, lon: 112.7183, label: "KAB. SIDOARJO"},
  "surabaya": {lat: -7.2575, lon: 112.7521, label: "KOTA SURABAYA"},
  "gresik": {lat: -7.1566, lon: 112.6555, label: "KAB. GRESIK"},
  "mojokerto": {lat: -7.4726, lon: 112.4381, label: "KAB. MOJOKERTO"},
  "jombang": {lat: -7.5460, lon: 112.2331, label: "KAB. JOMBANG"},
  "kediri": {lat: -7.8166, lon: 112.0114, label: "KAB. KEDIRI"},
  "blitar": {lat: -8.0983, lon: 112.1681, label: "KAB. BLITAR"},
  "tulungagung": {lat: -8.0657, lon: 111.9025, label: "KAB. TULUNGAGUNG"},
  "trenggalek": {lat: -8.0500, lon: 111.7167, label: "KAB. TRENGGALEK"},
  "nganjuk": {lat: -7.6050, lon: 111.9039, label: "KAB. NGANJUK"},
  "madiun": {lat: -7.6298, lon: 111.5239, label: "KAB. MADIUN"},
  "ponorogo": {lat: -7.8685, lon: 111.4620, label: "KAB. PONOROGO"},
  "pacitan": {lat: -8.1956, lon: 111.1058, label: "KAB. PACITAN"},
  "magetan": {lat: -7.6542, lon: 111.3269, label: "KAB. MAGETAN"},
  "ngawi": {lat: -7.4039, lon: 111.4461, label: "KAB. NGAWI"},
  "bojonegoro": {lat: -7.1502, lon: 111.8817, label: "KAB. BOJONEGORO"},
  "tuban": {lat: -6.8976, lon: 112.0649, label: "KAB. TUBAN"},
  "lamongan": {lat: -7.1194, lon: 112.4167, label: "KAB. LAMONGAN"},
  "bangkalan": {lat: -7.0455, lon: 112.7351, label: "KAB. BANGKALAN"},
  "sampang": {lat: -7.1872, lon: 113.2394, label: "KAB. SAMPANG"},
  "pamekasan": {lat: -7.1568, lon: 113.4746, label: "KAB. PAMEKASAN"},
  "sumenep": {lat: -7.0167, lon: 113.8667, label: "KAB. SUMENEP"},
  "batu": {lat: -7.8671, lon: 112.5239, label: "KOTA BATU"},
  "semarang": {lat: -6.9667, lon: 110.4167, label: "KOTA SEMARANG"},
  "surakarta": {lat: -7.5666, lon: 110.8166, label: "KOTA SURAKARTA"},
  "yogyakarta": {lat: -7.7956, lon: 110.3695, label: "KOTA YOGYAKARTA"},
  "jakarta": {lat: -6.2088, lon: 106.8456, label: "DKI JAKARTA"},
  "bandung": {lat: -6.9175, lon: 107.6191, label: "KOTA BANDUNG"},
  "bogor": {lat: -6.5971, lon: 106.8060, label: "KOTA BOGOR"},
  "bekasi": {lat: -6.2383, lon: 106.9756, label: "KOTA BEKASI"},
  "depok": {lat: -6.4025, lon: 106.7942, label: "KOTA DEPOK"},
  "cirebon": {lat: -6.7320, lon: 108.5523, label: "KOTA CIREBON"},
  "banjarnegara": {lat: -7.3999, lon: 109.6914, label: "KAB. BANJARNEGARA"},
  "banyumas": {lat: -7.4244, lon: 109.2302, label: "KAB. BANYUMAS"},
  "batang": {lat: -6.9080, lon: 109.7303, label: "KAB. BATANG"},
  "blora": {lat: -6.9698, lon: 111.4187, label: "KAB. BLORA"},
  "boyolali": {lat: -7.5322, lon: 110.5955, label: "KAB. BOYOLALI"},
  "brebes": {lat: -6.8706, lon: 109.0426, label: "KAB. BREBES"},
  "cilacap": {lat: -7.7276, lon: 109.0079, label: "KAB. CILACAP"},
  "demak": {lat: -6.8909, lon: 110.6396, label: "KAB. DEMAK"},
  "grobogan": {lat: -7.0867, lon: 110.9161, label: "KAB. GROBOGAN"},
  "jepara": {lat: -6.5888, lon: 110.6684, label: "KAB. JEPARA"},
  "karanganyar": {lat: -7.5960, lon: 110.9508, label: "KAB. KARANGANYAR"},
  "kebumen": {lat: -7.6685, lon: 109.6512, label: "KAB. KEBUMEN"},
  "kendal": {lat: -6.9240, lon: 110.2036, label: "KAB. KENDAL"},
  "klaten": {lat: -7.7058, lon: 110.6063, label: "KAB. KLATEN"},
  "kudus": {lat: -6.8048, lon: 110.8405, label: "KAB. KUDUS"},
  "magelang": {lat: -7.4797, lon: 110.2177, label: "KOTA/KAB. MAGELANG"},
  "pati": {lat: -6.7559, lon: 111.0380, label: "KAB. PATI"},
  "pekalongan": {lat: -6.8886, lon: 109.6753, label: "KOTA/KAB. PEKALONGAN"},
  "pemalang": {lat: -6.8906, lon: 109.3808, label: "KAB. PEMALANG"},
  "purbalingga": {lat: -7.3881, lon: 109.3639, label: "KAB. PURBALINGGA"},
  "purworejo": {lat: -7.7145, lon: 110.0082, label: "KAB. PURWOREJO"},
  "rembang": {lat: -6.7086, lon: 111.3416, label: "KAB. REMBANG"},
  "sragen": {lat: -7.4265, lon: 111.0221, label: "KAB. SRAGEN"},
  "sukoharjo": {lat: -7.6830, lon: 110.8409, label: "KAB. SUKOHARJO"},
  "tegal": {lat: -6.8694, lon: 109.1402, label: "KOTA/KAB. TEGAL"},
  "temanggung": {lat: -7.3164, lon: 110.1760, label: "KAB. TEMANGGUNG"},
  "wonogiri": {lat: -7.8136, lon: 110.9244, label: "KAB. WONOGIRI"},
  "wonosobo": {lat: -7.3614, lon: 109.9002, label: "KAB. WONOSOBO"},
  "salatiga": {lat: -7.3305, lon: 110.5084, label: "KOTA SALATIGA"},
  "bantul": {lat: -7.8879, lon: 110.3289, label: "KAB. BANTUL"},
  "gunungkidul": {lat: -7.9667, lon: 110.6000, label: "KAB. GUNUNGKIDUL"},
  "kulon progo": {lat: -7.8267, lon: 110.1642, label: "KAB. KULON PROGO"},
  "sleman": {lat: -7.7161, lon: 110.3556, label: "KAB. SLEMAN"},
  "bandung barat": {lat: -6.8452, lon: 107.5023, label: "KAB. BANDUNG BARAT"},
  "ciamis": {lat: -7.3257, lon: 108.3534, label: "KAB. CIAMIS"},
  "cianjur": {lat: -6.8168, lon: 107.1425, label: "KAB. CIANJUR"},
  "garut": {lat: -7.2279, lon: 107.9087, label: "KAB. GARUT"},
  "indramayu": {lat: -6.3276, lon: 108.3249, label: "KAB. INDRAMAYU"},
  "karawang": {lat: -6.3063, lon: 107.3019, label: "KAB. KARAWANG"},
  "kuningan": {lat: -6.9765, lon: 108.4841, label: "KAB. KUNINGAN"},
  "majalengka": {lat: -6.8364, lon: 108.2278, label: "KAB. MAJALENGKA"},
  "pangandaran": {lat: -7.6841, lon: 108.6512, label: "KAB. PANGANDARAN"},
  "purwakarta": {lat: -6.5569, lon: 107.4433, label: "KAB. PURWAKARTA"},
  "subang": {lat: -6.5713, lon: 107.7587, label: "KAB. SUBANG"},
  "sukabumi": {lat: -6.9277, lon: 106.9300, label: "KOTA/KAB. SUKABUMI"},
  "sumedang": {lat: -6.8586, lon: 107.9204, label: "KAB. SUMEDANG"},
  "tasikmalaya": {lat: -7.3274, lon: 108.2207, label: "KOTA/KAB. TASIKMALAYA"},
  "banjar": {lat: -7.3706, lon: 108.5342, label: "KOTA BANJAR"},
  "cimahi": {lat: -6.8722, lon: 107.5425, label: "KOTA CIMAHI"}
};

// DAFTAR 23 BERKAS AUDIO ASLI YANG SUDAH TERTANAM DI DALAM APK (`audio/...`)
const DAFTAR_REKAMAN_ADZAN = [
  { label: "[ Otomatis / Sesuai Waktu ]", file: "" },
  { label: "Adzan Subuh Standar (adzan_subuh.ogg)", file: "audio/adzan_subuh.ogg" },
  { label: "Adzan Subuh Syahdu (Azan Sbh Syahdu.ogg)", file: "audio/Azan Sbh Syahdu.ogg" },
  { label: "Adzan Standar Masjid (adzan.ogg)", file: "audio/adzan.ogg" },
  { label: "Adzan Makkah Standar (adzan_makkah_standar.mp3)", file: "audio/murottal/adzan_makkah_standar.mp3" },
  { label: "Adzan Masjid Kampung (Ajan Masjid Kampung.ogg)", file: "audio/Ajan Masjid Kampung.ogg" }
];

const DAFTAR_REKAMAN_TARHIM = [
  { label: "1. Tarhim Standar Masjid (tarhim.ogg)", file: "audio/tarhim.ogg" },
  { label: "2. Tarhim Syaikh Mahmud Kholil Al-Hussary (Tarhim Mahmud Al Hussary.ogg)", file: "audio/Tarhim Mahmud Al Hussary.ogg" },
  { label: "3. Khusus Pembuka Pra-Murottal Subuh: Ya Arhamarrohimin (Arhamarrohimin Tarhim.ogg)", file: "audio/Arhamarrohimin Tarhim.ogg" }
];

function buatConfigDefault() {
  return {
    provinsiTerpilih: "",
    kota: "",
    kotaTerpilih: "",
    kecamatan: "",
    kecamatanTerpilih: "",
    desaTerpilih: "",
    lokasiDitemukan: "Belum Diatur (Silakan Pilih Wilayah Anda)",
    latitude: 0,
    longitude: 0,
    sudutKiblat: 0,
    master_aktif: false,
    waktuMurottal: 30,
    waktuTarhim: 6,
    waktuAsmaul: 4,
    waktuArham: 10,
    waktuIqomah: 10,
    durasiKhusyuk: 30,
    modeMurottal: "ikatan",
    audioStream: 3,
    volAdzan: 85,
    volMurottal: 75,
    autoVolume: false,
    popupHentikanLuar: true,
    goyangHentikan: false,
    otaAutoUpdate: true,
    getarAwal: false,
    ttsSpeed: 1.0,
    ttsPitch: 1.0,
    ttsVarian: false,
    ikhtiar: 0,
    kor_subuh: 0,
    kor_dzuhur: 0,
    kor_ashar: 0,
    kor_maghrib: 0,
    kor_isya: 0,
    koreksiHijriyah: 0,
    adzan_subuh_on: false,
    adzan_dzuhur_on: false,
    adzan_ashar_on: false,
    adzan_maghrib_on: false,
    adzan_isya_on: false,
    tarhim_subuh_on: false,
    tarhim_dzuhur_on: false,
    tarhim_ashar_on: false,
    tarhim_maghrib_on: false,
    tarhim_isya_on: false,
    s_arham: false,
    s_asmaul: false,
    s_doa_adzan: false,
    s_countdown_iqomah: false,
    s_bel: false,
    s_jam: false,
    menitLaporan5Waktu: 15,
    modeLaporanWaktu: "lima_waktu_dan_ibadah",
    s_tahajud: false,
    s_imsak: false,
    s_preterbit: false,
    s_terbit: false,
    s_dhuha: false,
    s_istiwa: false,
    s_jumat: false,
    s_yasin_malam_jumat: false,
    s_puasa: false,
    s_rawatib: false,
    s_khusyuk: false,
    s_musafir: false,
    s_kehatihatian: false,
    alarm_waktu: "",
    alarm_pesan: "",
    adzanSubuhFile: "audio/adzan_subuh.ogg",
    adzanDzuhurFile: "audio/adzan.ogg",
    adzanAsharFile: "audio/murottal/adzan_makkah_standar.mp3",
    adzanMaghribFile: "audio/adzan.ogg",
    adzanIsyaFile: "audio/Ajan Masjid Kampung.ogg",
    tarhimPilihanUtama: "audio/tarhim.ogg",
    tarhimSubuhFile: "audio/tarhim.ogg",
    tarhimDzuhurFile: "audio/tarhim.ogg",
    tarhimAsharFile: "audio/tarhim.ogg",
    tarhimMaghribFile: "audio/tarhim.ogg",
    tarhimIsyaFile: "audio/tarhim.ogg",
    asmaulFile: "audio/asmaul_husna.mp3",
    doaAdzanFile: "audio/doa_adzan.mp3",
    lastMurottalPath: "",
    lastMurottalPos: 0,
    jadwalSebulan: {},
    profilLokasi: {}
  };
}

function resetKeNolTotal() {
  window.__sedangResetPabrikSengaja = true;
  hentikanAudioDanSimpan();
  jadwalIqomahAktif = null;
  simpanJadwalIqomah();
  try {
    localStorage.removeItem("nidaul_masjid_cfg_v77");
    localStorage.removeItem("nidaul_masjid_backup_otomatis_v97");
    localStorage.removeItem("nidaul_masjid_gembok_v77");
  } catch (e) {}
  gembokAbsolut = {};
  if (window.AndroidBridge && window.AndroidBridge.clearAllStageLocks) {
    try { window.AndroidBridge.clearAllStageLocks(); } catch (e) {}
  }
  cfg = window.cfg = buatConfigDefault();
  simpanData();
  window.__sedangResetPabrikSengaja = false;
}

function aktifkanCepatStandarMasjid() {
  cfg.master_aktif = true;
  cfg.adzan_subuh_on = true;
  cfg.adzan_dzuhur_on = true;
  cfg.adzan_ashar_on = true;
  cfg.adzan_maghrib_on = true;
  cfg.adzan_isya_on = true;
  cfg.tarhim_subuh_on = true;
  cfg.tarhim_dzuhur_on = true;
  cfg.tarhim_ashar_on = true;
  cfg.tarhim_maghrib_on = true;
  cfg.tarhim_isya_on = true;
  cfg.s_arham = true;
  cfg.s_asmaul = true;
  cfg.s_doa_adzan = true;
  cfg.s_countdown_iqomah = true;
  cfg.s_bel = true;
  cfg.s_jam = true;
  cfg.s_tahajud = true;
  cfg.s_imsak = true;
  cfg.s_preterbit = true;
  cfg.s_terbit = true;
  cfg.s_dhuha = true;
  cfg.s_istiwa = true;
  cfg.s_jumat = true;
  cfg.s_yasin_malam_jumat = true;
  cfg.s_puasa = true;
  cfg.s_rawatib = true;
  cfg.getarAwal = true;
  simpanData();
}

var cfg = window.cfg = window.cfg = buatConfigDefault();
let gembokAbsolut = {};
let cacheCuaca = "Cerah Berawan • Suhu 29°C (Rentang Harian: 24°C – 32°C)";
let cacheCuacaSuara = "Prakiraan cuaca wilayah Anda hari ini cerah berawan dengan suhu sekitar 29 derajat Celcius.";
let cacheGempa = "Belum ada peringatan gempa bumi signifikan dari BMKG.";
let tanggalHijriyahCache = "";
let bulanHijriyahIni = "";
let hariHijriyahNum = 0;
let currentAudioObj = null;
let currentAudioTitle = "";
let customAudioBlobs = {};
let kompasListenerAktif = false;
let toastTimer = null;

function tampilkanToastVisual(pesan) {
  const box = document.getElementById("toast-container");
  if (!box) return;
  box.innerHTML = `<div class="toast-banner">${pesan}</div>`;
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { box.innerHTML = ""; }, 4000);
}

// -------------------------------------------------------------------------
// PENYIMPANAN KONFIGURASI & SINKRONISASI KE LAYANAN NATIVE ANDROID 24 JAM
// -------------------------------------------------------------------------
let halamanAktif = "beranda";
let idCounterUnik = 1;

function buatIdElemen(prefix, teks) {
  const slug = String(teks || "item")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 42);
  return `${prefix}-${slug || "elemen"}-${idCounterUnik++}`;
}

// Handler Tombol Kembali HP 2 Tahap Sesuai Permintaan Nur:
// 1. Jika di Sub-Menu -> Kembali ke Beranda Utama APK
// 2. Jika sudah di Beranda Utama APK -> Keluar (Close) menuju Layar Beranda HP (Mesin Latar Belakang Tetap Aktif!)
window.onHardwareBackPressed = function() {
  if (halamanAktif !== "beranda") {
    tampilkanMenuUtama();
    bicaraGoogleTTS("Kembali ke Beranda Utama Nurul Masjid Pro.");
  } else {
    bicaraGoogleTTS("Keluar ke layar beranda ponsel. Mesin pengingat salat tetap aktif di latar belakang.", true);
    if (window.AndroidBridge && window.AndroidBridge.exitToPhoneHome) {
      setTimeout(() => window.AndroidBridge.exitToPhoneHome(), 250);
    } else if (window.AndroidBridge && window.AndroidBridge.hideToBackground) {
      setTimeout(() => window.AndroidBridge.hideToBackground(), 250);
    }
  }
};

function apakahObjekConfigPunyaLokasi(obj) {
  if (!obj || typeof obj !== "object") return false;
  const lat = Number(obj.latitude) || 0;
  const lon = Number(obj.longitude) || 0;
  const k = String(obj.kota || obj.kecamatan || obj.lokasiDitemukan || "").trim().toLowerCase();
  return Boolean(lat !== 0 && lon !== 0 && k && !k.includes("belum diatur"));
}

function ambilConfigTersimpanTerbaik() {
  const kandidatRaw = [];
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.getSavedConfig === "function") {
      const nCfg = window.AndroidBridge.getSavedConfig();
      if (nCfg && nCfg.length > 10) kandidatRaw.push(nCfg);
    }
  } catch (e) {}
  try {
    const r1 = localStorage.getItem("nidaul_masjid_cfg_v77");
    if (r1 && r1.length > 10) kandidatRaw.push(r1);
  } catch (e) {}
  try {
    const r2 = localStorage.getItem("nidaul_masjid_backup_otomatis_v97");
    if (r2 && r2.length > 10) kandidatRaw.push(r2);
  } catch (e) {}
  try {
    const r3 = localStorage.getItem("nidaul_masjid_backup_user_v77");
    if (r3 && r3.length > 10) kandidatRaw.push(r3);
  } catch (e) {}

  let fallbackParsed = null;
  for (let i = 0; i < kandidatRaw.length; i++) {
    try {
      const p = JSON.parse(kandidatRaw[i]);
      if (p && typeof p === "object") {
        if (apakahObjekConfigPunyaLokasi(p)) return p;
        if (!fallbackParsed) fallbackParsed = p;
      }
    } catch (e) {}
  }
  return fallbackParsed;
}

function muatData() {
  const def = buatConfigDefault();
  try {
    const terbaik = ambilConfigTersimpanTerbaik();
    if (terbaik) {
      cfg = window.cfg = Object.assign(buatConfigDefault(), terbaik);
    }
    const rawGembok = localStorage.getItem("nidaul_masjid_gembok_v77");
    if (rawGembok) gembokAbsolut = JSON.parse(rawGembok);
  } catch (e) {}
  const kunciFileAudio = [
    "adzanSubuhFile", "adzanDzuhurFile", "adzanAsharFile", "adzanMaghribFile", "adzanIsyaFile",
    "tarhimSubuhFile", "tarhimDzuhurFile", "tarhimAsharFile", "tarhimMaghribFile", "tarhimIsyaFile"
  ];
  kunciFileAudio.forEach(k => {
    if (!cfg[k] || String(cfg[k]).trim() === "") {
      cfg[k] = def[k];
    }
  });
  // PENTING: Jika asmaulFile di pengaturan lama masih berisi Arhamarrohimin Tarhim.ogg, kosongkan agar Maghrib & Isya tidak salah memutar Ya Arhamarrohimin!
  if (!cfg.asmaulFile || cfg.asmaulFile === "audio/Arhamarrohimin Tarhim.ogg") {
    cfg.asmaulFile = "audio/asmaul_husna.mp3";
  }
  if (typeof cfg.s_yasin_malam_jumat === "undefined") cfg.s_yasin_malam_jumat = false;
  if (!cfg.doaAdzanFile || String(cfg.doaAdzanFile).trim() === "") cfg.doaAdzanFile = "audio/doa_adzan.mp3";
  const fileTarhimValid = [
    "audio/tarhim.ogg",
    "audio/Tarhim Mahmud Al Hussary.ogg",
    "audio/Arhamarrohimin Tarhim.ogg",
    "audio/ya_muhaimin_ya_salam.mp3"
  ];
  ["tarhimSubuhFile", "tarhimDzuhurFile", "tarhimAsharFile", "tarhimMaghribFile", "tarhimIsyaFile"].forEach(kT => {
    if (!cfg[kT] || !fileTarhimValid.includes(cfg[kT])) {
      cfg[kT] = cfg.tarhimPilihanUtama && fileTarhimValid.includes(cfg.tarhimPilihanUtama)
        ? cfg.tarhimPilihanUtama
        : "audio/tarhim.ogg";
    }
  });
  if (!cfg.waktuAsmaul || cfg.waktuAsmaul === 5) cfg.waktuAsmaul = 4;
  if (!cfg.modeLaporanWaktu) cfg.modeLaporanWaktu = "setiap_peringatan";
  if (!cfg.volMurottal || cfg.volMurottal > 90) {
    cfg.volMurottal = 75;
  }
  if (!cfg.volAdzan || cfg.volAdzan > 95) {
    cfg.volAdzan = 85;
  }
  cfg.autoVolume = false;
  if (typeof cfg.provinsiTerpilih === "undefined") cfg.provinsiTerpilih = "";
  if (typeof cfg.kotaTerpilih === "undefined") cfg.kotaTerpilih = "";
  if (typeof cfg.kecamatanTerpilih === "undefined") cfg.kecamatanTerpilih = "";
  if (typeof cfg.desaTerpilih === "undefined") cfg.desaTerpilih = "";
  if (typeof cfg.s_arham === "undefined") cfg.s_arham = false;
  try {
    const rawIq = localStorage.getItem("nidaul_iqomah_aktif_v68");
    if (rawIq) jadwalIqomahAktif = JSON.parse(rawIq);
  } catch (e) {}
  pastikanJadwalTersedia();
}

function simpanData() {
  try {
    if (!window.__sedangResetPabrikSengaja && !apakahObjekConfigPunyaLokasi(cfg)) {
      const tersimpan = ambilConfigTersimpanTerbaik();
      if (tersimpan && apakahObjekConfigPunyaLokasi(tersimpan)) {
        cfg = window.cfg = Object.assign(buatConfigDefault(), tersimpan, {
          goyangHentikan: false,
          popupHentikanLuar: (cfg && typeof cfg.popupHentikanLuar === "boolean") ? cfg.popupHentikanLuar : true
        });
      }
    }
    if (apakahObjekConfigPunyaLokasi(cfg)) {
      const tglIni = (typeof dapatkanTanggalISO === "function") ? dapatkanTanggalISO(0) : "";
      if (tglIni && (!cfg.jadwalSebulan || !cfg.jadwalSebulan[tglIni]) && typeof hitungJadwalKemenagBulanan === "function") {
        cfg.jadwalSebulan = hitungJadwalKemenagBulanan(Number(cfg.latitude), Number(cfg.longitude));
      }
    }
    const jsonStr = JSON.stringify(cfg);
    localStorage.setItem("nidaul_masjid_cfg_v77", jsonStr);
    if (apakahObjekConfigPunyaLokasi(cfg)) {
      localStorage.setItem("nidaul_masjid_backup_otomatis_v97", jsonStr);
    }
    if (window.AndroidBridge) {
      if (window.AndroidBridge.saveConfig) window.AndroidBridge.saveConfig(jsonStr);
      if (window.AndroidBridge.updateNotification) {
        const lok = cfg.kecamatan || cfg.lokasiDitemukan || cfg.kota;
        window.AndroidBridge.updateNotification("Jam Masjid Aktif • " + lok, hitungSisaWaktuTeks().replace(/\n/g, " | "));
      }
    }
  } catch (e) {}
}

function simpanGembok() {
  try {
    localStorage.setItem("nidaul_masjid_gembok_v77", JSON.stringify(gembokAbsolut));
  } catch (e) {}
}

// IndexedDB untuk tambahan berkas audio dari HP (misal pengguna menambahkan MP3 baru)
function bukaDatabaseAudio(cb) {
  try {
    const req = indexedDB.open("NidaulMasjidAudioDB_V61", 1);
    req.onupgradeneeded = function(e) {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("audios")) {
        db.createObjectStore("audios", { keyPath: "name" });
      }
    };
    req.onsuccess = function(e) { cb(e.target.result); };
    req.onerror = function() { cb(null); };
  } catch (e) { cb(null); }
}

function muatSemuaAudioDariDB() {
  bukaDatabaseAudio(function(db) {
    if (!db) return;
    const tx = db.transaction("audios", "readonly");
    const store = tx.objectStore("audios");
    const req = store.getAll();
    req.onsuccess = function() {
      (req.result || []).forEach(item => {
        if (item.name && item.blob) {
          customAudioBlobs[item.name.toLowerCase()] = URL.createObjectURL(item.blob);
        }
      });
    };
  });
}

function simpanFileAudioKeDB(fileList, onSelesai) {
  bukaDatabaseAudio(function(db) {
    if (!db) { if (onSelesai) onSelesai(0); return; }
    const tx = db.transaction("audios", "readwrite");
    const store = tx.objectStore("audios");
    let count = 0;
    for (let i = 0; i < fileList.length; i++) {
      const f = fileList[i];
      if (f.name.match(/\.(mp3|ogg|wav|m4a)$/i)) {
        store.put({ name: f.name, blob: f });
        customAudioBlobs[f.name.toLowerCase()] = URL.createObjectURL(f);
        count++;
      }
    }
    tx.oncomplete = function() { if (onSelesai) onSelesai(count); };
  });
}

// -------------------------------------------------------------------------
// JEMBATAN HTTP NATIVE ANDROID & SINKRONISASI WAKTU NYATA KEMENAG RI (api.myquran.com & api.aladhan.com)
// -------------------------------------------------------------------------
window.DetakJantung = Math.floor(Date.now() / 1000);
window.SesiMesinAktif = 1;
window.TanggalSistem = "";
window.KodeCuacaIni = 0;
window.BulanHijriyahIni = "";
window.__httpCallbacks = {};
let __httpCbCounter = 1;

window.__onNativeHttpResult = function(cbId, sukses, b64Content) {
  const cb = window.__httpCallbacks[cbId];
  delete window.__httpCallbacks[cbId];
  if (!cb) return;
  if (!sukses || !b64Content) {
    cb(false, "");
    return;
  }
  try {
    const binStr = atob(b64Content);
    const bytes = new Uint8Array(binStr.length);
    for (let i = 0; i < binStr.length; i++) {
      bytes[i] = binStr.charCodeAt(i);
    }
    const decoded = new TextDecoder("utf-8").decode(bytes);
    cb(true, decoded);
  } catch (e) {
    cb(false, "");
  }
};

function getAPI(url, callback) {
  if (window.AndroidBridge && typeof window.AndroidBridge.httpGetNative === "function") {
    const cbId = "cb_" + (__httpCbCounter++) + "_" + Date.now();
    window.__httpCallbacks[cbId] = function(sukses, content) {
      if (sukses && content) {
        callback(true, content);
      } else {
        fetch(url)
          .then(r => r.ok ? r.text() : Promise.reject())
          .then(txt => callback(true, txt))
          .catch(() => callback(false, "Peladen menolak akses."));
      }
    };
    try {
      window.AndroidBridge.httpGetNative(url, cbId);
      return;
    } catch (e) {
      delete window.__httpCallbacks[cbId];
    }
  }
  fetch(url)
    .then(r => r.ok ? r.text() : Promise.reject())
    .then(txt => callback(true, txt))
    .catch(() => callback(false, "Peladen menolak akses."));
}

function ekstrakNamaKotaKemenag(teksWilayah) {
  let s = String(teksWilayah || cfg.kotaTerpilih || cfg.kota || "").trim();
  if (s.includes(",")) {
    const parts = s.split(",");
    s = parts[parts.length - 1].trim();
  }
  s = s.replace(/^(kabupaten|kab\.?)\s+/i, "").replace(/^kecamatan\s+/i, "").replace(/^kec\.?\s+/i, "").trim();
  return s || "situbondo";
}

function sinkronisasiJadwalV3Cerdas(namaKotaInput, cb, isSiluman = false) {
  const kClean = ekstrakNamaKotaKemenag(namaKotaInput).toLowerCase();
  const kUrl = encodeURIComponent(kClean);
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");

  getAPI(`https://api.myquran.com/v2/sholat/kota/cari/${kUrl}`, function(s, res) {
    if (!s || !res) {
      sinkronisasiJadwalAladhanKemenag(cb, isSiluman);
      return;
    }
    try {
      const d = JSON.parse(res);
      if (!d || d.status !== true || !Array.isArray(d.data) || d.data.length === 0) {
        sinkronisasiJadwalAladhanKemenag(cb, isSiluman);
        return;
      }
      const fObj = d.data[0];
      const id = String(fObj.id || "").trim();
      const nResmi = String(fObj.lokasi || "").trim();
      if (!id) {
        sinkronisasiJadwalAladhanKemenag(cb, isSiluman);
        return;
      }
      cfg.idKota = id;
      if (!cfg.kecamatan) {
        cfg.lokasiDitemukan = nResmi;
      } else {
        cfg.lokasiDitemukan = `${cfg.kecamatan} (${nResmi})`;
      }
      simpanData();

      getAPI(`https://api.myquran.com/v2/sholat/jadwal/${id}/${yyyy}/${mm}`, function(s2, res2) {
        if (!s2 || !res2) {
          sinkronisasiJadwalAladhanKemenag(cb, isSiluman);
          return;
        }
        try {
          const d2 = JSON.parse(res2);
          if (!d2 || d2.status !== true || !d2.data || !Array.isArray(d2.data.jadwal)) {
            sinkronisasiJadwalAladhanKemenag(cb, isSiluman);
            return;
          }
          const jadwalBaru = {};
          d2.data.jadwal.forEach(item => {
            const tgl = String(item.date || "").trim();
            if (tgl) {
              jadwalBaru[tgl] = {
                Subuh: String(item.subuh || "").trim(),
                Terbit: String(item.terbit || "").trim(),
                Dhuha: String(item.dhuha || "").trim(),
                Dzuhur: String(item.dzuhur || "").trim(),
                Ashar: String(item.ashar || "").trim(),
                Maghrib: String(item.maghrib || "").trim(),
                Isya: String(item.isya || "").trim()
              };
            }
          });
          if (Object.keys(jadwalBaru).length > 0) {
            // Terapkan presisi waktu nyata tingkat Kecamatan & Kelurahan/Desa berdasarkan selisih bujur nyata terhadap pusat Kabupaten/Kota
            let deltaMenitDesa = 0;
            const kKabClean = ekstrakNamaKotaKemenag(namaKotaInput).toLowerCase();
            const pusatKab = KOORDINAT_KOTA_NASIONAL[kKabClean];
            const lonDesaAktif = Number(cfg.longitude) || 0;
            if (pusatKab && lonDesaAktif !== 0 && Math.abs(pusatKab.lon - lonDesaAktif) >= 0.08) {
              // Setiap 1 derajat bujur bumi = 4 menit waktu matahari nyata (Wilayah lebih timur masuk waktu lebih awal, lebih barat lebih lambat)
              deltaMenitDesa = Math.round((pusatKab.lon - lonDesaAktif) * 4.0);
            }
            if (deltaMenitDesa !== 0) {
              Object.keys(jadwalBaru).forEach(tglK => {
                const rowJ = jadwalBaru[tglK];
                rowJ.Subuh = tambahMenit(rowJ.Subuh, deltaMenitDesa);
                rowJ.Terbit = tambahMenit(rowJ.Terbit, deltaMenitDesa);
                rowJ.Dhuha = tambahMenit(rowJ.Dhuha, deltaMenitDesa);
                rowJ.Dzuhur = tambahMenit(rowJ.Dzuhur, deltaMenitDesa);
                rowJ.Ashar = tambahMenit(rowJ.Ashar, deltaMenitDesa);
                rowJ.Maghrib = tambahMenit(rowJ.Maghrib, deltaMenitDesa);
                rowJ.Isya = tambahMenit(rowJ.Isya, deltaMenitDesa);
              });
            }
            cfg.jadwalSebulan = jadwalBaru;
            simpanData();
            if (cb) cb(true, nResmi);
            return;
          }
        } catch (e2) {}
        sinkronisasiJadwalAladhanKemenag(cb, isSiluman);
      });
    } catch (e) {
      sinkronisasiJadwalAladhanKemenag(cb, isSiluman);
    }
  });
}

function sinkronisasiJadwalAladhanKemenag(cb, isSiluman = false) {
  const lat = Number(cfg.latitude) || -7.7062;
  const lon = Number(cfg.longitude) || 114.0098;
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = now.getMonth() + 1;
  getAPI(`https://api.aladhan.com/v1/calendar/${yyyy}/${mm}?latitude=${lat}&longitude=${lon}&method=20`, function(s, res) {
    if (!s || !res) {
      if (cb) cb(false, "Gagal menghubungi peladen jadwal Kemenag.");
      return;
    }
    try {
      const d = JSON.parse(res);
      if (!d || !Array.isArray(d.data)) {
        if (cb) cb(false, "Format jadwal tidak sesuai.");
        return;
      }
      const jadwalBaru = {};
      const cleanJam = (v) => String(v || "").replace(/\s*\(.*?\)/g, "").trim().substring(0, 5);
      d.data.forEach(item => {
        if (item && item.date && item.date.gregorian && item.timings) {
          const parts = String(item.date.gregorian.date || "").split("-");
          if (parts.length === 3) {
            const tglKey = `${parts[2]}-${parts[1]}-${parts[0]}`;
            const terbitStr = cleanJam(item.timings.Sunrise);
            jadwalBaru[tglKey] = {
              Subuh: cleanJam(item.timings.Fajr),
              Terbit: terbitStr,
              Dhuha: tambahMenit(terbitStr, 20),
              Dzuhur: cleanJam(item.timings.Dhuhr),
              Ashar: cleanJam(item.timings.Asr),
              Maghrib: cleanJam(item.timings.Maghrib),
              Isya: cleanJam(item.timings.Isha)
            };
          }
        }
      });
      if (Object.keys(jadwalBaru).length > 0) {
        if (!cfg.idKota) cfg.idKota = "KEMENAG-20";
        cfg.jadwalSebulan = jadwalBaru;
        simpanData();
        if (cb) cb(true, cfg.lokasiDitemukan || cfg.kota);
        return;
      }
    } catch (e) {}
    if (cb) cb(false, "Gagal memuat jadwal.");
  });
}

window.__cacheHijriyahApiPerOffset = window.__cacheHijriyahApiPerOffset || {};
window.__koreksiOtomatisApiHijri = window.__koreksiOtomatisApiHijri || 0;

function ambilTanggalHijriyah(offsetHari = 0, callback = null) {
  const shiftMaghrib = (offsetHari === 0 && isLewatMaghrib());
  let tRealMs = Date.now() + (offsetHari * 86400000);
  if (shiftMaghrib) tRealMs += 86400000;
  const hariList = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const namaHari = hariList[new Date(tRealMs).getDay()];

  const korManual = Number(cfg.koreksiHijriyah) || 0;
  const tHijriMs = tRealMs + (korManual * 86400000);
  const dtH = new Date(tHijriMs);
  const tglFormatApi = `${String(dtH.getDate()).padStart(2, "0")}-${String(dtH.getMonth() + 1).padStart(2, "0")}-${dtH.getFullYear()}`;
  const cacheKey = `${tglFormatApi}_${shiftMaghrib ? 1 : 0}_${korManual}`;

  getAPI(`https://api.aladhan.com/v1/gToH/${tglFormatApi}`, function(sukses, content) {
    if (sukses && content) {
      try {
        const d = JSON.parse(content);
        if (d && d.data && d.data.hijri) {
          const h = d.data.hijri;
          const mEn = (h.month && h.month.en) ? h.month.en : "";
          const petaBulan = {
            "Muharram": "Muharram",
            "Safar": "Safar",
            "Rabi' al-awwal": "Rabiul Awal",
            "Rabi' al-thani": "Rabiul Akhir",
            "Jumada al-awwal": "Jumadil Awal",
            "Jumada al-thani": "Jumadil Akhir",
            "Rajab": "Rajab",
            "Sha'ban": "Syakban",
            "Ramadan": "Ramadhan",
            "Shawwal": "Syawal",
            "Dhu al-Qi'dah": "Zulkaidah",
            "Dhu al-Hijjah": "Zulhijah"
          };
          const daftarBulan = ["Muharram", "Safar", "Rabiul Awal", "Rabiul Akhir", "Jumadil Awal", "Jumadil Akhir", "Rajab", "Syakban", "Ramadhan", "Syawal", "Zulkaidah", "Zulhijah"];
          const mNum = (h.month && Number(h.month.number)) ? Number(h.month.number) : (daftarBulan.indexOf(petaBulan[mEn] || mEn) + 1);
          const nBulan = petaBulan[mEn] || daftarBulan[Math.max(0, Math.min(11, mNum - 1))] || mEn;
          const dayNum = Number(h.day) || 1;
          const yrNum = Number(h.year) || 1448;
          const yrStr = String(yrNum);
          const teksHasil = `${shiftMaghrib ? "Malam " : ""}${namaHari}, ${dayNum} ${nBulan} ${yrStr} Hijriyah`;

          // Gunakan tanggal standar Kemenag RI / MABIMS agar selaras dengan Kalender Jawa & Hilal Indonesia
          const baseKemenag = konversiMsKeHijriyahMurni(tHijriMs);
          const hdResmiIndo = (baseKemenag && baseKemenag.hm === mNum && baseKemenag.hy === yrNum && Math.abs(dayNum - baseKemenag.hd) <= 1)
            ? baseKemenag.hd
            : dayNum;
          const teksHasilIndo = `${shiftMaghrib ? "Malam " : ""}${namaHari}, ${hdResmiIndo} ${nBulan} ${yrStr} Hijriyah`;

          window.__cacheHijriyahApiPerOffset[cacheKey] = {
            teksLengkap: teksHasilIndo,
            hd: hdResmiIndo,
            hm: mNum || 1,
            nBulan: nBulan,
            hy: yrNum,
            dtMasehi: new Date(tRealMs)
          };

          if (offsetHari === 0) {
            tanggalHijriyahCache = `${hdResmiIndo} ${nBulan} ${yrStr} H`;
            hariHijriyahNum = hdResmiIndo;
            bulanHijriyahIni = nBulan;
            window.BulanHijriyahIni = nBulan;
            const elSub = document.getElementById("live-clock-sub-hijri");
            if (elSub) elSub.textContent = infoHariBesarIslam(0);
            const elKal = document.getElementById("btn-info-hari-pasaran");
            if (elKal) {
              const teksKalBaru = `Kalender Hari Ini: ${formatTanggalIndo(dapatkanTanggalISO(0))} (${hitungPasaranJawa(0)}) • ${tanggalHijriyahCache}`;
              elKal.textContent = teksKalBaru;
              elKal.setAttribute("aria-label", teksKalBaru);
            }
          }
          if (callback) callback(teksHasilIndo, hdResmiIndo, nBulan);
          return;
        }
      } catch (e) {}
    }
    const lokal = hitungHijriyahLokal(offsetHari);
    if (callback) callback(lokal.teksLengkap, lokal.hd, lokal.nBulan);
  });
}

// -------------------------------------------------------------------------
// KALKULATOR FALAKIYAH KEMENAG RI & KALENDER HIJRIYAH + PASARAN JAWA
// -------------------------------------------------------------------------
function hitungSudutKiblat(lat, lon) {
  const latK = 21.422510 * Math.PI / 180.0;
  const lonK = 39.826168 * Math.PI / 180.0;
  const phi = (Number(lat) || -7.7062) * Math.PI / 180.0;
  const dLon = lonK - ((Number(lon) || 114.0095) * Math.PI / 180.0);
  const y = Math.sin(dLon);
  const x = Math.cos(phi) * Math.tan(latK) - Math.sin(phi) * Math.cos(dLon);
  const brng = Math.atan2(y, x) * 180.0 / Math.PI;
  return Math.round((brng + 360) % 360);
}

function hitungJadwalKemenagSatuHari(lat, lon, year, month, day) {
  let tz = 7;
  if (lon >= 135.0) tz = 9;
  else if (lon >= 114.5) tz = 8;

  const start = new Date(year, 0, 0);
  const diff = new Date(year, month - 1, day) - start;
  const doy = Math.floor(diff / 86400000);
  const gamma = (2.0 * Math.PI / 365.0) * (doy - 0.5);

  const eqtime = 229.18 * (0.000075 + 0.001868 * Math.cos(gamma) - 0.032077 * Math.sin(gamma) - 0.014615 * Math.cos(2 * gamma) - 0.040849 * Math.sin(2 * gamma));
  const decl = 0.006918 - 0.399912 * Math.cos(gamma) + 0.070257 * Math.sin(gamma) - 0.006758 * Math.cos(2 * gamma) + 0.000907 * Math.sin(2 * gamma) - 0.002697 * Math.cos(3 * gamma) + 0.00148 * Math.sin(3 * gamma);
  const latRad = lat * Math.PI / 180.0;
  const transit = 720.0 - (4.0 * lon) - eqtime + (tz * 60.0);

  function haMenit(zenithDeg) {
    const zRad = zenithDeg * Math.PI / 180.0;
    let cosHa = (Math.cos(zRad) - Math.sin(latRad) * Math.sin(decl)) / (Math.cos(latRad) * Math.cos(decl));
    cosHa = Math.max(-1.0, Math.min(1.0, cosHa));
    return (Math.acos(cosHa) * 180.0 / Math.PI) * 4.0;
  }

  const subuhM = transit - haMenit(110.0) + 2.0;
  const terbitM = transit - haMenit(90.8333) - 2.0;
  const dhuhaM = terbitM + 20.0;
  const dzuhurM = transit + 2.0;
  const asrAlt = Math.atan(1.0 / (1.0 + Math.tan(Math.abs(latRad - decl))));
  const asrZenith = 90.0 - (asrAlt * 180.0 / Math.PI);
  const asharM = transit + haMenit(asrZenith) + 2.0;
  const maghribM = transit + haMenit(90.8333) + 2.0;
  const isyaM = transit + haMenit(108.0) + 2.0;

  function fmtJam(m) {
    let tot = Math.ceil(m) % 1440;
    if (tot < 0) tot += 1440;
    return String(Math.floor(tot / 60)).padStart(2, "0") + ":" + String(tot % 60).padStart(2, "0");
  }

  return {
    Subuh: fmtJam(subuhM),
    Terbit: fmtJam(terbitM),
    Dhuha: fmtJam(dhuhaM),
    Dzuhur: fmtJam(dzuhurM),
    Ashar: fmtJam(asharM),
    Maghrib: fmtJam(maghribM),
    Isya: fmtJam(isyaM)
  };
}

function hitungJadwalKemenagBulanan(lat, lon, year, month) {
  const now = new Date();
  const y = year || now.getFullYear();
  const m = month || (now.getMonth() + 1);
  const hasil = {};
  for (let d = 1; d <= 31; d++) {
    const dt = new Date(y, m - 1, d);
    if (dt.getMonth() + 1 === m) {
      const key = y + "-" + String(m).padStart(2, "0") + "-" + String(d).padStart(2, "0");
      hasil[key] = hitungJadwalKemenagSatuHari(Number(lat) || -7.7062, Number(lon) || 114.0095, y, m, d);
    }
  }
  return hasil;
}

function apakahLokasiSudahDiatur() {
  if (!cfg) return false;
  const lokValid = (s) => Boolean(s && String(s).trim() && !String(s).toLowerCase().includes("belum diatur"));
  if (!lokValid(cfg.kota)) {
    if (lokValid(cfg.kecamatan)) cfg.kota = cfg.kecamatan;
    else if (lokValid(cfg.lokasiDitemukan)) cfg.kota = cfg.lokasiDitemukan;
  }
  return Boolean(lokValid(cfg.kota) && Number(cfg.latitude) !== 0 && Number(cfg.longitude) !== 0);
}

let __sedangSinkronJadwal = false;
function pastikanJadwalTersedia() {
  if (!apakahLokasiSudahDiatur()) {
    cfg.jadwalSebulan = {};
    cfg.sudutKiblat = 0;
    return;
  }
  const tglIni = dapatkanTanggalISO(0);
  if (!cfg.jadwalSebulan || !cfg.jadwalSebulan[tglIni]) {
    cfg.jadwalSebulan = hitungJadwalKemenagBulanan(Number(cfg.latitude), Number(cfg.longitude));
    cfg.sudutKiblat = hitungSudutKiblat(Number(cfg.latitude), Number(cfg.longitude));
    if (typeof simpanData === "function") simpanData();
    if (!__sedangSinkronJadwal) {
      __sedangSinkronJadwal = true;
      sinkronisasiJadwalV3Cerdas(cfg.kotaTerpilih || cfg.kota, () => {
        __sedangSinkronJadwal = false;
      }, true);
    }
  } else if (!cfg.idKota && !__sedangSinkronJadwal) {
    __sedangSinkronJadwal = true;
    sinkronisasiJadwalV3Cerdas(cfg.kotaTerpilih || cfg.kota, () => {
      __sedangSinkronJadwal = false;
    }, true);
  }
}

function dapatkanTanggalISO(offsetHari = 0) {
  const d = new Date(Date.now() + offsetHari * 86400000);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function formatTanggalIndo(tglStr) {
  const parts = (tglStr || dapatkanTanggalISO(0)).split("-");
  if (parts.length !== 3) return tglStr;
  const dt = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
  const hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const bln = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
  return `${hari[dt.getDay()]}, ${Number(parts[2])} ${bln[Number(parts[1]) - 1]} ${parts[0]}`;
}

function tambahMenit(wStr, menit) {
  if (!wStr || !wStr.includes(":")) return "";
  const [h, m] = wStr.split(":").map(Number);
  let tot = (h * 60 + m + Number(menit || 0)) % 1440;
  if (tot < 0) tot += 1440;
  return String(Math.floor(tot / 60)).padStart(2, "0") + ":" + String(tot % 60).padStart(2, "0");
}

function hitungMenitAbsolut(wStr) {
  if (!wStr || !wStr.includes(":")) return -1;
  const [h, m] = wStr.split(":").map(Number);
  if (isNaN(h) || isNaN(m)) return -1;
  return h * 60 + m;
}

function waktuSholatTerkoreksi(jdw, namaWaktu) {
  if (!jdw || !jdw[namaWaktu]) return "";
  if (namaWaktu === "Terbit" || namaWaktu === "Dhuha") return jdw[namaWaktu];
  const mapKor = {
    Subuh: cfg.kor_subuh || 0,
    Dzuhur: cfg.kor_dzuhur || 0,
    Ashar: cfg.kor_ashar || 0,
    Maghrib: cfg.kor_maghrib || 0,
    Isya: cfg.kor_isya || 0
  };
  return tambahMenit(jdw[namaWaktu], (Number(cfg.ikhtiar) || 0) + (Number(mapKor[namaWaktu]) || 0));
}

function isLewatMaghrib() {
  const jdw = cfg.jadwalSebulan && cfg.jadwalSebulan[dapatkanTanggalISO(0)];
  const now = new Date();
  const skrgM = now.getHours() * 60 + now.getMinutes();
  if (!jdw || !jdw.Maghrib) return skrgM >= 17 * 60 + 30;
  return skrgM >= hitungMenitAbsolut(waktuSholatTerkoreksi(jdw, "Maghrib"));
}

function konversiMsKeHijriyahMurni(msTarget) {
  const daftarBulan = ["Muharram", "Safar", "Rabiul Awal", "Rabiul Akhir", "Jumadil Awal", "Jumadil Akhir", "Rajab", "Syakban", "Ramadhan", "Syawal", "Zulkaidah", "Zulhijah"];
  const dt = new Date(msTarget);
  // Algoritma Falakiyah Standar Kemenag RI / MABIMS & Kalender Sultan Agung
  // (Terverifikasi 27 Okt 2026 = 15 Jumadil Awal 1448 H, 28 Okt 2026 = 16 Jumadil Awal 1448 H, 1 Nov 2026 = 20 Jumadil Awal 1448 H)
  let y = dt.getFullYear();
  let m = dt.getMonth() + 1;
  const d = dt.getDate();
  if (m < 3) { y -= 1; m += 12; }
  const a = Math.floor(y / 100.0);
  const b = 2 - a + Math.floor(a / 4.0);
  const jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + b - 1524;
  let l = jd - 1948440 + 10632;
  const n = Math.floor((l - 1) / 10631.0);
  l = l - 10631 * n + 354;
  const j = Math.floor((10985 - l) / 5316.0) * Math.floor((50 * l) / 17719.0) + Math.floor(l / 5670.0) * Math.floor((43 * l) / 15238.0);
  l = l - Math.floor((30 - j) / 15.0) * Math.floor((17719 * j) / 50.0) - mathFloorDiv(j, 16) * mathFloorDiv(15238 * j, 43) + 29;
  const hm = Math.max(1, Math.min(12, Math.floor((24 * l) / 709.0)));
  const hd = Math.max(1, Math.min(30, l - Math.floor((709 * hm) / 24.0)));
  const hy = 30 * n + j - 30;
  return { hd, hm, nBulan: daftarBulan[hm - 1], hy };
}

function mathFloorDiv(a, b) {
  return Math.floor(a / b);
}

function hitungKalenderJawaLengkap(offsetHari = 0, abaikanShiftMaghrib = false) {
  const shiftMaghrib = (!abaikanShiftMaghrib && offsetHari === 0 && isLewatMaghrib());
  const korManual = Number(cfg && cfg.koreksiHijriyah) || 0;
  let tRealMs = Date.now() + (offsetHari * 86400000);
  if (shiftMaghrib) tRealMs += 86400000;
  const dtWeton = new Date(tRealMs);

  // Patokan mutlak Weton & Pasaran Jawa: Jumat Legi, 17 Agustus 1945 (UTC murni bebas geser zona waktu)
  const utcTarget = Date.UTC(dtWeton.getFullYear(), dtWeton.getMonth(), dtWeton.getDate());
  const utcProklamasi = Date.UTC(1945, 7, 17); // Jumat Legi (index Legi = 0)
  const selisihHari = Math.round((utcTarget - utcProklamasi) / 86400000);

  const daftarHari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const neptuHariMap = [5, 4, 3, 7, 8, 6, 9]; // Minggu=5, Senin=4, Selasa=3, Rabu=7, Kamis=8, Jumat=6, Sabtu=9

  const daftarPasaran = ["Legi", "Pahing", "Pon", "Wage", "Kliwon"];
  const neptuPasaranMap = [5, 9, 7, 4, 8]; // Legi=5, Pahing=9, Pon=7, Wage=4, Kliwon=8

  const idxHari = dtWeton.getDay();
  const idxPasaran = ((selisihHari % 5) + 5) % 5;

  const hariNama = daftarHari[idxHari];
  const pasaranNama = daftarPasaran[idxPasaran];
  const neptuHari = neptuHariMap[idxHari];
  const neptuPasaran = neptuPasaranMap[idxPasaran];
  const neptuTotal = neptuHari + neptuPasaran;

  // Perhitungan 30 Wuku Pawukon Jawa:
  // Patokan mutlak: Minggu Pahing, 5 April 2026 & Minggu Pahing, 1 November 2026 adalah awal Wuku Sinta (index 0)
  const daftarWuku = [
    "Sinta", "Landep", "Wukir", "Kurantil", "Tolu",
    "Gumbreg", "Warigalit", "Warigagung", "Julungwangi", "Sungsang",
    "Galungan", "Kuningan", "Langkir", "Mandasiya", "Julungpujut",
    "Pahang", "Kuruwelut", "Marakeh", "Tambir", "Medangkungan",
    "Maktal", "Wuye", "Manahil", "Prangbakat", "Bala",
    "Wugu", "Wayang", "Kulawu", "Dukut", "Watugunung"
  ];
  const utcSintaRef = Date.UTC(2026, 3, 5); // Minggu Pahing, 5 April 2026 = Awal Wuku Sinta
  const selisihSinta = Math.round((utcTarget - utcSintaRef) / 86400000);
  const hariSiklus210 = ((selisihSinta % 210) + 210) % 210;
  const idxWuku = Math.floor(hariSiklus210 / 7);
  const namaWuku = daftarWuku[idxWuku];
  const nomorWuku = idxWuku + 1;

  // Perhitungan Tanggal, Bulan, Tahun Jawa (Sultan Agung) & Siklus 8 Tahun (Sewindu)
  const daftarBulanJawa = [
    "Sura", "Sapar", "Mulud", "Bakda Mulud", "Jumadilawal", "Jumadilakhir",
    "Rejeb", "Ruwah", "Pasa", "Sawal", "Sela", "Besar"
  ];
  const hMurni = konversiMsKeHijriyahMurni(tRealMs + (korManual * 86400000));
  const tglJawa = hMurni.hd;
  const bulanJawa = daftarBulanJawa[Math.max(0, Math.min(11, hMurni.hm - 1))];
  const tahunJawa = hMurni.hy + 512;

  // Daur 8 Tahun Jawa (Sewindu) dimulai dari 1555 Jawa = Tahun Alip
  const daftarNamaTahunJawa = ["Alip", "Ehe", "Jimawal", "Je", "Dal", "Be", "Wawu", "Jimakir"];
  const idxTahunJawa = (((tahunJawa - 1555) % 8) + 8) % 8;
  const namaTahunJawa = daftarNamaTahunJawa[idxTahunJawa];

  // Daur 4 Windu (32 Tahun): Kuntara, Sengara, Sancaya, Adi
  const daftarWindu = ["Kuntara", "Sengara", "Sancaya", "Adi"];
  const idxWindu = ((Math.floor((tahunJawa - 1555) / 8) % 4) + 4) % 4;
  const namaWindu = daftarWindu[idxWindu];

  const awalanMalam = shiftMaghrib ? "Malam " : "";
  const weton = `${awalanMalam}${hariNama} ${pasaranNama}`;
  const teksTanggalJawa = `${tglJawa} ${bulanJawa} ${tahunJawa} ${namaTahunJawa}`;
  const teksNeptu = `Neptu ${neptuTotal} (${hariNama} ${neptuHari} + ${pasaranNama} ${neptuPasaran})`;
  const teksWuku = `Wuku ${namaWuku} (${nomorWuku}/30)`;
  const teksRingkas = `${weton}, ${teksTanggalJawa} (${teksNeptu} • Wuku ${namaWuku})`;
  const teksLengkap = `${weton}, ${tglJawa} ${bulanJawa} ${tahunJawa} Tahun ${namaTahunJawa} (Windu ${namaWindu}) • ${teksNeptu} • ${teksWuku}`;

  return {
    weton,
    hariNama,
    pasaranNama,
    neptuHari,
    neptuPasaran,
    neptuTotal,
    tglJawa,
    bulanJawa,
    tahunJawa,
    namaTahunJawa,
    namaWindu,
    namaWuku,
    nomorWuku,
    teksTanggalJawa,
    teksNeptu,
    teksWuku,
    teksRingkas,
    teksLengkap
  };
}

function hitungPasaranJawa(offsetHari = 0) {
  const jw = hitungKalenderJawaLengkap(offsetHari);
  return `${jw.weton}, ${jw.teksTanggalJawa} (Neptu ${jw.neptuTotal} • Wuku ${jw.namaWuku})`;
}

function hitungHijriyahLokal(offsetHari = 0, abaikanShiftMaghrib = false) {
  const shiftMaghrib = (!abaikanShiftMaghrib && offsetHari === 0 && isLewatMaghrib());
  let tRealMs = Date.now() + (offsetHari * 86400000);
  if (shiftMaghrib) tRealMs += 86400000;
  const korManual = Number(cfg.koreksiHijriyah) || 0;
  const tHijriMs = tRealMs + (korManual * 86400000);
  const dtH = new Date(tHijriMs);
  const tglFormatApi = `${String(dtH.getDate()).padStart(2, "0")}-${String(dtH.getMonth() + 1).padStart(2, "0")}-${dtH.getFullYear()}`;
  const cacheKey = `${tglFormatApi}_${shiftMaghrib ? 1 : 0}_${korManual}`;

  if (window.__cacheHijriyahApiPerOffset && window.__cacheHijriyahApiPerOffset[cacheKey]) {
    const cached = window.__cacheHijriyahApiPerOffset[cacheKey];
    if (offsetHari === 0 && !abaikanShiftMaghrib) {
      tanggalHijriyahCache = `${cached.hd} ${cached.nBulan} ${cached.hy} H`;
      hariHijriyahNum = cached.hd;
      bulanHijriyahIni = cached.nBulan;
      window.BulanHijriyahIni = cached.nBulan;
    }
    return cached;
  }

  const korOtomatis = Number(window.__koreksiOtomatisApiHijri) || 0;
  const hasil = konversiMsKeHijriyahMurni(tHijriMs + (korOtomatis * 86400000));
  const hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const dtReal = new Date(tRealMs);
  const teksLengkap = (shiftMaghrib ? "Malam " : "") + hari[dtReal.getDay()] + ", " + hasil.hd + " " + hasil.nBulan + " " + hasil.hy + " Hijriyah";

  if (offsetHari === 0 && !abaikanShiftMaghrib) {
    tanggalHijriyahCache = `${hasil.hd} ${hasil.nBulan} ${hasil.hy} H`;
    hariHijriyahNum = hasil.hd;
    bulanHijriyahIni = hasil.nBulan;
    window.BulanHijriyahIni = hasil.nBulan;
  }
  return { teksLengkap, hd: hasil.hd, hm: hasil.hm, nBulan: hasil.nBulan, hy: hasil.hy, dtMasehi: dtReal };
}

function cekNamaHariBesarHijriyah(hm, hd) {
  if (hm === 1 && hd === 1) return "Tahun Baru Islam 1 Muharram";
  if (hm === 1 && hd === 9) return "Puasa Sunnah Tasu'a (9 Muharram)";
  if (hm === 1 && hd === 10) return "Puasa Sunnah Asyura (10 Muharram)";
  if (hm === 3 && hd === 12) return "Maulid Nabi Muhammad SAW (12 Rabiul Awal)";
  if (hm === 7 && hd === 1) return "Awal Bulan Mulia Rajab (1 Rajab)";
  if (hm === 7 && hd === 27) return "Isra Mi'raj Nabi Muhammad SAW (27 Rajab)";
  if (hm === 8 && hd === 15) return "Malam & Hari Nisfu Syakban (15 Syakban)";
  if (hm === 9 && hd === 1) return "Awal Puasa Bulan Suci Ramadhan (1 Ramadhan)";
  if (hm === 9 && hd === 17) return "Peringatan Nuzulul Qur'an (17 Ramadhan)";
  if (hm === 9 && hd >= 21 && hd % 2 === 1) return `Malam Ganjil 10 Terakhir Ramadhan (${hd} Ramadhan — Lailatul Qadar)`;
  if (hm === 10 && hd === 1) return "Hari Raya Idul Fitri (1 Syawal)";
  if (hm === 10 && hd === 2) return "Hari Raya Kedua Idul Fitri & Awal Puasa Sunnah Syawal (2 Syawal)";
  if (hm === 12 && hd === 1) return "Awal 10 Hari Pertama Bulan Mulia Zulhijah (1 Zulhijah)";
  if (hm === 12 && hd === 8) return "Puasa Sunnah Tarwiyah (8 Zulhijah)";
  if (hm === 12 && hd === 9) return "Puasa Sunnah Wukuf Arafah (9 Zulhijah)";
  if (hm === 12 && hd === 10) return "Hari Raya Idul Adha (10 Zulhijah)";
  if (hm === 12 && (hd === 11 || hd === 12 || hd === 13)) return `Hari Tasyrik Idul Adha (${hd} Zulhijah — Diharamkan Puasa)`;
  return "";
}

function infoPuasaDanAmalanTerdekat(offsetHari = 0) {
  const hSkrg = hitungHijriyahLokal(offsetHari);
  const dtSkrg = hSkrg.dtMasehi || new Date(Date.now() + offsetHari * 86400000);
  const hariMasehi = dtSkrg.getDay(); // 1 = Senin, 4 = Kamis, 5 = Jumat

  const dilarangPuasa = (hSkrg.hm === 10 && hSkrg.hd === 1) || (hSkrg.hm === 12 && hSkrg.hd >= 10 && hSkrg.hd <= 13);
  const infoList = [];

  if (hSkrg.hm === 9) {
    infoList.push(`Sedang Berjalan: Ibadah Puasa Wajib Ramadhan Hari ke-${hSkrg.hd}`);
  } else if (dilarangPuasa) {
    infoList.push(`Status Hari Ini: Hari Raya / Hari Tasyrik (Diharamkan Berpuasa)`);
  } else {
    if (hSkrg.hd >= 13 && hSkrg.hd <= 15) {
      infoList.push(`Hari Ini: Jadwal Puasa Sunnah Ayyamul Bidh (${hSkrg.hd} ${hSkrg.nBulan})`);
    }
    if (hariMasehi === 1) {
      infoList.push("Hari Ini: Jadwal Puasa Sunnah Hari Senin");
    } else if (hariMasehi === 4) {
      infoList.push("Hari Ini: Jadwal Puasa Sunnah Hari Kamis");
    } else if (hariMasehi === 5) {
      infoList.push("Hari Ini: Hari Jumat Berkah (Amalan Surah Al-Kahfi, Yasin & Shalawat)");
    }
  }

  // Cari Ayyamul Bidh berikutnya (tanggal 13 Hijriyah) secara nyata hari demi hari
  let hariKeAyyamulBidh = -1;
  let teksAyyamulBidh = "";
  for (let d = 1; d <= 35; d++) {
    const hCek = hitungHijriyahLokal(offsetHari + d, true);
    if (hCek.hd === 13 && !(hCek.hm === 12 && hCek.hd === 13) && hCek.hm !== 9) {
      hariKeAyyamulBidh = d;
      const tglMasehiAb = formatTanggalIndo(dapatkanTanggalISO(offsetHari + d));
      teksAyyamulBidh = `Puasa Sunnah Ayyamul Bidh (13–15 ${hCek.nBulan}): ${d} hari lagi (${tglMasehiAb})`;
      break;
    }
  }
  if (teksAyyamulBidh) infoList.push(teksAyyamulBidh);

  // Cari Puasa Senin / Kamis berikutnya bila bukan bulan Ramadhan
  if (hSkrg.hm !== 9) {
    for (let d = 1; d <= 7; d++) {
      const dtCek = new Date(Date.now() + (offsetHari + d) * 86400000);
      const dow = dtCek.getDay();
      if (dow === 1 || dow === 4) {
        const hCek = hitungHijriyahLokal(offsetHari + d, true);
        const haram = (hCek.hm === 10 && hCek.hd === 1) || (hCek.hm === 12 && hCek.hd >= 10 && hCek.hd <= 13);
        if (!haram) {
          const namaSeninKamis = dow === 1 ? "Puasa Sunnah Senin" : "Puasa Sunnah Kamis";
          infoList.push(`${namaSeninKamis} Terdekat: ${d === 1 ? "Besok" : d + " hari lagi"} (${formatTanggalIndo(dapatkanTanggalISO(offsetHari + d))})`);
          break;
        }
      }
    }
  }

  return infoList.join(" • ");
}

function infoHariBesarIslam(offsetHari = 0) {
  const hSkrg = hitungHijriyahLokal(offsetHari);
  const tglHijriTeks = `${hSkrg.hd} ${hSkrg.nBulan} ${hSkrg.hy} H`;

  // 1. Cek apakah tepat hari ini adalah Hari Besar Islam
  const hariBesarHariIni = cekNamaHariBesarHijriyah(hSkrg.hm, hSkrg.hd);

  // 2. Pindai nyata hari demi hari (1 s/d 360 hari ke depan dari tanggal yang dipilih)
  const daftarMendatang = [];
  const sudahMasuk = {};
  for (let d = 1; d <= 360; d++) {
    const hCek = hitungHijriyahLokal(offsetHari + d, true);
    const namaHb = cekNamaHariBesarHijriyah(hCek.hm, hCek.hd);
    if (namaHb && !namaHb.includes("Malam Ganjil") && !namaHb.includes("Hari Tasyrik") && !namaHb.includes("Hari Raya Kedua")) {
      if (!sudahMasuk[namaHb]) {
        sudahMasuk[namaHb] = true;
        const tglMasehi = formatTanggalIndo(dapatkanTanggalISO(offsetHari + d));
        daftarMendatang.push({
          nama: namaHb,
          selisihHari: d,
          tglMasehi: tglMasehi
        });
        if (daftarMendatang.length >= 2) break;
      }
    }
  }

  // 3. Cek apakah hari ini Ayyamul Bidh atau hitung mundur Ayyamul Bidh
  let infoAyyamulBidhPendek = "";
  if (hSkrg.hd >= 13 && hSkrg.hd <= 15 && !(hSkrg.hm === 12 && hSkrg.hd === 13) && hSkrg.hm !== 9) {
    infoAyyamulBidhPendek = `Hari Ini Puasa Sunnah Ayyamul Bidh (${hSkrg.hd} ${hSkrg.nBulan})`;
  } else {
    for (let d = 1; d <= 32; d++) {
      const hCek = hitungHijriyahLokal(offsetHari + d, true);
      if (hCek.hd === 13 && hCek.hm !== 9) {
        infoAyyamulBidhPendek = `Puasa Ayyamul Bidh (13 ${hCek.nBulan}): ${d === 1 ? "Besok" : d + " hari lagi"}`;
        break;
      }
    }
  }

  if (hariBesarHariIni) {
    const bagBerikut = daftarMendatang.length > 0
      ? ` • Berikutnya: ${daftarMendatang[0].nama} (${daftarMendatang[0].selisihHari} hari lagi — ${daftarMendatang[0].tglMasehi})`
      : "";
    return `${tglHijriTeks} • HARI INI: ${hariBesarHariIni}${bagBerikut}`;
  }

  if (daftarMendatang.length > 0) {
    const hb1 = daftarMendatang[0];
    const hb2 = daftarMendatang.length > 1 ? ` • Disusul: ${daftarMendatang[1].nama} (${daftarMendatang[1].selisihHari} hari lagi)` : "";
    const bagAb = infoAyyamulBidhPendek ? ` • ${infoAyyamulBidhPendek}` : "";
    return `${tglHijriTeks} • Menuju ${hb1.nama}: ${hb1.selisihHari === 1 ? "BESOK" : hb1.selisihHari + " hari lagi"} (${hb1.tglMasehi})${hb2}${bagAb}`;
  }

  return `Kalender Islam: ${tglHijriTeks}${infoAyyamulBidhPendek ? " • " + infoAyyamulBidhPendek : ""}`;
}

function dapatkanTargetSholatBerikutnya() {
  pastikanJadwalTersedia();
  const tglIni = dapatkanTanggalISO(0);
  const jdw = cfg.jadwalSebulan[tglIni];
  if (!jdw) return { nama: "Subuh", jam: "04:00", selisihMenit: 60 };
  const now = new Date();
  const tSekarang = now.getHours() * 60 + now.getMinutes();
  const dWaktu = [
    { n: "Subuh", w: waktuSholatTerkoreksi(jdw, "Subuh") },
    { n: "Terbit (Syuruq)", w: jdw.Terbit },
    { n: "Salat Dhuha", w: jdw.Dhuha || tambahMenit(jdw.Terbit, 20) },
    { n: "Dzuhur", w: waktuSholatTerkoreksi(jdw, "Dzuhur") },
    { n: "Ashar", w: waktuSholatTerkoreksi(jdw, "Ashar") },
    { n: "Maghrib", w: waktuSholatTerkoreksi(jdw, "Maghrib") },
    { n: "Isya", w: waktuSholatTerkoreksi(jdw, "Isya") }
  ];
  for (const w of dWaktu) {
    const mTarget = hitungMenitAbsolut(w.w);
    if (mTarget > tSekarang) {
      return { nama: w.n, jam: w.w, selisihMenit: mTarget - tSekarang };
    }
  }
  return {
    nama: "Subuh Besok",
    jam: dWaktu[0].w,
    selisihMenit: (hitungMenitAbsolut(dWaktu[0].w) + 1440) - tSekarang
  };
}

function hitungSisaWaktuTeks() {
  const tglIni = dapatkanTanggalISO(0);
  const tgt = dapatkanTargetSholatBerikutnya();
  return `${formatTanggalIndo(tglIni)} (${hitungPasaranJawa(0)}). Menuju ${tgt.nama} pukul ${tgt.jam} (${Math.floor(tgt.selisihMenit / 60)} Jam ${tgt.selisihMenit % 60} Menit lagi).`;
}

// -------------------------------------------------------------------------
// SISTEM SUARA ASISTEN (TTS) & PEMUTAR 23 AUDIO TERTANAM DI APK (`audio/...`)
// -------------------------------------------------------------------------
let timerFallbackTTS = null;
window._pendingTTSCallback = null;

window.onNativeTTSFinished = function() {
  if (timerFallbackTTS) {
    clearTimeout(timerFallbackTTS);
    timerFallbackTTS = null;
  }
  const cb = window._pendingTTSCallback;
  window._pendingTTSCallback = null;
  if (cb) cb();
};

function batalkanSemuaAntreanSuara() {
  if (timerFallbackTTS) {
    clearTimeout(timerFallbackTTS);
    timerFallbackTTS = null;
  }
  window._pendingTTSCallback = null;
  window._pendingBellCallback = null;
  window._pendingAudioCallback = null;
  if (window.AndroidBridge && window.AndroidBridge.stopTTS) {
    try { window.AndroidBridge.stopTTS(); } catch (e) {}
  } else if ("speechSynthesis" in window) {
    try { window.speechSynthesis.cancel(); } catch (e) {}
  }
}

window.bicaraGoogleTTS = bicaraGoogleTTS;
function bicaraGoogleTTS(teks, senyapVisual = false, callbackSelesai = null) {
  const teksUcap = String(teks || "");
  if (!senyapVisual) tampilkanToastVisual(teksUcap);

  if (timerFallbackTTS) {
    clearTimeout(timerFallbackTTS);
    timerFallbackTTS = null;
  }
  window._pendingTTSCallback = callbackSelesai || null;

  if (window.AndroidBridge && window.AndroidBridge.speak) {
    try {
      window.AndroidBridge.speak(teksUcap, Number(cfg.ttsSpeed) || 1.0, Number(cfg.ttsPitch) || 1.0);
      if (callbackSelesai) {
        // Pengaman cadangan hanya jika sinyal onNativeTTSFinished belum terpanggil setelah kalimat panjang selesai
        const batasAmanMs = Math.max(6000, teksUcap.length * 115 + 2500);
        timerFallbackTTS = setTimeout(() => {
          window.onNativeTTSFinished();
        }, batasAmanMs);
      }
      return;
    } catch (e) {}
  } else if ("speechSynthesis" in window) {
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(teksUcap);
      u.lang = "id-ID";
      u.rate = Number(cfg.ttsSpeed) || 1.0;
      u.pitch = Number(cfg.ttsPitch) || 1.0;
      u.onend = function() { window.onNativeTTSFinished(); };
      window.speechSynthesis.speak(u);
      return;
    } catch (e) {}
  }
  if (callbackSelesai) {
    const estMs = Math.max(3000, teksUcap.length * 90);
    timerFallbackTTS = setTimeout(() => {
      window.onNativeTTSFinished();
    }, estMs);
  }
}

// Pemetaan Eksak ke 23 Berkas Audio Asli yang Tertanam di Folder `audio/` dalam APK
function petakanKePathAudioAsli(kataKunciAtauFile) {
  const raw = String(kataKunciAtauFile || "").trim();
  const k = raw.toLowerCase().replace(/[\s\-_]/g, "");

  // 1. Jika sudah berupa path resmi `audio/...`, langsung kembalikan secara eksak tanpa diubah agar TIDAK PERNAH TERTUKAR!
  if (raw.startsWith("audio/")) {
    const baseRaw = raw.replace(/^audio\/murottal\//i, "").replace(/^audio\//i, "").toLowerCase();
    for (const [fname, blobUrl] of Object.entries(customAudioBlobs)) {
      if (fname.toLowerCase() === baseRaw || fname.toLowerCase() === raw.toLowerCase()) {
        return blobUrl;
      }
    }
    return raw;
  }

  // 2. Cek pencocokan eksak nama file di IndexedDB
  for (const [fname, blobUrl] of Object.entries(customAudioBlobs)) {
    const nClean = fname.toLowerCase().replace(/[\s\-_]/g, "");
    if (fname.toLowerCase() === raw.toLowerCase() || (k && nClean === k)) {
      return blobUrl;
    }
  }

  // 3. Pemetaan ke 23 berkas audio asli dari nidaul masjid pro.ppk
  const peta23Audio = {
    "adzansubuh": "audio/adzan_subuh.ogg",
    "azansbhsyahdu": "audio/Azan Sbh Syahdu.ogg",
    "adzan": "audio/adzan.ogg",
    "adzanmakkah": "audio/murottal/adzan_makkah_standar.mp3",
    "ajanmasjidkampung": "audio/Ajan Masjid Kampung.ogg",
    "tarhim": "audio/tarhim.ogg",
    "tarhimdzuhur": "audio/tarhim.ogg",
    "tarhimmahmudalhussary": "audio/Tarhim Mahmud Al Hussary.ogg",
    "arham": "audio/Arhamarrohimin Tarhim.ogg",
    "asmaul": "audio/asmaul_husna.mp3",
    "doa": "audio/doa_adzan.mp3",
    "doaadzan": "audio/doa_adzan.mp3",
    "bel": "audio/bel_pendek.mp3",
    "belpendek": "audio/bel_pendek.mp3",
    "bumper": "audio/bumper.mp3",
    "iqomah": "audio/iqomah.mp3",
    "peringatanterbit": "audio/peringatan terbit.mp3",
    "timerterbit": "audio/timer_terbit.mp3",
    "sirineterbit": "audio/sirine_terbit.mp3",
    "yamuhaimin": "audio/ya_muhaimin_ya_salam.mp3",
    "yamuhaiminyasalam": "audio/ya_muhaimin_ya_salam.mp3",
    "terbit": "audio/terbit.mp3",
    "dhuha": "audio/dhuha.ogg",
    "tahajud": "audio/tahajud.mp3",
    "subuh": "audio/murottal/subuh-01.ogg",
    "dzuhur": "audio/murottal/dzuhur-01.ogg",
    "ashar": "audio/murottal/ashar-01.ogg",
    "maghrib": "audio/murottal/maghrib-01.ogg",
    "isya": "audio/murottal/isya-01.ogg",
    "aljumuah": "audio/aljumuah.ogg",
    "yasin": "audio/yasin.ogg",
    "murottal": "audio/murottal/dzuhur-01.ogg"
  };

  if (peta23Audio[k]) return peta23Audio[k];

  // Pilihan acak untuk murottal umum
  if (k === "" || k === "acak") {
    const daftarMurottal = [
      "audio/murottal/subuh-01.ogg",
      "audio/murottal/dzuhur-01.ogg",
      "audio/murottal/ashar-01.ogg",
      "audio/murottal/maghrib-01.ogg",
      "audio/murottal/isya-01.ogg",
      "audio/aljumuah.ogg",
      "audio/yasin.ogg"
    ];
    return daftarMurottal[Math.floor(Math.random() * daftarMurottal.length)];
  }
  return "audio/" + raw;
}

function renderBannerPlayer() {
  const el = document.getElementById("player-container");
  if (window.AndroidBridge && window.AndroidBridge.updateNotification) {
    try {
      if (currentAudioTitle) {
        window.AndroidBridge.updateNotification(
          "Mengudara: " + currentAudioTitle,
          "Ketuk HENTIKAN SUARA SEKARANG di bawah atau goyangkan HP 2x untuk mematikan suara dari luar APK."
        );
        if (tahapSiaranAktif && cfg.popupHentikanLuar !== false && window.AndroidBridge.showStopPopup) {
          window.AndroidBridge.showStopPopup(currentAudioTitle, false);
        }
      } else {
        window.AndroidBridge.updateNotification(
          "Nurul Masjid Pro • Jam Masjid Aktif",
          "Siaga menjaga jadwal salat, murottal, tarhim & adzan 24 jam di latar belakang."
        );
        if (window.AndroidBridge.closeStopPopup) {
          window.AndroidBridge.closeStopPopup();
        }
      }
    } catch (e) {}
  }
  if (!el) return;
  if (!currentAudioTitle) {
    el.innerHTML = "";
    return;
  }
  el.innerHTML = `
    <div class="player-banner">
      <div style="font-weight:800;font-size:1.05rem;margin-bottom:8px;">SEDANG MENGUDARA: ${currentAudioTitle}</div>
      <button type="button" class="btn btn-red" id="btn-stop-banner">HENTIKAN SIARAN AUDIO SEKARANG</button>
    </div>
  `;
  const bStop = document.getElementById("btn-stop-banner");
  if (bStop) bStop.onclick = () => {
    tahapDihentikanManual = tahapSiaranAktif;
    hentikanAudioDanSimpan();
    bicaraGoogleTTS("Siaran audio dihentikan.");
  };
}

function hentikanAudioDanSimpan() {
  batalkanSemuaAntreanSuara();
  // Simpan posisi terakhir jika yang sedang berputar adalah Murottal untuk mendukung Mode Sambung
  if (cfg.modeMurottal === "sambung" && currentAudioTitle && currentAudioTitle.toLowerCase().includes("murottal")) {
    try {
      if (window.AndroidBridge && window.AndroidBridge.getAudioPosition) {
        const posMs = window.AndroidBridge.getAudioPosition();
        if (posMs > 2000) {
          cfg.lastMurottalPos = Math.floor(posMs / 1000);
          simpanData();
        }
      } else if (currentAudioObj && currentAudioObj.currentTime > 2) {
        cfg.lastMurottalPos = Math.floor(currentAudioObj.currentTime);
        simpanData();
      }
    } catch (e) {}
  }
  if (currentAudioObj) {
    try {
      currentAudioObj.pause();
      currentAudioObj.currentTime = 0;
    } catch (e) {}
    currentAudioObj = null;
  }
  if (window.AndroidBridge && window.AndroidBridge.stopAudio) {
    try { window.AndroidBridge.stopAudio(); } catch (e) {}
  }
  currentAudioTitle = "";
  renderBannerPlayer();
}

// Callback dari Native MediaPlayer saat pemutaran selesai
window.onStoppedFromOutsideApk = function() {
  if (tahapSiaranAktif) {
    tahapDihentikanManual = tahapSiaranAktif;
  }
  hentikanAudioDanSimpan();
};

window.onNativeAudioFinished = function() {
  const cb = window._pendingAudioCallback;
  window._pendingAudioCallback = null;
  currentAudioTitle = "";
  renderBannerPlayer();
  if (cb) cb();
};

function siapkanGantiAudioBaru() {
  batalkanSemuaAntreanSuara();
  if (cfg.modeMurottal === "sambung" && currentAudioTitle && currentAudioTitle.toLowerCase().includes("murottal")) {
    try {
      if (window.AndroidBridge && window.AndroidBridge.getAudioPosition) {
        const posMs = window.AndroidBridge.getAudioPosition();
        if (posMs > 2000) {
          cfg.lastMurottalPos = Math.floor(posMs / 1000);
          simpanData();
        }
      } else if (currentAudioObj && currentAudioObj.currentTime > 2) {
        cfg.lastMurottalPos = Math.floor(currentAudioObj.currentTime);
        simpanData();
      }
    } catch (e) {}
  }
  if (currentAudioObj) {
    try {
      currentAudioObj.pause();
      currentAudioObj.currentTime = 0;
    } catch (e) {}
    currentAudioObj = null;
  }
}

function putarAudio(jenis, paramWaktu, callbackSelesai = null) {
  siapkanGantiAudioBaru();
  const volP = (jenis === "adzan") ? (cfg.volAdzan || 100) : (cfg.volMurottal || 60);
  let targetKey = paramWaktu || "acak";
  let judul = paramWaktu || "Murottal Al-Qur'an";

  if (jenis === "adzan") {
    judul = "Kumandang Adzan " + paramWaktu;
    const mapFile = {
      Subuh: cfg.adzanSubuhFile || "audio/adzan_subuh.ogg",
      Dzuhur: cfg.adzanDzuhurFile || "audio/adzan.ogg",
      Ashar: cfg.adzanAsharFile || "audio/murottal/adzan_makkah_standar.mp3",
      Maghrib: cfg.adzanMaghribFile || "audio/adzan.ogg",
      Isya: cfg.adzanIsyaFile || "audio/Ajan Masjid Kampung.ogg"
    };
    targetKey = mapFile[paramWaktu] || "audio/adzan.ogg";
  } else if (jenis === "tarhim") {
    const mapTarhim = {
      Subuh: cfg.tarhimSubuhFile || "audio/tarhim.ogg",
      Dzuhur: cfg.tarhimDzuhurFile || "audio/tarhim.ogg",
      Ashar: cfg.tarhimAsharFile || "audio/tarhim.ogg",
      Maghrib: cfg.tarhimMaghribFile || "audio/tarhim.ogg",
      Isya: cfg.tarhimIsyaFile || "audio/tarhim.ogg"
    };
    targetKey = mapTarhim[paramWaktu] || "audio/tarhim.ogg";
    // Menghormati 100% pilihan rekaman Tarhim pengguna untuk setiap waktu sholat
    judul = `Lantunan Tarhim ${paramWaktu} (${dapatkanLabelTarhim(targetKey)})`;
  } else if (jenis === "sistem") {
    const pLow = String(paramWaktu || "").toLowerCase();
    if (pLow.includes("asmaul")) judul = "Lantunan Asmaul Husna — Hijjaz";
    else if (pLow.includes("doa_adzan") || pLow.includes("doaadzan")) judul = "Doa Setelah Adzan — Syekh Saad Al-Ghamidi";
    else if (pLow.includes("arhamarrohimin")) judul = "Lantunan Ya Arhamarrohimin Pra-Subuh";
    else if (pLow.includes("iqomah")) judul = "Kumandang Panggilan Iqomah";
    else if (pLow.includes("tahajud")) judul = "Lantunan Pengingat Tahajud";
    else if (pLow.includes("dhuha")) judul = "Lantunan Pengingat Salat Dhuha";
    else if (pLow.includes("terbit")) judul = "Penanda Waktu Syuruq / Terbit";
    else if (pLow.includes("tarhim")) judul = `Uji Dengar ${dapatkanLabelTarhim(paramWaktu)}`;
  }

  const pathAudio = petakanKePathAudioAsli(targetKey);
  const isYasinAtauJumuah = String(paramWaktu || "").includes("yasin") || String(paramWaktu || "").includes("aljumuah");
  if (jenis === "murottal") {
    judul = isYasinAtauJumuah
      ? (String(paramWaktu).includes("yasin") ? "Surah Yasin Malam Jumat" : "Surah Al-Jumu'ah Hari Jumat")
      : "Murottal Al-Qur'an (" + (paramWaktu || "Pilihan") + ")";
    if (!isYasinAtauJumuah && cfg.modeMurottal === "sambung" && cfg.lastMurottalPath) {
      targetKey = cfg.lastMurottalPath;
    }
  }
  const pathFinal = (jenis === "murottal" && !isYasinAtauJumuah && cfg.modeMurottal === "sambung" && cfg.lastMurottalPath)
    ? cfg.lastMurottalPath
    : pathAudio;
  if (jenis === "murottal" && !isYasinAtauJumuah) {
    cfg.lastMurottalPath = pathFinal;
  }
  // Getar awal sebelum kumandang adzan jika sakelar getarAwal aktif
  if (jenis === "adzan" && cfg.getarAwal && navigator.vibrate) {
    try { navigator.vibrate([300, 150, 300]); } catch (e) {}
  }

  const onAudioDone = function() {
    currentAudioTitle = "";
    renderBannerPlayer();
    if (jenis === "murottal") {
      cfg.lastMurottalPos = 0;
      simpanData();
    }
    if (jenis === "adzan") {
      const lanjutanSetelahDoa = () => {
        let pesanTambahan = "";
        if (cfg.s_rawatib) {
          if (paramWaktu === "Subuh" || paramWaktu === "Ashar") {
            pesanTambahan += "Mari bersiap merapatkan barisan untuk mendirikan salat berjamaah. ";
          } else {
            pesanTambahan += "Dirikanlah salat sunnah rawatib sebelum iqomah dikumandangkan. ";
          }
        }
        if (cfg.s_musafir && (paramWaktu === "Dzuhur" || paramWaktu === "Ashar" || paramWaktu === "Maghrib" || paramWaktu === "Isya")) {
          pesanTambahan += "Bagi Anda yang sedang dalam perjalanan jauh atau musafir, tersedia keringanan rukhsoh salat jamak dan qashar. ";
        }
        if (pesanTambahan) bicaraGoogleTTS(pesanTambahan, true);
        if (callbackSelesai) callbackSelesai();
      };

      if (cfg.s_doa_adzan) {
        const fileDoa = (cfg.doaAdzanFile && String(cfg.doaAdzanFile).trim() !== "") ? cfg.doaAdzanFile : "audio/doa_adzan.mp3";
        putarAudio("sistem", fileDoa, lanjutanSetelahDoa);
        return;
      } else {
        lanjutanSetelahDoa();
        return;
      }
      let pesanBakda = "";
      if (cfg.s_doa_adzan) {
        pesanBakda += "Panggilan adzan telah usai. Mari berdoa setelah adzan: Allahumma robba hadzihid da'watit tammah, wash sholatil qoimah, ati Sayyidana Muhammadanil wasilata wal fadhilah. ";
      }
      if (cfg.s_rawatib) {
        if (paramWaktu === "Subuh" || paramWaktu === "Ashar") {
          pesanBakda += "Mari bersiap merapatkan barisan untuk mendirikan salat berjamaah. ";
        } else {
          pesanBakda += "Dirikanlah salat sunnah rawatib sebelum iqomah dikumandangkan. ";
        }
      }
      if (cfg.s_musafir && (paramWaktu === "Dzuhur" || paramWaktu === "Ashar" || paramWaktu === "Maghrib" || paramWaktu === "Isya")) {
        pesanBakda += "Bagi Anda yang sedang dalam perjalanan jauh atau musafir, tersedia keringanan rukhsoh salat jamak dan qashar. ";
      }
      if (pesanBakda) bicaraGoogleTTS(pesanBakda, true);
    }
    if (callbackSelesai) callbackSelesai();
  };

  // 1. Utama: Gunakan pemutar Native Android (`MediaPlayer` + `AssetFileDescriptor`) jika di dalam APK
  if (window.AndroidBridge && window.AndroidBridge.playAudio) {
    try {
      window._pendingAudioCallback = onAudioDone;
      const okNative = window.AndroidBridge.playAudio(pathFinal, volP);
      if (okNative) {
        currentAudioTitle = judul;
        renderBannerPlayer();
        if (jenis === "murottal" && cfg.modeMurottal === "sambung" && cfg.lastMurottalPos > 2 && window.AndroidBridge.seekAudioTo) {
          setTimeout(() => {
            try { window.AndroidBridge.seekAudioTo(cfg.lastMurottalPos * 1000); } catch (e) {}
          }, 400);
        }
        return;
      }
    } catch (e) {}
  }

  // 2. Fallback Multi-Jalur: Cek otomatis di `audio/`, `./audio/`, `app/src/main/assets/audio/`, dan `file:///android_asset/audio/`
  const cleanRel = pathAudio.replace(/^\.?\/+/g, "").replace(/^app\/src\/main\/assets\//g, "");
  const kandidatJalur = [
    encodeURI(cleanRel),
    encodeURI("./" + cleanRel),
    encodeURI("app/src/main/assets/" + cleanRel),
    "file:///android_asset/" + encodeURI(cleanRel)
  ];
  let idxJalur = 0;

  function cobaPutarJalurBerikutnya() {
    if (idxJalur >= kandidatJalur.length) {
      currentAudioTitle = "";
      renderBannerPlayer();
      if (String(pathFinal || "").includes("doa_adzan")) {
        bicaraGoogleTTS("Allahumma robba hadzihid da'watit tammah, wash sholatil qoimah, ati Sayyidana Muhammadanil wasilata wal fadhilah, wab'atshu maqomam mahmudanil ladzi wa'adtah.", true, callbackSelesai);
        return;
      }
      if (callbackSelesai) callbackSelesai();
      return;
    }
    const urlCoba = kandidatJalur[idxJalur++];
    const audio = new Audio(urlCoba);
    audio.volume = Math.max(0.1, Math.min(1.0, volP / 100.0));
    currentAudioObj = audio;
    audio.onended = onAudioDone;
    audio.onerror = function() {
      cobaPutarJalurBerikutnya();
    };
    currentAudioTitle = judul;
    renderBannerPlayer();
    const p = audio.play();
    if (p && typeof p.catch === "function") {
      p.catch(() => {
        cobaPutarJalurBerikutnya();
      });
    }
  }
  cobaPutarJalurBerikutnya();
}

window.onNativeBellFinished = function() {
  const cb = window._pendingBellCallback;
  window._pendingBellCallback = null;
  if (cb) cb();
};

// Pemutar Bel Masjid Mandiri: TIDAK PERNAH menghentikan Tarhim atau Murottal yang sedang berkumandang!
function bunyikanBelMasjid(callbackSetelahBel) {
  if (!cfg.s_bel) {
    if (callbackSetelahBel) callbackSetelahBel();
    return;
  }
  if (window.AndroidBridge && window.AndroidBridge.playBell) {
    try {
      window._pendingBellCallback = callbackSetelahBel || null;
      const ok = window.AndroidBridge.playBell(cfg.volAdzan || 100);
      if (ok) return;
    } catch (e) {}
  }
  // Fallback HTML5 Audio mandiri (tidak menyentuh currentAudioObj utama!)
  try {
    const bellAudio = new Audio("audio/bel_pendek.mp3");
    bellAudio.volume = 1.0;
    bellAudio.onended = () => { if (callbackSetelahBel) callbackSetelahBel(); };
    bellAudio.onerror = () => { if (callbackSetelahBel) callbackSetelahBel(); };
    bellAudio.play().catch(() => { if (callbackSetelahBel) callbackSetelahBel(); });
  } catch (e) {
    if (callbackSetelahBel) callbackSetelahBel();
  }
}

// -------------------------------------------------------------------------
// RANGKUMAN PAGI & MESIN DETAK JAM DIGITAL MASJID
// -------------------------------------------------------------------------
function buatRangkumanPagiTeks() {
  const tglIni = dapatkanTanggalISO(0);
  const jdw = cfg.jadwalSebulan[tglIni];
  let infoTerbit = "";
  if (jdw && jdw.Terbit) {
    infoTerbit = ` Waktu matahari terbit pukul ${jdw.Terbit}, dan waktu salat Dhuha dimulai pukul ${jdw.Dhuha || tambahMenit(jdw.Terbit, 20)}.`;
  }
  const d = new Date().getDay();
  let amalan = "Mari awali pagi dengan zikir pagi dan sedekah subuh.";
  if (d === 5) amalan = "Hari ini adalah Jumat berkah. Mari perbanyak shalawat dan membaca Surah Al-Kahfi.";
  else if (d === 1 || d === 4) amalan = `Hari ini adalah hari sunnah berpuasa ${d === 1 ? "Senin." : "Kamis."}`;
  hitungHijriyahLokal(0);
  return `Assalamu'alaikum warahmatullahi wabarakatuh. Rangkuman pagi Nurul Masjid Pro. Hari ini ${formatTanggalIndo(tglIni)}, pasaran ${hitungPasaranJawa(0)}. Bertepatan dengan ${tanggalHijriyahCache}.${infoTerbit} ${cacheCuacaSuara} ${amalan}`;
}

function apakahTahapSudahTerkunci(kunciGembok) {
  if (gembokAbsolut[kunciGembok]) return true;
  if (window.AndroidBridge && typeof window.AndroidBridge.isStageLocked === "function") {
    try {
      if (window.AndroidBridge.isStageLocked(kunciGembok)) {
        gembokAbsolut[kunciGembok] = true;
        return true;
      }
    } catch (e) {}
  }
  return false;
}

function kunciTahapSekarang(kunciGembok) {
  gembokAbsolut[kunciGembok] = true;
  if (window.AndroidBridge && typeof window.AndroidBridge.markStageLock === "function") {
    try { window.AndroidBridge.markStageLock(kunciGembok); } catch (e) {}
  }
  simpanGembok();
}

function apakahWaktuJadwalTiba(menitSekarang, jamTargetStr, kunciGembok) {
  if (!jamTargetStr || apakahTahapSudahTerkunci(kunciGembok)) return false;
  const targetM = hitungMenitAbsolut(jamTargetStr);
  if (targetM < 0) return false;
  if (menitSekarang >= targetM && menitSekarang <= targetM + 1) {
    kunciTahapSekarang(kunciGembok);
    return true;
  }
  return false;
}

let jadwalIqomahAktif = null; // { waktu, menitCd2, menitCd1, menitIqomah, sudahCd2, sudahCd1, sudahIqomah }
let menitSelesaiKhusyuk = -1;

const KALIMAT_HIKMAH_HARIAN = [
  "Sesungguhnya salat yang paling berat bagi orang munafik adalah salat Isya dan salat Subuh berjamaah.",
  "Barang siapa menjaga salat lima waktu tepat pada waktunya, maka salat itu akan menjadi cahaya dan keselamatan baginya pada hari kiamat.",
  "Perbanyaklah shalawat dan istighfar di setiap pergantian waktu agar hati senantiasa tenang dan diberkahi Allah Subhanahu wa Ta'ala."
];

function dapatkanKalimatHikmah() {
  if (!cfg.ttsVarian) return "";
  const idx = new Date().getHours() % KALIMAT_HIKMAH_HARIAN.length;
  return " " + KALIMAT_HIKMAH_HARIAN[idx];
}

// Fungsi pemutar Asmaul Husna yang aman: TIDAK PERNAH salah memutar Arhamarrohimin Tarhim.ogg!
function putarAsmaulHusnaAman() {
  const fAsmaul = String(cfg.asmaulFile || "audio/asmaul_husna.mp3").trim();
  const target = (fAsmaul && fAsmaul !== "audio/Arhamarrohimin Tarhim.ogg") ? fAsmaul : "audio/asmaul_husna.mp3";
  putarAudio("sistem", target);
}

function simpanJadwalIqomah() {
  try {
    if (jadwalIqomahAktif) {
      localStorage.setItem("nidaul_iqomah_aktif_v68", JSON.stringify(jadwalIqomahAktif));
    } else {
      localStorage.removeItem("nidaul_iqomah_aktif_v68");
    }
  } catch (e) {}
}

function picuSuaraIqomahSekarang(namaWaktu) {
  const tglSkrg = dapatkanTanggalISO(0);
  if (namaWaktu) {
    gembokAbsolut["IQ_MAIN_" + namaWaktu + tglSkrg] = true;
    simpanGembok();
  }
  if (jadwalIqomahAktif) {
    jadwalIqomahAktif.sudahIqomah = true;
    simpanJadwalIqomah();
  }
  // Putar langsung iqomah.mp3 di pemutar utama & dentangkan bel di bellPlayer secara serentak (100% anti-gagal, tidak menggantung di callback bel!)
  putarAudio("sistem", "audio/iqomah.mp3", () => {
    bicaraGoogleTTS(`Panggilan iqomah ${namaWaktu || ""} telah selesai dikumandangkan. Mari berdiri, luruskan dan rapatkan barisan salat berjamaah.`, true);
    if (cfg.s_khusyuk) {
      const now = new Date();
      const mSkrg = now.getHours() * 60 + now.getMinutes();
      const durK = Number(cfg.durasiKhusyuk) || 30;
      menitSelesaiKhusyuk = (mSkrg + durK) % 1440;
      if (window.AndroidBridge && window.AndroidBridge.setSilentMode) {
        window.AndroidBridge.setSilentMode(true);
      }
    }
  });
  bunyikanBelMasjid();
}

function jalankanRangkaianAdzanLengkap(w) {
  const jedaIqomah = Math.max(6, Number(cfg.waktuIqomah) || 10);
  const nowStart = new Date();
  const mMulaiAdzan = nowStart.getHours() * 60 + nowStart.getMinutes();
  const tglIni = dapatkanTanggalISO(0);

  // SATU JADWAL IQOMAH TUNGGAL YANG TERKUNCI (Tidak diubah-ubah lagi agar tidak pernah berbunyi ganda!)
  jadwalIqomahAktif = {
    tgl: tglIni,
    waktu: w,
    menitCd2: (mMulaiAdzan + jedaIqomah - 2) % 1440,
    menitCd1: (mMulaiAdzan + jedaIqomah - 1) % 1440,
    menitIqomah: (mMulaiAdzan + jedaIqomah) % 1440,
    sudahCd2: false,
    sudahCd1: false,
    sudahIqomah: false
  };
  simpanJadwalIqomah();

  putarAudio("adzan", w);
}

function apakahDalamRentangMenit(menitSkrg, jamMulaiStr, jamAkhirStr, kunciGembok) {
  if (!jamMulaiStr || !jamAkhirStr || gembokAbsolut[kunciGembok]) return false;
  const mMulai = hitungMenitAbsolut(jamMulaiStr);
  const mAkhir = hitungMenitAbsolut(jamAkhirStr);
  if (mMulai < 0 || mAkhir < 0) return false;
  if (menitSkrg >= mMulai && menitSkrg < mAkhir) {
    gembokAbsolut[kunciGembok] = true;
    if (window.AndroidBridge && window.AndroidBridge.markStageLock) {
      try { window.AndroidBridge.markStageLock(kunciGembok); } catch (e) {}
    }
    simpanGembok();
    return true;
  }
  return false;
}

let tahapSiaranAktif = "";
let tahapDihentikanManual = "";

// PEMBUNUH AUDIO OTOMATIS: Begitu masuk jadwal tahap berikutnya, batalkan antrean TTS/Bel lama dan ganti ke tahap baru secara atomik lewat playAudio()!
function pembunuhAudioOtomatis(namaTahapBaru) {
  batalkanSemuaAntreanSuara();
  if (cfg.modeMurottal === "sambung" && currentAudioTitle && currentAudioTitle.toLowerCase().includes("murottal")) {
    try {
      if (window.AndroidBridge && window.AndroidBridge.getAudioPosition) {
        const posMs = window.AndroidBridge.getAudioPosition();
        if (posMs > 2000) {
          cfg.lastMurottalPos = Math.floor(posMs / 1000);
          simpanData();
        }
      }
    } catch (e) {}
  }
  if (currentAudioObj) {
    try {
      currentAudioObj.pause();
      currentAudioObj.currentTime = 0;
    } catch (e) {}
    currentAudioObj = null;
  }
  tahapSiaranAktif = namaTahapBaru;
}

function apakahSedangDalamZonaSterilSalat(menitSkrg, jdw) {
  if (currentAudioTitle && currentAudioTitle.trim() !== "") return true;
  if (window._pendingTTSCallback || window._pendingBellCallback || window._pendingAudioCallback) return true;
  if (jadwalIqomahAktif && !jadwalIqomahAktif.sudahIqomah) return true;
  const daftarWajib = ["Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya"];
  for (const w of daftarWajib) {
    const jamAdzan = waktuSholatTerkoreksi(jdw, w);
    if (!jamAdzan) continue;
    const wLower = w.toLowerCase();
    const tarhimOn = Boolean(cfg["tarhim_" + wLower + "_on"]);
    const durTarhim = tarhimOn ? (Number(cfg.waktuTarhim) || 6) : 0;
    const durAsmaul = (w !== "Subuh" && cfg.s_asmaul) ? (Number(cfg.waktuAsmaul) || 4) : 0;
    const durMurottal = Number(cfg.waktuMurottal) || 30;
    const durArham = (w === "Subuh" && cfg.s_arham) ? (Number(cfg.waktuArham) || 10) : 0;
    const totalSebelum = durTarhim + durAsmaul + durMurottal + durArham;
    const totalSesudah = 4 + Math.max(6, Number(cfg.waktuIqomah) || 10);
    const mAdzan = hitungMenitAbsolut(jamAdzan);
    if (mAdzan >= 0 && menitSkrg >= (mAdzan - totalSebelum) && menitSkrg <= (mAdzan + totalSesudah)) {
      return true;
    }
  }
  return false;
}

let menitVisualTerakhir = "";

function jalankanEstafetPeringatanTerbit() {
  pembunuhAudioOtomatis("PRETERBIT");
  putarAudio("sistem", "audio/timer_terbit.mp3", () => {
    putarAudio("sistem", "audio/peringatan terbit.mp3", () => {
      putarAudio("murottal", "audio/ya_muhaimin_ya_salam.mp3");
    });
  });
}

function jalankanEstafetWaktuTerbit() {
  pembunuhAudioOtomatis("TERBIT");
  putarAudio("sistem", "audio/sirine_terbit.mp3", () => {
    putarAudio("sistem", "audio/terbit.mp3", () => {
      bicaraGoogleTTS("Matahari telah terbit sempurna, waktu Syuruq telah tiba.", true);
    });
  });
}
window.jalankanEstafetPeringatanTerbit = jalankanEstafetPeringatanTerbit;
window.jalankanEstafetWaktuTerbit = jalankanEstafetWaktuTerbit;

function detakMesinMasjid() {
  window.DetakJantung = Math.floor(Date.now() / 1000);
  const elClock = document.getElementById("live-clock-digits");
  const now = new Date();
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const hmSkrg = `${hh} : ${mm}`;
  if (elClock && menitVisualTerakhir !== hmSkrg) {
    menitVisualTerakhir = hmSkrg;
    elClock.textContent = `${hh} : ${mm} WIB`;
  }

  // Jika sakelar master_aktif MATI atau lokasi belum dipilih oleh pengguna, jangan bunyikan jadwal apa pun!
  if (!cfg.master_aktif || !apakahLokasiSudahDiatur()) return;
  const tglIni = dapatkanTanggalISO(0);

  // Pembersihan Gembok Harian Otomatis saat berganti tanggal (persis main.lua baris 908-919)
  if (window.TanggalSistem !== tglIni) {
    const gembokBersih = {};
    for (const [kunci, nilai] of Object.entries(gembokAbsolut)) {
      if (typeof kunci === "string" && kunci.includes(tglIni)) {
        gembokBersih[kunci] = nilai;
      }
    }
    gembokAbsolut = gembokBersih;
    window.TanggalSistem = tglIni;
    simpanGembok();
    ambilTanggalHijriyah(0);
  }

  pastikanJadwalTersedia();
  const menitSkrg = now.getHours() * 60 + now.getMinutes();
  const menitSkrgNum = now.getMinutes();
  const detikSkrg = now.getSeconds();

  // Sinkronisasi Siluman Cuaca & Gempa setiap menit 00 dan 30 (persis main.lua baris 930-934)
  const kunciSinkronSiluman = "SINKRON_SILUMAN_" + tglIni + "_" + hh + "_" + menitSkrgNum;
  if ((menitSkrgNum === 0 || menitSkrgNum === 30) && !gembokAbsolut[kunciSinkronSiluman]) {
    gembokAbsolut[kunciSinkronSiluman] = true;
    simpanGembok();
    tarikCuacaDanGempa();
  }

  const jdw = cfg.jadwalSebulan && cfg.jadwalSebulan[tglIni];
  if (!jdw) return;

  // 0. Periksa pemulihan Mode Hening / Khusyuk setelah salat selesai
  if (menitSelesaiKhusyuk >= 0 && menitSkrg >= menitSelesaiKhusyuk) {
    menitSelesaiKhusyuk = -1;
    if (window.AndroidBridge && window.AndroidBridge.setSilentMode) {
      window.AndroidBridge.setSilentMode(false);
    }
  }

  // Peringatan Kehati-hatian Akhir Waktu Sholat (15 Menit Sebelum Habis Waktu Dzuhur, Ashar, Maghrib, Isya — persis main.lua baris 1044-1047!)
  if (cfg.s_kehatihatian) {
    const pAkhir = [
      { c: "Dzuhur", n: waktuSholatTerkoreksi(jdw, "Ashar") },
      { c: "Ashar", n: waktuSholatTerkoreksi(jdw, "Maghrib") },
      { c: "Maghrib", n: waktuSholatTerkoreksi(jdw, "Isya") },
      { c: "Isya", n: waktuSholatTerkoreksi(jdw, "Subuh") }
    ];
    for (const wp of pAkhir) {
      if (wp.n && apakahWaktuJadwalTiba(menitSkrg, tambahMenit(wp.n, -15), "HATI_" + wp.c + "_" + tglIni)) {
        bicaraGoogleTTS(`Peringatan kehati-hatian. Waktu sholat ${wp.c} tersisa lima belas menit lagi.`, true);
      }
    }
  }

  // Pengingat Puasa Lengkap (10 Menit Setelah Maghrib Nyata — persis main.lua baris 1019-1042!)
  if (cfg.s_puasa && jdw.Maghrib) {
    const jamPengingatPuasa = tambahMenit(waktuSholatTerkoreksi(jdw, "Maghrib"), 10);
    if (apakahWaktuJadwalTiba(menitSkrg, jamPengingatPuasa, "PUASA_" + tglIni)) {
      const bs = (now.getDay() + 1) % 7;
      ambilTanggalHijriyah(1, function(teksH, tgl, bln) {
        if (!tgl || !bln) {
          if (bs === 1 || bs === 4) {
            bicaraGoogleTTS("Besok adalah hari " + (bs === 1 ? "Senin" : "Kamis") + ". Jangan lupa berniat puasa sunnah.", true);
          }
          return;
        }
        let pPesan = "";
        if (bln === "Muharram" && tgl === 9) pPesan = "Besok adalah tanggal 9 Muharram. Jangan lupa berniat puasa sunnah Tasu'a.";
        else if (bln === "Muharram" && tgl === 10) pPesan = "Besok adalah tanggal 10 Muharram. Jangan lupa berniat puasa sunnah Asyura.";
        else if (bln === "Zulhijah" && tgl === 8) pPesan = "Besok adalah tanggal 8 Zulhijah. Jangan lupa berniat puasa sunnah Tarwiyah.";
        else if (bln === "Zulhijah" && tgl === 9) pPesan = "Besok adalah tanggal 9 Zulhijah. Jangan lupa berniat puasa sunnah Arafah.";
        else if (bln === "Syakban" && tgl === 15) pPesan = "Besok adalah Nisfu Syakban. Anda dianjurkan berpuasa sunnah dan memperbanyak ibadah.";
        else if (bln === "Ramadhan" && tgl === 1) pPesan = "Alhamdulillah, besok adalah hari pertama bulan suci Ramadhan. Jangan lupa berniat puasa wajib.";
        else if (bln === "Syawal" && tgl >= 2 && tgl <= 7) pPesan = "Besok adalah tanggal " + tgl + " Syawal. Mari rutinkan puasa sunnah enam hari Syawal.";
        else if ((tgl === 13 || tgl === 14 || tgl === 15) && bln !== "Ramadhan" && !(bln === "Zulhijah" && tgl === 13)) {
          pPesan = "Besok masuk puasa sunnah Ayyamul Bidh tanggal " + tgl + " " + bln + ".";
        } else if (bs === 1 || bs === 4) {
          pPesan = "Besok adalah hari " + (bs === 1 ? "Senin" : "Kamis") + ". Jangan lupa berniat puasa sunnah.";
        }
        if (pPesan) { putarAudio("sistem", "audio/bumper.mp3", () => { bicaraGoogleTTS(pPesan, true); }); }
      });
    }
  }

  // =========================================================================
  // PRIORITAS UTAMA #1: RANGKAIAN JADWAL SALAT 5 WAKTU DENGAN PEMBUNUH AUDIO OTOMATIS
  // Setiap tahap lebih tinggi otomatis membunuh audio tahap sebelumnya tepat pada menit jadwalnya!
  // =========================================================================
  const daftarWajib = ["Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya"];
  for (const w of daftarWajib) {
    const jamAdzan = waktuSholatTerkoreksi(jdw, w);
    if (!jamAdzan) continue;
    const wLower = w.toLowerCase();
    const adzanOn = Boolean(cfg["adzan_" + wLower + "_on"]);
    const tarhimOn = Boolean(cfg["tarhim_" + wLower + "_on"]);

    const durTarhim = tarhimOn ? (Number(cfg.waktuTarhim) || 6) : 0;
    const durAsmaul = (w !== "Subuh" && cfg.s_asmaul) ? (Number(cfg.waktuAsmaul) || 4) : 0;
    const durMurottal = Number(cfg.waktuMurottal) || 30;
    const durArham = (w === "Subuh" && cfg.s_arham) ? (Number(cfg.waktuArham) || 10) : 0;

    const jamTarhim = tambahMenit(jamAdzan, -durTarhim);
    const jamAsmaul = tambahMenit(jamTarhim, -durAsmaul);
    const jamMurottal = tambahMenit(jamAsmaul, -durMurottal);
    const jamArham = tambahMenit(jamMurottal, -durArham);

    // JENJANG 6 (TERTINGGI SETELAH ADZAN): HITUNG MUNDUR & PANGGILAN IQOMAH
    const jedaIqomahW = Math.max(6, Number(cfg.waktuIqomah) || 10);
    const jamIqomahTarget = tambahMenit(jamAdzan, jedaIqomahW);
    const jamIqomahCd2 = tambahMenit(jamIqomahTarget, -2);
    const jamIqomahCd1 = tambahMenit(jamIqomahTarget, -1);
    const sedangPutarAdzanDoa = Boolean(currentAudioTitle && (currentAudioTitle.includes("Adzan") || currentAudioTitle.includes("Doa")));

    if (adzanOn) {
      if (!sedangPutarAdzanDoa && cfg.s_countdown_iqomah && jedaIqomahW >= 3 && apakahWaktuJadwalTiba(menitSkrg, jamIqomahCd2, "IQ_CD2_" + w + tglIni)) {
        bunyikanBelMasjid(() => bicaraGoogleTTS(`Dua menit lagi menuju iqomah ${w}.`, true));
        return;
      }
      if (!sedangPutarAdzanDoa && cfg.s_countdown_iqomah && jedaIqomahW >= 2 && apakahWaktuJadwalTiba(menitSkrg, jamIqomahCd1, "IQ_CD1_" + w + tglIni)) {
        bunyikanBelMasjid(() => bicaraGoogleTTS(`Satu menit lagi menuju iqomah ${w}. Mari luruskan dan rapatkan shaf.`, true));
        return;
      }
      if (apakahWaktuJadwalTiba(menitSkrg, jamIqomahTarget, "IQ_MAIN_" + w + "_" + tglIni)) {
        pembunuhAudioOtomatis("IQOMAH_" + w);
        picuSuaraIqomahSekarang(w);
        if (now.getDay() === 4 && w === "Maghrib" && (cfg.s_jumat || cfg.s_yasin_malam_jumat)) {
          setTimeout(() => {
            if (cfg.master_aktif && !currentAudioTitle) {
              pembunuhAudioOtomatis("YASIN_BAKDA_MAGHRIB");
              putarAudio("murottal", "audio/yasin.ogg");
            }
          }, 15 * 60000);
        }
        return;
      }
    }

    // JENJANG 5: KUMANDANG ADZAN TEPAT WAKTU (Langsung membunuh Tarhim/Murottal yang masih bunyi!)
    if (adzanOn && apakahWaktuJadwalTiba(menitSkrg, jamAdzan, "ADZAN_" + w + tglIni)) {
      pembunuhAudioOtomatis("ADZAN_" + w);
      jalankanRangkaianAdzanLengkap(w);
      return;
    }

    if (window.AndroidBridge && typeof window.AndroidBridge.getBgStage === "function") {
      try {
        const stBg = window.AndroidBridge.getBgStage();
        if (stBg && stBg.trim() !== "") {
          tahapSiaranAktif = stBg.trim();
        }
      } catch (e) {}
    }
    const sedangBunyiSekarang = (window.AndroidBridge && typeof window.AndroidBridge.apakahAudioAktif === "function")
      ? Boolean(window.AndroidBridge.apakahAudioAktif())
      : Boolean(currentAudioObj && !currentAudioObj.paused);

    // JENJANG 4: LANTUNAN TARHIM + BEL MASJID (Hanya dipicu 1 kali per waktu sholat dengan Gembok Absolut — Anti Tumpuk/Arisan!)
    const idTahapTarhim = "TARHIM_" + w + "_" + tglIni;
    const diRentangTarhim = (menitSkrg >= hitungMenitAbsolut(jamTarhim) && menitSkrg < hitungMenitAbsolut(jamAdzan));
    if (tarhimOn && durTarhim > 0 && diRentangTarhim && tahapDihentikanManual !== idTahapTarhim) {
      if (!apakahTahapSudahTerkunci(idTahapTarhim)) {
        kunciTahapSekarang(idTahapTarhim);
        pembunuhAudioOtomatis(idTahapTarhim);
        const menitSudahLewat = Math.max(0, menitSkrg - hitungMenitAbsolut(jamTarhim));
        putarAudio("tarhim", w);
        if (menitSudahLewat > 0 && window.AndroidBridge && window.AndroidBridge.seekAudioTo) {
          setTimeout(() => {
            try { window.AndroidBridge.seekAudioTo((menitSudahLewat * 60 + detikSkrg) * 1000); } catch (e) {}
          }, 350);
        }
        bunyikanBelMasjid();
      }
      return;
    }

    // JENJANG 3B (KHUSUS SUBUH): PENGINGAT IMSAK 10 MENIT PRA-SUBUH
    if (w === "Subuh" && cfg.s_imsak) {
      const jamImsak = tambahMenit(jamAdzan, -10);
      if (apakahWaktuJadwalTiba(menitSkrg, jamImsak, "IMSAK_" + tglIni)) {
        bunyikanBelMasjid(() => bicaraGoogleTTS(`Perhatian, pukul ${jamImsak} telah memasuki waktu Imsak, sepuluh menit menjelang kumandang adzan Subuh pukul ${jamAdzan}.`, true));
        return;
      }
    }

    // JENJANG 3A (KHUSUS DZUHUR SELAIN JUMAT): PERINGATAN WAKTU ISTIWA (8 MENIT SEBELUM DZUHUR)
    if (w === "Dzuhur" && cfg.s_istiwa && now.getDay() !== 5) {
      const jamIstiwa = tambahMenit(jamAdzan, -Math.max(8, durTarhim + durAsmaul));
      if (apakahWaktuJadwalTiba(menitSkrg, jamIstiwa, "ISTIWA_" + tglIni)) {
        bunyikanBelMasjid(() => {
          bicaraGoogleTTS(`Perhatian, pukul ${jamIstiwa} memasuki waktu Istiwa menjelang waktu Dzuhur pukul ${jamAdzan}. Waktu dilarang mendirikan salat sunnah hingga kumandang adzan Dzuhur.`, true);
        });
        return;
      }
    }

    // JENJANG 3: LANTUNAN ASMAUL HUSNA — HIJJAZ (Hanya dipicu 1 kali per waktu sholat dengan Gembok Absolut — Anti Tumpuk/Arisan!)
    const idTahapAsmaul = "ASMAUL_" + w + "_" + tglIni;
    const diRentangAsmaul = (menitSkrg >= hitungMenitAbsolut(jamAsmaul) && menitSkrg < hitungMenitAbsolut(jamTarhim));
    if (w !== "Subuh" && durAsmaul > 0 && diRentangAsmaul && tahapDihentikanManual !== idTahapAsmaul) {
      if (!apakahTahapSudahTerkunci(idTahapAsmaul)) {
        kunciTahapSekarang(idTahapAsmaul);
        pembunuhAudioOtomatis(idTahapAsmaul);
        putarAsmaulHusnaAman();
      }
      return;
    }

    // JENJANG 2: LANTUNAN MUROTTAL PRA-ADZAN (Hanya dipicu 1 kali per waktu sholat dengan Gembok Absolut — Anti Tumpuk/Arisan!)
    const idTahapMurottal = "MUROTTAL_" + w + "_" + tglIni;
    const diRentangMurottal = (menitSkrg >= hitungMenitAbsolut(jamMurottal) && menitSkrg < hitungMenitAbsolut(jamAsmaul));
    if (durMurottal > 0 && diRentangMurottal && tahapDihentikanManual !== idTahapMurottal) {
      if (!apakahTahapSudahTerkunci(idTahapMurottal)) {
        kunciTahapSekarang(idTahapMurottal);
        pembunuhAudioOtomatis(idTahapMurottal);
        const isMalamJumat = (now.getDay() === 4);
        const menitLewatMurottal = Math.max(0, menitSkrg - hitungMenitAbsolut(jamMurottal));
        if (cfg.s_jumat && now.getDay() === 5 && w === "Dzuhur") {
          putarAudio("murottal", "audio/aljumuah.ogg");
        } else if ((cfg.s_jumat || cfg.s_yasin_malam_jumat) && isMalamJumat && (w === "Maghrib" || w === "Isya")) {
          putarAudio("murottal", "audio/yasin.ogg");
        } else {
          putarAudio("murottal", wLower);
        }
        if (menitLewatMurottal > 0 && cfg.modeMurottal !== "sambung" && window.AndroidBridge && window.AndroidBridge.seekAudioTo) {
          setTimeout(() => {
            try { window.AndroidBridge.seekAudioTo((menitLewatMurottal * 60 + detikSkrg) * 1000); } catch (e) {}
          }, 350);
        }
        if (cfg.s_bel) bunyikanBelMasjid();
      }
      return;
    }

    // JENJANG 1: LANTUNAN YA ARHAMARROHIMIN (Hanya dipicu 1 kali per waktu sholat dengan Gembok Absolut — Anti Tumpuk/Arisan!)
    const idTahapArham = "ARHAM_SUBUH_" + tglIni;
    const diRentangArham = (menitSkrg >= hitungMenitAbsolut(jamArham) && menitSkrg < hitungMenitAbsolut(jamMurottal));
    if (w === "Subuh" && durArham > 0 && diRentangArham && tahapDihentikanManual !== idTahapArham) {
      if (!apakahTahapSudahTerkunci(idTahapArham)) {
        kunciTahapSekarang(idTahapArham);
        pembunuhAudioOtomatis(idTahapArham);
        const menitLewatArham = Math.max(0, menitSkrg - hitungMenitAbsolut(jamArham));
        putarAudio("sistem", "audio/Arhamarrohimin Tarhim.ogg");
        if (menitLewatArham > 0 && window.AndroidBridge && window.AndroidBridge.seekAudioTo) {
          setTimeout(() => {
            try { window.AndroidBridge.seekAudioTo((menitLewatArham * 60 + detikSkrg) * 1000); } catch (e) {}
          }, 350);
        }
        if (cfg.s_bel) bunyikanBelMasjid();
      }
      return;
    }
  }

  // =========================================================================
  // WAKTU-WAKTU PENTING IBADAH HARIAN (DI LUAR ZONA STERIL RANGKAIAN SALAT)
  // =========================================================================
  if (apakahSedangDalamZonaSterilSalat(menitSkrg, jdw)) return;

  // 1. Pengingat Waktu Khusus (Alarm Ibadah Pribadi — persis main.lua baris 922-928)
  if (cfg.alarm_waktu && apakahWaktuJadwalTiba(menitSkrg, cfg.alarm_waktu, "ALARM_PRIBADI_" + tglIni + "_" + cfg.alarm_waktu)) {
    pembunuhAudioOtomatis("ALARM_KHUSUS");
    putarAudio("sistem", "audio/bumper.mp3", () => bicaraGoogleTTS(cfg.alarm_pesan || "Alarm pribadi berbunyi.", true));
    return;
  }

  // 2. Pengingat Sepertiga Malam Terakhir / Salat Tahajud dengan WAKTU NYATA (2/3 Malam dari Maghrib & Subuh Nyata — persis main.lua baris 954-965!)
  if (cfg.s_tahajud && jdw.Maghrib && jdw.Subuh) {
    const tm = hitungMenitAbsolut(waktuSholatTerkoreksi(jdw, "Maghrib"));
    let ts = hitungMenitAbsolut(waktuSholatTerkoreksi(jdw, "Subuh"));
    if (tm >= 0 && ts >= 0) {
      if (ts < tm) ts += 1440;
      const thj = Math.floor(tm + (2 * (ts - tm) / 3)) % 1440;
      const jamTahajudNyata = String(Math.floor(thj / 60)).padStart(2, "0") + ":" + String(thj % 60).padStart(2, "0");
      if (apakahWaktuJadwalTiba(menitSkrg, jamTahajudNyata, "THJ_" + tglIni)) {
        pembunuhAudioOtomatis("TAHAJUD_NYATA");
        bicaraGoogleTTS("Sepertiga malam terakhir telah tiba. Bangunlah untuk sholat Tahajud.", true, () => {
          putarAudio("sistem", "audio/tahajud.mp3");
        });
        return;
      }
    }
  }

  // 2b. Pengingat Sahur Ramadhan (60 Menit Sebelum Subuh Nyata — persis main.lua baris 967-974)
  if ((window.BulanHijriyahIni === "Ramadhan" || bulanHijriyahIni === "Ramadhan") && jdw.Subuh) {
    const jamSahur = tambahMenit(waktuSholatTerkoreksi(jdw, "Subuh"), -60);
    if (apakahWaktuJadwalTiba(menitSkrg, jamSahur, "SAHUR_" + tglIni)) {
      pembunuhAudioOtomatis("SAHUR_RAMADHAN");
      bicaraGoogleTTS("Waktu sahur telah tiba. Subuh tersisa enam puluh menit lagi.", true);
      return;
    }
  }

  // 3. Waktu-Waktu Penting Ibadah Pagi: Estafet Pra-Terbit (10 mnt sebelum Terbit: Timer 10 Detik -> Peringatan Terbit 128kbps -> Ya Muhaimin Ya Salam) & Waktu Terbit (Sirine -> Terbit 128kbps)
  if (jdw.Terbit) {
    const jamPraTerbit = tambahMenit(jdw.Terbit, -10);
    const jamDhuha = jdw.Dhuha || tambahMenit(jdw.Terbit, 20);
    if (cfg.s_preterbit && apakahWaktuJadwalTiba(menitSkrg, jamPraTerbit, "PRETERBIT_" + tglIni)) {
      jalankanEstafetPeringatanTerbit();
      return;
    }
    if (cfg.s_terbit && apakahWaktuJadwalTiba(menitSkrg, jdw.Terbit, "TERBIT_" + tglIni)) {
      jalankanEstafetWaktuTerbit();
      return;
    }
    if (cfg.s_dhuha && apakahWaktuJadwalTiba(menitSkrg, jamDhuha, "DHUHA_" + tglIni)) {
      pembunuhAudioOtomatis("DHUHA");
      putarAudio("sistem", "audio/dhuha.ogg");
      return;
    }
  }

  // 4. Peringatan Hari Jumat Pukul 10:00 (persis main.lua baris 995-996)
  if (cfg.s_jumat && now.getDay() === 5 && apakahWaktuJadwalTiba(menitSkrg, "10:00", "SJ_" + tglIni)) {
    bicaraGoogleTTS("Hari ini adalah Jumat. Bacalah Al-Kahfi, perbanyak shalawat, dan bersegeralah ke masjid.", true);
    return;
  }

  // 5. Peringatan Kehati-hatian Akhir Waktu Sholat (15 Menit Sebelum Habis Waktu Dzuhur, Ashar, Maghrib, Isya — persis main.lua baris 1044-1047!)
  if (cfg.s_kehatihatian) {
    const pAkhir = [
      { c: "Dzuhur", n: waktuSholatTerkoreksi(jdw, "Ashar") },
      { c: "Ashar", n: waktuSholatTerkoreksi(jdw, "Maghrib") },
      { c: "Maghrib", n: waktuSholatTerkoreksi(jdw, "Isya") },
      { c: "Isya", n: waktuSholatTerkoreksi(jdw, "Subuh") }
    ];
    for (const wp of pAkhir) {
      if (wp.n && apakahWaktuJadwalTiba(menitSkrg, tambahMenit(wp.n, -15), "HATI_" + wp.c + "_" + tglIni)) {
        bicaraGoogleTTS(`Peringatan kehati-hatian. Waktu sholat ${wp.c} tersisa lima belas menit lagi.`, true);
        return;
      }
    }
  }

  // 6. Pengingat Puasa Lengkap (10 Menit Setelah Maghrib Nyata — persis main.lua baris 1019-1042!)
  if (cfg.s_puasa && jdw.Maghrib) {
    const jamPengingatPuasa = tambahMenit(waktuSholatTerkoreksi(jdw, "Maghrib"), 10);
    if (apakahWaktuJadwalTiba(menitSkrg, jamPengingatPuasa, "PUASA_" + tglIni)) {
      const bs = (now.getDay() + 1) % 7;
      ambilTanggalHijriyah(1, function(teksH, tgl, bln) {
        if (!tgl || !bln) {
          if (bs === 1 || bs === 4) {
            bicaraGoogleTTS("Besok adalah hari " + (bs === 1 ? "Senin" : "Kamis") + ". Jangan lupa berniat puasa sunnah.", true);
          }
          return;
        }
        let pPesan = "";
        if (bln === "Muharram" && tgl === 9) pPesan = "Besok adalah tanggal 9 Muharram. Jangan lupa berniat puasa sunnah Tasu'a.";
        else if (bln === "Muharram" && tgl === 10) pPesan = "Besok adalah tanggal 10 Muharram. Jangan lupa berniat puasa sunnah Asyura.";
        else if (bln === "Zulhijah" && tgl === 8) pPesan = "Besok adalah tanggal 8 Zulhijah. Jangan lupa berniat puasa sunnah Tarwiyah.";
        else if (bln === "Zulhijah" && tgl === 9) pPesan = "Besok adalah tanggal 9 Zulhijah. Jangan lupa berniat puasa sunnah Arafah.";
        else if (bln === "Syakban" && tgl === 15) pPesan = "Besok adalah Nisfu Syakban. Anda dianjurkan berpuasa sunnah dan memperbanyak ibadah.";
        else if (bln === "Ramadhan" && tgl === 1) pPesan = "Alhamdulillah, besok adalah hari pertama bulan suci Ramadhan. Jangan lupa berniat puasa wajib.";
        else if (bln === "Syawal" && tgl >= 2 && tgl <= 7) pPesan = "Besok adalah tanggal " + tgl + " Syawal. Mari rutinkan puasa sunnah enam hari Syawal.";
        else if ((tgl === 13 || tgl === 14 || tgl === 15) && bln !== "Ramadhan" && !(bln === "Zulhijah" && tgl === 13)) {
          pPesan = "Besok masuk puasa sunnah Ayyamul Bidh tanggal " + tgl + " " + bln + ".";
        } else if (bs === 1 || bs === 4) {
          pPesan = "Besok adalah hari " + (bs === 1 ? "Senin" : "Kamis") + ". Jangan lupa berniat puasa sunnah.";
        }
        if (pPesan) { putarAudio("sistem", "audio/bumper.mp3", () => { bicaraGoogleTTS(pPesan, true); }); }
      });
      return;
    }
  }

  // 7. Laporan Asisten Hidup 5 Waktu Sholat (Gaya Marbot Masjid — Otomatis Beberapa Menit Sebelum 5 Waktu Sholat + bel_pendek.mp3, Menggantikan Laporan Tiap Jam)
  if (cfg.s_jam) {
    const menitSebelum = Number(cfg.menitLaporan5Waktu) || 15;
    for (let i = 0; i < daftarWajib.length; i++) {
      const namaW = daftarWajib[i];
      const jamW = waktuSholatTerkoreksi(jdw, namaW);
      if (!jamW) continue;
      const jamLap5 = tambahMenit(jamW, -menitSebelum);
      const kunciLap5 = "LAP5WAKTU_" + namaW + "_" + tglIni;
      if (apakahWaktuJadwalTiba(menitSkrg, jamLap5, kunciLap5)) {
        const lokasiSebut = cfg.lokasiDitemukan || cfg.kota || "wilayah Anda";
        const pesanMarbot = `Assalamu'alaikum warahmatullahi wabarakatuh. Sekarang pukul ${hh} lewat ${mm} menit. ${menitSebelum} menit lagi akan memasuki waktu sholat ${namaW} pada pukul ${jamW.replace(":", " lewat ")} untuk ${lokasiSebut}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`;
        if (cfg.s_bel !== false) {
          putarAudio("sistem", "audio/bel_pendek.mp3", () => {
            bicaraGoogleTTS(pesanMarbot, true);
          });
        } else {
          bicaraGoogleTTS(pesanMarbot, true);
        }
        return;
      }
    }
  }
}
window.detakMesinMasjid = detakMesinMasjid;

let __intervalDetakUtama = setInterval(detakMesinMasjid, 1000);

// WATCHDOG JANTUNG MASJID (persis main.lua baris 1175-1187: menghidupkan kembali mesin otomatis jika detak jantung terhenti!)
function watchdogMesin() {
  try {
    const skrgSec = Math.floor(Date.now() / 1000);
    if (skrgSec - (window.DetakJantung || 0) > 30) {
      window.SesiMesinAktif = (window.SesiMesinAktif || 1) + 1;
      if (__intervalDetakUtama) clearInterval(__intervalDetakUtama);
      __intervalDetakUtama = setInterval(detakMesinMasjid, 1000);
      detakMesinMasjid();
    }
  } catch (e) {}
}
setInterval(watchdogMesin, 15000);

// -------------------------------------------------------------------------
// SINKRONISASI CUACA & GEMPA BMKG
// -------------------------------------------------------------------------
function tarikCuacaDanGempa(cb) {
  const lat = cfg.latitude || -7.7062;
  const lon = cfg.longitude || 114.0095;
  const nLok = cfg.kecamatan || cfg.lokasiDitemukan || cfg.kota;
  fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto`)
    .then(r => r.json())
    .then(d => {
      const temp = d.current.temperature_2m;
      window.KodeCuacaIni = Number(d.current.weather_code) || 0;
      const tMax = d.daily.temperature_2m_max[0];
      const tMin = d.daily.temperature_2m_min[0];
      cacheCuacaSuara = `Prakiraan cuaca ${nLok} hari ini bersuhu ${temp} derajat Celcius, dengan suhu terendah ${tMin} derajat dan tertinggi ${tMax} derajat Celcius.`;
      cacheCuaca = `Wilayah: ${nLok} • Suhu Saat Ini: ${temp}°C (Terendah ${tMin}°C, Tertinggi ${tMax}°C)`;
      if (cb) cb();
    })
    .catch(() => { if (cb) cb(); });

  fetch("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json")
    .then(r => r.json())
    .then(d => {
      const g = d.Infogempa.gempa;
      cacheGempa = `Gempa ${g.Magnitude} SR • Pusat: ${g.Wilayah} (${g.Tanggal} ${g.Jam}) • ${g.Potensi}`;
      if (cb) cb();
    })
    .catch(() => { if (cb) cb(); });
}

// -------------------------------------------------------------------------
// PEMBANTU ANTARMUKA AKSESIBEL RAMAH TUNANETRA (TALKBACK & JIESHUO)
// -------------------------------------------------------------------------
function bersihkanLayar(namaHalaman = "submenu") {
  halamanAktif = namaHalaman;
  idCounterUnik = 1;
  if (kompasListenerAktif && window.AndroidBridge && window.AndroidBridge.stopCompass) {
    try { window.AndroidBridge.stopCompass(); } catch (e) {}
    kompasListenerAktif = false;
  }
  const root = document.getElementById("app-root");
  root.innerHTML = "";
  window.scrollTo(0, 0);
  return root;
}

function tambahHeader(root, judul, sub) {
  const div = document.createElement("header");
  div.id = "kartu-header-halaman";
  div.className = "header-card";
  div.innerHTML = `<h1 id="judul-halaman-aktif" tabindex="0">${judul} — ${sub}</h1>`;
  root.appendChild(div);
  setTimeout(() => {
    const h1 = document.getElementById("judul-halaman-aktif");
    if (h1) h1.focus();
  }, 50);
}

function tambahLabelBagian(root, teks, idKhusus = "") {
  const h2 = document.createElement("h2");
  h2.id = idKhusus || buatIdElemen("judul-bagian", teks);
  h2.className = "section-label";
  h2.setAttribute("tabindex", "0");
  h2.textContent = teks;
  root.appendChild(h2);
  return h2;
}

function tambahTombol(root, teks, warnaKelas, aksiKlik, idKhusus = "") {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.id = idKhusus || buatIdElemen("btn", teks);
  btn.className = `btn ${warnaKelas || ""}`.trim();
  btn.textContent = teks;
  btn.setAttribute("aria-label", teks);
  btn.addEventListener("click", function() {
    aksiKlik(btn);
  });
  root.appendChild(btn);
  return btn;
}

// Sakelar Aksesibel Dengan ID Elemen Unik & Update In-Place Tanpa Merusak Fokus Layar
function tambahSakelarAksesibel(root, labelFitur, keyConfig, idKhusus = "") {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.id = idKhusus || `btn-sakelar-${keyConfig}`;
  function perbaruiTampilanSakelar() {
    const aktif = !!cfg[keyConfig];
    btn.className = `btn ${aktif ? "btn-green" : "btn-gray"}`;
    btn.setAttribute("aria-pressed", aktif ? "true" : "false");
    const teksUtuh = `${labelFitur}: ${aktif ? "AKTIF" : "NONAKTIF"} (Ketuk untuk Ubah)`;
    btn.textContent = teksUtuh;
    btn.setAttribute("aria-label", teksUtuh);
  }
  perbaruiTampilanSakelar();
  btn.addEventListener("click", function() {
    cfg[keyConfig] = !cfg[keyConfig];
    simpanData();
    perbaruiTampilanSakelar();
    if (keyConfig === "master_aktif") {
      if (!cfg.master_aktif) {
        hentikanAudioDanSimpan();
        bicaraGoogleTTS("Siaran otomatis 24 jam dinonaktifkan. Seluruh pemutaran audio otomatis dihentikan.");
      } else {
        const semuaMasihMati = !cfg.adzan_subuh_on && !cfg.adzan_dzuhur_on && !cfg.tarhim_subuh_on && !cfg.tarhim_dzuhur_on;
        if (semuaMasihMati) {
          aktifkanCepatStandarMasjid();
        }
        bicaraGoogleTTS("Siaran otomatis 24 jam beserta sakelar adzan dan tarhim telah diaktifkan.");
        setTimeout(detakMesinMasjid, 300);
      }
      return;
    }
    bicaraGoogleTTS(`${labelFitur} ${cfg[keyConfig] ? "diaktifkan" : "dinonaktifkan"}.`);
  });
  root.appendChild(btn);
  return btn;
}

// Render Daftar Jadwal Salat Rapat & Dibaca Utuh Satu Baris Lengkap oleh Jieshuo / TalkBack (Setiap Baris Punya ID Elemen Unik!)
function buatKotakJadwalTerstruktur(root, judulKotak, jdwObj) {
  const box = document.createElement("div");
  box.id = "wadah-jadwal-salat-utama";
  box.className = "schedule-box";

  const sSubuh = waktuSholatTerkoreksi(jdwObj, "Subuh");
  const sImsak = tambahMenit(sSubuh, -10);
  const sTerbit = jdwObj.Terbit;
  const sDhuha = jdwObj.Dhuha || tambahMenit(jdwObj.Terbit, 20);
  const sDzuhur = waktuSholatTerkoreksi(jdwObj, "Dzuhur");
  const sIstiwa = tambahMenit(sDzuhur, -8);
  const sAshar = waktuSholatTerkoreksi(jdwObj, "Ashar");
  const sMaghrib = waktuSholatTerkoreksi(jdwObj, "Maghrib");
  const sIsya = waktuSholatTerkoreksi(jdwObj, "Isya");

  const kalimatSemuaJadwal = `${judulKotak}: Imsak ${sImsak}, Subuh ${sSubuh}, Terbit ${sTerbit}, Dhuha ${sDhuha}, Istiwa (Larangan Salat) ${sIstiwa} s/d ${sDzuhur}, Dzuhur ${sDzuhur}, Ashar ${sAshar}, Maghrib ${sMaghrib}, Isya ${sIsya}.`;

  const btnJudulJadwal = document.createElement("button");
  btnJudulJadwal.type = "button";
  btnJudulJadwal.id = "btn-judul-jadwal-lengkap";
  btnJudulJadwal.className = "btn btn-teal";
  btnJudulJadwal.textContent = kalimatSemuaJadwal;
  btnJudulJadwal.setAttribute("aria-label", kalimatSemuaJadwal);
  btnJudulJadwal.addEventListener("click", () => bicaraGoogleTTS(kalimatSemuaJadwal));
  box.appendChild(btnJudulJadwal);

  const mLapK = Number(cfg.menitLaporan5Waktu) || 15;
  const mHatiK = Number(cfg.menitKehatihatian) || 15;
  const infoMarbot5 = `Subuh ${tambahMenit(sSubuh, -mLapK)}, Dzuhur ${tambahMenit(sDzuhur, -mLapK)}, Ashar ${tambahMenit(sAshar, -mLapK)}, Maghrib ${tambahMenit(sMaghrib, -mLapK)}, Isya ${tambahMenit(sIsya, -mLapK)} (${cfg.s_marbot !== false ? "AKTIF" : "NONAKTIF"})`;
  const infoHati5 = `Akhir Subuh ${tambahMenit(sTerbit, -mHatiK)}, Akhir Dzuhur ${tambahMenit(sAshar, -mHatiK)}, Akhir Ashar ${tambahMenit(sMaghrib, -mHatiK)}, Akhir Maghrib ${tambahMenit(sIsya, -mHatiK)}, Akhir Isya ${tambahMenit(sSubuh, -mHatiK)} (${cfg.s_kehatihatian !== false ? "AKTIF" : "NONAKTIF"})`;

  const barisJadwal = [
    ["imsak", "1. Waktu Imsak (10 Menit Pra-Subuh)", sImsak],
    ["subuh", "2. Waktu Salat Subuh", sSubuh],
    ["terbit", "3. Waktu Matahari Terbit (Syuruq)", sTerbit],
    ["dhuha", "4. Waktu Salat Sunnah Dhuha", sDhuha],
    ["istiwa", "5. Waktu Istiwa / Zawal (Larangan Salat Menjelang Dzuhur)", `${sIstiwa} s/d ${sDzuhur}`],
    ["dzuhur", "6. Waktu Salat Dzuhur", sDzuhur],
    ["ashar", "7. Waktu Salat Ashar", sAshar],
    ["maghrib", "8. Waktu Salat Maghrib", sMaghrib],
    ["isya", "9. Waktu Salat Isya", sIsya],
    ["marbot15", `10. Pengumuman Asisten Marbot (${mLapK} Menit Menjelang 5 Waktu Sholat)`, infoMarbot5],
    ["hati15", `11. Peringatan ${mHatiK} Menit Waktu Kehati-hatian (Menjelang Akhir Waktu Sholat)`, infoHati5]
  ];

  barisJadwal.forEach(([kodeId, namaW, jamW]) => {
    const teksBarisUtuh = `${namaW}: Pukul ${jamW}`;
    const row = document.createElement("button");
    row.type = "button";
    row.id = `btn-jadwal-waktu-${kodeId}`;
    row.className = "schedule-row";
    row.textContent = teksBarisUtuh;
    row.setAttribute("aria-label", teksBarisUtuh);
    row.addEventListener("click", () => bicaraGoogleTTS(`${namaW} pukul ${jamW}`));
    box.appendChild(row);
  });

  root.appendChild(box);
}

// -------------------------------------------------------------------------
// BERANDA UTAMA APK (RAPAT, SEMUA TOMBOL BER-ID, TIDAK KELUAR DARI APK)
// -------------------------------------------------------------------------
function tampilkanMenuUtama() {
  pastikanJadwalTersedia();
  const root = bersihkanLayar("beranda");

  const now = new Date();
  const jamStr = `${String(now.getHours()).padStart(2, "0")} : ${String(now.getMinutes()).padStart(2, "0")}`;
  const lokSudahAda = apakahLokasiSudahDiatur();
  const clockBtn = document.createElement("button");
  clockBtn.type = "button";
  clockBtn.id = "btn-jam-digital-utama";
  clockBtn.className = "clock-panel";
  clockBtn.setAttribute("aria-label", `Beranda Nurul Masjid Pro. Pengembang Resmi: Nur dan Mas Yeni Setiawan. Jam Digital Masjid pukul ${jamStr} WIB. ${lokSudahAda ? "Wilayah " + (cfg.lokasiDitemukan || cfg.kota) : "Wilayah belum diatur, silakan pilih lokasi Anda"}. Ketuk untuk dengar status jam masjid.`);
  clockBtn.innerHTML = `
    <div class="clock-label">NURUL MASJID PRO • JAM DIGITAL HIDUP</div>
    <div style="color:#FDE68A;font-size:0.98rem;font-weight:800;margin:4px 0 6px 0;letter-spacing:0.3px;">PENGEMBANG RESMI: NUR &amp; MAS YENI SETIAWAN</div>
    <div class="clock-digits" id="live-clock-digits">${jamStr} WIB</div>
    <div class="clock-sub" id="live-clock-sub-hijri">${infoHariBesarIslam(0)}</div>
  `;
  clockBtn.addEventListener("click", () => {
    if (!apakahLokasiSudahDiatur()) {
      bicaraGoogleTTS(`Nurul Masjid Pro karya Nur dan Mas Yeni Setiawan. Saat ini pukul ${now.getHours()} lewat ${now.getMinutes()} menit. Wilayah lokasi belum diatur dan seluruh sakelar masih dalam keadaan mati. Silakan pilih wilayah Kecamatan dan Desa Anda terlebih dahulu.`);
    } else {
      bicaraGoogleTTS(`Nurul Masjid Pro karya Nur dan Mas Yeni Setiawan. Saat ini pukul ${now.getHours()} lewat ${now.getMinutes()} menit. Wilayah ${cfg.lokasiDitemukan || cfg.kota}. ${hitungSisaWaktuTeks()}`);
    }
  });
  root.appendChild(clockBtn);

  const sumList = document.createElement("div");
  sumList.id = "wadah-ringkasan-beranda";
  sumList.className = "summary-list";

  const teksDevBeranda = "Identitas Pengembang Resmi: Nur (Jawa Timur) & Mas Yeni Setiawan (Banyumas, Jawa Tengah) — Karya Asli Jam Digital Masjid & Asisten Ibadah 24 Jam (Ketuk untuk Profil Lengkap)";
  const btnDevRingkas = document.createElement("button");
  btnDevRingkas.type = "button";
  btnDevRingkas.id = "btn-identitas-pengembang-beranda";
  btnDevRingkas.className = "summary-item";
  btnDevRingkas.style.cssText = "border-left:5px solid #FBBF24;font-weight:800;";
  btnDevRingkas.textContent = teksDevBeranda;
  btnDevRingkas.setAttribute("aria-label", teksDevBeranda);
  btnDevRingkas.addEventListener("click", bukaMenuTentangAplikasi);
  sumList.appendChild(btnDevRingkas);

  const teksLok = lokSudahAda
    ? `Wilayah Aktif: ${cfg.lokasiDitemukan || cfg.kota} (Koordinat Asli: ${Number(cfg.latitude).toFixed(4)}, ${Number(cfg.longitude).toFixed(4)} • Arah Kiblat ${cfg.sudutKiblat}°)`
    : "Wilayah Aktif: BELUM DIATUR (Kondisi Awal Kosong — Ketuk untuk Memilih Provinsi, Kabupaten/Kota, Kecamatan & Desa)";

  const btnLokRingkas = document.createElement("button");
  btnLokRingkas.type = "button";
  btnLokRingkas.id = "btn-info-wilayah-aktif";
  btnLokRingkas.className = "summary-item";
  btnLokRingkas.textContent = teksLok;
  btnLokRingkas.setAttribute("aria-label", teksLok);
  btnLokRingkas.addEventListener("click", menuPengaturanLokasi);
  sumList.appendChild(btnLokRingkas);

  const teksKal = `Kalender Hari Ini: ${formatTanggalIndo(dapatkanTanggalISO(0))} (${hitungPasaranJawa(0)}) • ${tanggalHijriyahCache}`;
  const btnKalRingkas = document.createElement("button");
  btnKalRingkas.type = "button";
  btnKalRingkas.id = "btn-info-hari-pasaran";
  btnKalRingkas.className = "summary-item";
  btnKalRingkas.textContent = teksKal;
  btnKalRingkas.setAttribute("aria-label", teksKal);
  btnKalRingkas.addEventListener("click", () => bicaraGoogleTTS(teksKal));
  sumList.appendChild(btnKalRingkas);

  if (lokSudahAda) {
    const tgt = dapatkanTargetSholatBerikutnya();
    const teksTarget = `Waktu Salat Berikutnya: Menuju ${tgt.nama} pukul ${tgt.jam} (${Math.floor(tgt.selisihMenit / 60)} Jam ${tgt.selisihMenit % 60} Menit lagi)`;
    const btnTarget = document.createElement("button");
    btnTarget.type = "button";
    btnTarget.id = "btn-info-target-berikutnya";
    btnTarget.className = "summary-item";
    btnTarget.textContent = teksTarget;
    btnTarget.setAttribute("aria-label", teksTarget);
    btnTarget.addEventListener("click", () => bicaraGoogleTTS(teksTarget));
    sumList.appendChild(btnTarget);
  }
  root.appendChild(sumList);

  const tglIni = dapatkanTanggalISO(0);
  const j = cfg.jadwalSebulan && cfg.jadwalSebulan[tglIni];
  if (lokSudahAda && j) {
    buatKotakJadwalTerstruktur(
      root,
      `Jadwal Salat 9 Waktu Hari Ini (Ikhtiyath ${cfg.ikhtiar >= 0 ? "+" : ""}${cfg.ikhtiar} Menit)`,
      j
    );
  }

  tambahLabelBagian(root, "Kendali Utama Cepat (Lokasi, Siaran 24 Jam, Tarhim & Reset ke Nol)", "judul-kendali-utama-luar");

  tambahTombol(root, "Pilih Wilayah, Provinsi, Kabupaten/Kota, Kecamatan & Desa Asli", "btn-teal", menuPengaturanLokasi, "btn-utama-pengaturan-wilayah");

  tambahSakelarAksesibel(root, "Status Mesin Siaran & Adzan Otomatis 24 Jam", "master_aktif", "btn-sakelar-master-siaran-24jam");

  tambahTombol(root, "Aktifkan Cepat Seluruh Sakelar Standar Masjid (Adzan, Tarhim, Marbot 15 Menit, Waktu Kehati-hatian, Asmaul Husna & Doa)", "btn-green", () => {
    aktifkanCepatStandarMasjid();
    cfg.s_marbot = true;
    cfg.s_kehatihatian = true;
    cfg.s_laporan3waktu = true;
    cfg.s_sapaan_pra_adzan = true;
    cfg.popupHentikanLuar = true;
    cfg.goyangHentikan = false;
    simpanData();
    bicaraGoogleTTS("Alhamdulillah, seluruh sakelar standar siaran masjid termasuk Asisten Marbot 15 menit menjelang sholat dan peringatan 15 menit waktu kehati-hatian telah diaktifkan.");
    tampilkanMenuUtama();
  }, "btn-aktifkan-cepat-semua-sakelar");

  tambahTombol(root, `Fitur Asisten Marbot Masjid (Pengumuman ${Number(cfg.menitLaporan5Waktu) || 15} Menit Menjelang 5 Waktu Sholat & Peringatan ${Number(cfg.menitKehatihatian) || 15} Menit Waktu Kehati-hatian)`, "btn-teal", () => {
    if (typeof bukaMenuMarbotMasjid === "function") bukaMenuMarbotMasjid();
  }, "btn-utama-fitur-marbot-masjid");

  tambahTombol(root, "Bacakan Rangkuman Pagi, Sisa Waktu & Info Cuaca Hari Ini", "btn-blue", () => {
    if (typeof buatRangkumanPagiTeks === "function") {
      bicaraGoogleTTS(buatRangkumanPagiTeks());
    }
  }, "btn-utama-bacakan-rangkuman-pagi");

  tambahTombol(root, "Pilih Audio Tarhim (Buka Pop-Up Pilihan Tarhim)", "btn-purple", () => bukaPopupPilihTarhim("Semua 5 Waktu Salat", "semua", tampilkanMenuUtama), "btn-utama-popup-tarhim");

  const labelJalurBeranda = (typeof dapatkanInfoJalurAudioAktif === "function") ? dapatkanInfoJalurAudioAktif().pendek : "Jalur Media / Musik";
  tambahTombol(root, `Pilih Jalur Saluran Audio / Streaming (Saat Ini: ${labelJalurBeranda} — Media, Nada Dering, Notifikasi, Alarm, Sistem)`, "btn-teal", () => {
    if (typeof bukaPopupPilihJalurAudio === "function") bukaPopupPilihJalurAudio(tampilkanMenuUtama);
  }, "btn-utama-pilih-jalur-audio");

  tambahSakelarAksesibel(root, "Munculkan Otomatis Jendela Pop-Up Tombol Besar Hentikan Suara di Layar Kunci Saat Jadwal Masuk (Jadwal Latar Tetap Aktif)", "popupHentikanLuar", "btn-sakelar-popup-hentikan-luar");

  tambahTombol(root, "Uji Munculkan Jendela Pop-Up Tombol Besar Hentikan Suara di Layar Kunci Sekarang", "btn-amber", () => {
    if (window.AndroidBridge && window.AndroidBridge.showStopPopup) {
      window.AndroidBridge.showStopPopup("Simulasi Jadwal Masuk di Layar Kunci (Tombol Besar Hentikan Suara)", true);
    } else {
      bicaraGoogleTTS("Jendela Pop-Up Tombol Besar Hentikan Suara akan muncul otomatis di layar kunci saat aplikasi diinstal sebagai APK Android.");
    }
  }, "btn-uji-popup-hentikan-luar");

  tambahTombol(root, "Periksa Update Otomatis & Audio Baru dari Server Sekarang (Tanpa Instal Ulang APK)", "btn-blue", () => {
    periksaUpdateOtomatisServer(true);
  }, "btn-utama-update-otomatis-server");

  tambahTombol(root, "Jalankan di Latar Belakang & Ke Beranda HP (Mesin Tetap Aktif 24 Jam)", "btn-dark", () => {
    bicaraGoogleTTS("Aplikasi berjalan di latar belakang. Menuju layar beranda ponsel.", true);
    if (window.AndroidBridge && window.AndroidBridge.hideToBackground) {
      setTimeout(() => window.AndroidBridge.hideToBackground(), 300);
    }
  }, "btn-utama-jalankan-latar-belakang");

  tambahTombol(root, "Traktir Pengembang (Dukungan Sukarela GoPay)", "btn-blue", bukaMenuTraktirPengembang, "btn-utama-traktir-gopay");

  tambahTombol(root, "Reset Pabrik ke Kondisi Awal Kosong / Nol (Matikan Semua Sakelar & Kosongkan Lokasi)", "btn-red", () => {
    resetKeNolTotal();
    bicaraGoogleTTS("Reset pabrik selesai. Seluruh lokasi dan sakelar telah dikosongkan ke posisi nol atau mati.");
    tampilkanMenuUtama();
  }, "btn-utama-restart-reset-pabrik");

  tambahLabelBagian(root, "Kategori Pengaturan Siaran, Asisten Marbot, Jalur Saluran Audio, Durasi & Suara");
  tambahTombol(root, `Pengaturan Lengkap Asisten Marbot Masjid (Pengumuman ${Number(cfg.menitLaporan5Waktu) || 15} Menit Menjelang Sholat & Peringatan ${Number(cfg.menitKehatihatian) || 15} Menit Waktu Kehati-hatian)`, "btn-teal", () => {
    if (typeof bukaMenuMarbotMasjid === "function") bukaMenuMarbotMasjid();
  }, "btn-kategori-marbot-masjid");
  tambahTombol(root, "Sakelar & Pilihan Rekaman Adzan, Tarhim, Asmaul Husna, Doa & Bel", "", menuPengaturanAdzan);
  tambahTombol(root, `Atur Durasi Murottal, Tarhim, Iqomah, Marbot (${Number(cfg.menitLaporan5Waktu) || 15} Menit) & Waktu Kehati-hatian (${Number(cfg.menitKehatihatian) || 15} Menit)`, "", menuPengaturanDurasi);
  tambahTombol(root, `Sakelar Asisten Marbot (${Number(cfg.menitLaporan5Waktu) || 15} Menit), Peringatan ${Number(cfg.menitKehatihatian) || 15} Menit Waktu Kehati-hatian, Istiwa & Ibadah Penting`, "", menuSakelarSunnah);
  tambahTombol(root, `Volume Suara, Jalur Saluran Audio (${typeof dapatkanInfoJalurAudioAktif === "function" ? dapatkanInfoJalurAudioAktif().pendek : "Media"}), Mode Murottal & Kecepatan Suara TTS`, "", menuPengaturanAudioMedia, "btn-kategori-volume-jalur-audio");

  tambahLabelBagian(root, "Kategori Wilayah, Kecamatan, Desa Asli & Koreksi Waktu");
  tambahTombol(root, "Atur Wilayah, Kecamatan & Desa Asli (Banyumas, Situbondo, Kudus, Pati & Nasional)", "btn-teal", menuPengaturanLokasi);
  tambahTombol(root, "Daftar Wilayah Favorit & Cadangan Pengaturan Masjid", "btn-teal", menuProfilLokasi);

  tambahLabelBagian(root, "Kategori Sarana Ibadah, Tasbih Digital, Kalender & Info Alam");
  tambahTombol(root, "Kompas Penunjuk Arah Kiblat Bersuara (Sensor Aktif)", "btn-blue", menuRadarKiblat);
  tambahTombol(root, "Kalender Hijriyah, Pasaran Jawa & Hari Besar Islam", "btn-blue", menuKalenderHijriyah);
  tambahTombol(root, "Tabel Jadwal Salat 9 Waktu Harian Lengkap (Termasuk Waktu Istiwa)", "btn-blue", menuJadwalBulanan);
  tambahTombol(root, "Tasbih & Zikir Digital Bersuara + Getar Bakda Salat", "btn-purple", bukaMenuTasbihDigital);
  tambahTombol(root, "Pasang Pengingat Jam Khusus (Alarm Ibadah)", "btn-blue", menuAlarmPribadi);
  tambahTombol(root, "Pantauan Prakiraan Cuaca Lokal & Info Gempa BMKG", "btn-blue", menuInfoAlam);

  tambahLabelBagian(root, "Kategori Uji Coba Suara, Tentang Aplikasi, Lisensi & Traktir Pengembang");
  tambahTombol(root, "Dasbor Uji Coba Suara Lengkap (Marbot 15 Menit, Waktu Kehati-hatian, Jalur Audio, Adzan, Tarhim, Murottal & Terbit)", "btn-green", menuTesAudio);
  tambahTombol(root, "Status Sistem, Pembaruan Server & Izin Baterai", "btn-green", menuDiagnostik);
  tambahTombol(root, "Tentang Aplikasi & Profil Pengembang (Nur & Mas Yeni Setiawan)", "btn-teal", bukaMenuTentangAplikasi, "btn-menu-tentang-aplikasi");
  tambahTombol(root, "Lisensi Resmi & Perlindungan Hak Cipta (UU RI No. 28 Tahun 2014)", "btn-dark", bukaMenuLisensiResmi, "btn-menu-lisensi-resmi");
  tambahTombol(root, "Traktir Pengembang (Dukungan Sukarela GoPay)", "btn-blue", bukaMenuTraktirPengembang, "btn-menu-traktir-pengembang");

  const foot = document.createElement("footer");
  foot.className = "footer-note";
  foot.setAttribute("tabindex", "0");
  foot.textContent = "Pengembang Resmi: Nur (Jawa Timur) & Mas Yeni Setiawan (Banyumas, Jawa Tengah) • WhatsApp / GoPay: 0877-8158-6983 • Dilindungi UU RI No. 28 Tahun 2014 tentang Hak Cipta.";
  root.appendChild(foot);
}

// -------------------------------------------------------------------------
// JENDELA POP-UP PEMILIHAN 3 AUDIO TARHIM (RAMAH JIESHUO & TALKBACK)
// -------------------------------------------------------------------------
function dapatkanLabelTarhim(filePath) {
  const f = String(filePath || "audio/tarhim.ogg");
  const temukan = DAFTAR_REKAMAN_TARHIM.find(it => it.file === f);
  return temukan ? temukan.label : "1. Tarhim Standar Masjid (tarhim.ogg)";
}


function dapatkanLabelAdzan(pathFile) {
  const f = DAFTAR_REKAMAN_ADZAN.find(it => it.file === pathFile);
  return f ? f.label : "Adzan Standar Masjid (adzan.ogg)";
}

function bukaPopupPilihAdzan(namaWaktuTarget = "Semua Waktu", keyCfgTarget = "semua", callbackSegarkan = null) {
  const lama = document.getElementById("modal-popup-adzan");
  if (lama) lama.remove();

  const overlay = document.createElement("div");
  overlay.id = "modal-popup-adzan";
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-label", `Pop-Up Pilihan 5 Audio Adzan untuk ${namaWaktuTarget}`);
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(6,32,24,0.88);z-index:2000;display:flex;align-items:center;justify-content:center;padding:10px;overflow-y:auto;";

  const box = document.createElement("div");
  box.id = "isi-dialog-popup-adzan";
  box.style.cssText = "width:100%;max-width:520px;background:#F0F5F2;border:3px solid #6EE7B7;border-radius:16px;padding:12px;box-shadow:0 12px 32px rgba(0,0,0,0.5);";

  const judulPop = document.createElement("h2");
  judulPop.id = "judul-popup-adzan";
  judulPop.setAttribute("tabindex", "0");
  judulPop.className = "section-label";
  judulPop.style.marginTop = "0";
  judulPop.textContent = `Pop-Up Pilih Audio Adzan: ${namaWaktuTarget}`;
  box.appendChild(judulPop);

  const nilaiSaatIni = (keyCfgTarget === "semua")
    ? (cfg.adzanDzuhurFile || "audio/adzan.ogg")
    : (cfg[keyCfgTarget] || "audio/adzan.ogg");

  DAFTAR_REKAMAN_ADZAN.forEach((op, idx) => {
    const aktif = (nilaiSaatIni === op.file);
    const wrapOp = document.createElement("div");
    wrapOp.style.cssText = "background:#FFFFFF;border:2px solid #81C784;border-radius:10px;padding:8px;margin:5px 0;";

    const btnPilih = document.createElement("button");
    btnPilih.type = "button";
    btnPilih.id = `btn-popup-pilih-adzan-${idx + 1}`;
    btnPilih.className = `btn ${aktif ? "btn-green" : "btn-teal"}`;
    const teksTombol = `${aktif ? "[ TERPILIH ] " : ""}Pilih ${op.label} untuk ${namaWaktuTarget}`;
    btnPilih.textContent = teksTombol;
    btnPilih.setAttribute("aria-label", teksTombol);
    btnPilih.addEventListener("click", () => {
      if (keyCfgTarget === "semua") {
        cfg.adzanSubuhFile = op.file;
        cfg.adzanDzuhurFile = op.file;
        cfg.adzanAsharFile = op.file;
        cfg.adzanMaghribFile = op.file;
        cfg.adzanIsyaFile = op.file;
      } else {
        cfg[keyCfgTarget] = op.file;
      }
      simpanData();
      bicaraGoogleTTS(`Alhamdulillah, ${op.label} berhasil dipilih untuk ${namaWaktuTarget}.`);
      overlay.remove();
      if (callbackSegarkan) callbackSegarkan();
    });
    wrapOp.appendChild(btnPilih);

    const btnDengar = document.createElement("button");
    btnDengar.type = "button";
    btnDengar.id = `btn-popup-dengar-adzan-${idx + 1}`;
    btnDengar.className = "btn btn-blue";
    btnDengar.textContent = `Uji Dengar Suara: ${op.label}`;
    btnDengar.setAttribute("aria-label", `Uji Dengar Suara ${op.label}`);
    btnDengar.addEventListener("click", () => {
      putarAudio("sistem", op.file);
    });
    wrapOp.appendChild(btnDengar);

    box.appendChild(wrapOp);
  });

  const btnStopPop = document.createElement("button");
  btnStopPop.type = "button";
  btnStopPop.className = "btn btn-orange";
  btnStopPop.textContent = "Hentikan Uji Dengar Suara Adzan";
  btnStopPop.addEventListener("click", () => {
    hentikanAudioDanSimpan();
    bicaraGoogleTTS("Uji dengar dihentikan.");
  });
  box.appendChild(btnStopPop);

  const btnTutup = document.createElement("button");
  btnTutup.type = "button";
  btnTutup.id = "btn-popup-adzan-tutup";
  btnTutup.className = "btn btn-red";
  btnTutup.textContent = "Tutup Jendela Pop-Up Pilihan Adzan";
  btnTutup.addEventListener("click", () => {
    hentikanAudioDanSimpan();
    overlay.remove();
    bicaraGoogleTTS("Jendela pop-up pemilihan adzan ditutup.");
  });
  box.appendChild(btnTutup);

  overlay.appendChild(box);
  document.body.appendChild(overlay);
  bicaraGoogleTTS(`Membuka jendela pop-up pemilihan lima audio adzan untuk ${namaWaktuTarget}. Silakan geser untuk memilih.`);
  setTimeout(() => judulPop.focus(), 60);
}

function bukaPopupPilihTarhim(namaWaktuTarget = "Semua Waktu", keyCfgTarget = "semua", callbackSegarkan = null) {
  const lama = document.getElementById("modal-popup-tarhim");
  if (lama) lama.remove();

  const overlay = document.createElement("div");
  overlay.id = "modal-popup-tarhim";
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-label", `Pop-Up Pilihan 3 Audio Tarhim untuk ${namaWaktuTarget}`);
  overlay.style.cssText = "position:fixed;inset:0;background:rgba(6,32,24,0.88);z-index:2000;display:flex;align-items:center;justify-content:center;padding:10px;overflow-y:auto;";

  const box = document.createElement("div");
  box.id = "isi-dialog-popup-tarhim";
  box.style.cssText = "width:100%;max-width:520px;background:#F0F5F2;border:3px solid #6EE7B7;border-radius:16px;padding:12px;box-shadow:0 12px 32px rgba(0,0,0,0.5);";

  const judulPop = document.createElement("h2");
  judulPop.id = "judul-popup-tarhim";
  judulPop.setAttribute("tabindex", "0");
  judulPop.className = "section-label";
  judulPop.style.marginTop = "0";
  judulPop.textContent = `Pop-Up Pilih Audio Tarhim: ${namaWaktuTarget}`;
  box.appendChild(judulPop);

  const nilaiSaatIni = (keyCfgTarget === "semua")
    ? (cfg.tarhimSubuhFile || "audio/tarhim.ogg")
    : (cfg[keyCfgTarget] || "audio/tarhim.ogg");

  const daftarOpsiTarhim = DAFTAR_REKAMAN_TARHIM;
  daftarOpsiTarhim.forEach((op, idx) => {
    const aktif = (nilaiSaatIni === op.file);
    const wrapOp = document.createElement("div");
    wrapOp.style.cssText = "background:#FFFFFF;border:2px solid #81C784;border-radius:10px;padding:8px;margin:5px 0;";

    const btnPilih = document.createElement("button");
    btnPilih.type = "button";
    btnPilih.id = `btn-popup-pilih-tarhim-${idx + 1}`;
    btnPilih.className = `btn ${aktif ? "btn-green" : "btn-teal"}`;
    const teksTombol = `${aktif ? "[ TERPILIH ] " : ""}Pilih ${op.label} untuk ${namaWaktuTarget}`;
    btnPilih.textContent = teksTombol;
    btnPilih.setAttribute("aria-label", teksTombol);
    btnPilih.addEventListener("click", () => {
      if (keyCfgTarget === "semua") {
        const fileSelainSubuh = op.file.includes("Arhamarrohimin") ? "audio/tarhim.ogg" : op.file;
        cfg.tarhimPilihanUtama = fileSelainSubuh;
        cfg.tarhimSubuhFile = op.file;
        cfg.tarhimDzuhurFile = fileSelainSubuh;
        cfg.tarhimAsharFile = fileSelainSubuh;
        cfg.tarhimMaghribFile = fileSelainSubuh;
        cfg.tarhimIsyaFile = fileSelainSubuh;
      } else {
        cfg[keyCfgTarget] = op.file;
      }
      simpanData();
      bicaraGoogleTTS(`Alhamdulillah, ${op.label} berhasil dipilih untuk ${namaWaktuTarget}.`);
      overlay.remove();
      if (callbackSegarkan) callbackSegarkan();
    });
    wrapOp.appendChild(btnPilih);

    const btnDengar = document.createElement("button");
    btnDengar.type = "button";
    btnDengar.id = `btn-popup-dengar-tarhim-${idx + 1}`;
    btnDengar.className = "btn btn-blue";
    btnDengar.textContent = `Uji Dengar Suara: ${op.label}`;
    btnDengar.setAttribute("aria-label", `Uji Dengar Suara ${op.label}`);
    btnDengar.addEventListener("click", () => {
      putarAudio("sistem", op.file);
    });
    wrapOp.appendChild(btnDengar);

    box.appendChild(wrapOp);
  });

  const btnStopPop = document.createElement("button");
  btnStopPop.type = "button";
  btnStopPop.id = "btn-popup-tarhim-stop";
  btnStopPop.className = "btn btn-orange";
  btnStopPop.textContent = "Hentikan Uji Dengar Suara Tarhim";
  btnStopPop.addEventListener("click", () => {
    hentikanAudioDanSimpan();
    bicaraGoogleTTS("Uji dengar dihentikan.");
  });
  box.appendChild(btnStopPop);

  const btnTutup = document.createElement("button");
  btnTutup.type = "button";
  btnTutup.id = "btn-popup-tarhim-tutup";
  btnTutup.className = "btn btn-red";
  btnTutup.textContent = "Tutup Jendela Pop-Up Pilihan Tarhim";
  btnTutup.addEventListener("click", () => {
    hentikanAudioDanSimpan();
    overlay.remove();
    bicaraGoogleTTS("Jendela pop-up pemilihan tarhim ditutup.");
  });
  box.appendChild(btnTutup);

  overlay.appendChild(box);
  document.body.appendChild(overlay);
  bicaraGoogleTTS(`Membuka jendela pop-up pemilihan tiga audio tarhim untuk ${namaWaktuTarget}. Silakan geser untuk memilih.`);
  setTimeout(() => judulPop.focus(), 60);
}

// -------------------------------------------------------------------------
// MENU 1: SAKELAR & PILIHAN REKAMAN ADZAN, TARHIM, ASMAUL HUSNA & BEL
// -------------------------------------------------------------------------
function menuPengaturanAdzan() {
  const root = bersihkanLayar();
  tambahHeader(root, "Sakelar & Rekaman Adzan, Tarhim & Bel", "Atur Sakelar Aktif dan Pilih Rekaman dari 23 Audio Masjid");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  tambahLabelBagian(root, "1. Sakelar Kumandang Adzan 5 Waktu");
  tambahSakelarAksesibel(root, "Kumandang Adzan Subuh", "adzan_subuh_on");
  tambahSakelarAksesibel(root, "Kumandang Adzan Dzuhur", "adzan_dzuhur_on");
  tambahSakelarAksesibel(root, "Kumandang Adzan Ashar", "adzan_ashar_on");
  tambahSakelarAksesibel(root, "Kumandang Adzan Maghrib", "adzan_maghrib_on");
  tambahSakelarAksesibel(root, "Kumandang Adzan Isya", "adzan_isya_on");

  tambahLabelBagian(root, "2. Sakelar Tarhim, Asmaul Husna & Bel Masjid");
  tambahSakelarAksesibel(root, "Lantunan Tarhim Subuh", "tarhim_subuh_on");
  tambahSakelarAksesibel(root, "Lantunan Tarhim Dzuhur", "tarhim_dzuhur_on");
  tambahSakelarAksesibel(root, "Lantunan Tarhim Ashar", "tarhim_ashar_on");
  tambahSakelarAksesibel(root, "Lantunan Tarhim Maghrib", "tarhim_maghrib_on");
  tambahSakelarAksesibel(root, "Lantunan Tarhim Isya", "tarhim_isya_on");
  tambahSakelarAksesibel(root, "Lantunan Ya Arhamarrohimin Pra-Murottal (Khusus Subuh)", "s_arham");
  tambahSakelarAksesibel(root, "Lantunan Asmaul Husna Pra-Tarhim (Selain Subuh)", "s_asmaul");
  tambahSakelarAksesibel(root, "Dentang Bel Pendek Penanda Waktu (bel_pendek.mp3)", "s_bel");

  tambahTombol(root, "Pilih & Pasang File Audio Asmaul Husna (MP3/OGG) dari Memori HP", "btn-blue", () => {
    const picker = document.getElementById("audio-file-picker");
    picker.onchange = function(e) {
      if (e.target.files && e.target.files.length > 0) {
        const fileTerpilih = e.target.files[0];
        simpanFileAudioKeDB(e.target.files, () => {
          cfg.asmaulFile = fileTerpilih.name;
          cfg.s_asmaul = true;
          simpanData();
          bicaraGoogleTTS(`Alhamdulillah, berkas ${fileTerpilih.name} berhasil dipasang sebagai audio Asmaul Husna dan sakelar Asmaul Husna telah diaktifkan.`);
          menuPengaturanAdzan();
        });
      }
    };
    picker.click();
  }, "btn-pasang-audio-asmaul-husna");

  tambahLabelBagian(root, "3. Pilih Rekaman Suara Adzan & Tarhim (23 Audio Tertanam)");

  function buatPemilihRekaman(idSelect, labelJudul, keyCfg, daftarOpsi) {
    const grp = document.createElement("div");
    grp.className = "form-group";
    const lbl = document.createElement("label");
    lbl.setAttribute("for", idSelect);
    lbl.textContent = labelJudul;
    grp.appendChild(lbl);

    const sel = document.createElement("select");
    sel.id = idSelect;
    daftarOpsi.forEach(op => {
      const opt = document.createElement("option");
      opt.value = op.file;
      opt.textContent = op.label;
      if (cfg[keyCfg] === op.file) opt.selected = true;
      sel.appendChild(opt);
    });
    sel.addEventListener("change", () => {
      cfg[keyCfg] = sel.value;
      simpanData();
      const teksTerpilih = sel.options[sel.selectedIndex].text;
      bicaraGoogleTTS(`${labelJudul} diatur ke ${teksTerpilih}`);
    });
    grp.appendChild(sel);

    const btnTes = document.createElement("button");
    btnTes.type = "button";
    btnTes.id = `btn-uji-${idSelect}`;
    btnTes.className = "btn btn-teal";
    btnTes.style.marginTop = "10px";
    btnTes.textContent = `Uji Putar ${labelJudul}`;
    btnTes.addEventListener("click", () => {
      putarAudio("sistem", sel.value || daftarOpsi[1].file);
    });
    grp.appendChild(btnTes);

    root.appendChild(grp);
  }

  tambahTombol(root, `Pilih Adzan Serentak 5 Waktu (Pop-Up 5 Audio) — Saat Ini: ${dapatkanLabelAdzan(cfg.adzanDzuhurFile)}`, "btn-purple", () => {
    bukaPopupPilihAdzan("Semua 5 Waktu Salat", "semua", menuPengaturanAdzan);
  }, "btn-popup-adzan-semua");

  const daftarWaktuAdzan = [
    ["Subuh (Tersedia 2 Versi Subuh & Pilihan Lainnya)", "adzanSubuhFile"],
    ["Dzuhur", "adzanDzuhurFile"],
    ["Ashar", "adzanAsharFile"],
    ["Maghrib", "adzanMaghribFile"],
    ["Isya", "adzanIsyaFile"]
  ];
  daftarWaktuAdzan.forEach(([namaW, keyA]) => {
    tambahTombol(root, `Pilih Adzan ${namaW} (Buka Pop-Up) — Aktif: ${dapatkanLabelAdzan(cfg[keyA])}`, "btn-teal", () => {
      bukaPopupPilihAdzan(`Waktu ${namaW}`, keyA, menuPengaturanAdzan);
    }, `btn-popup-adzan-${keyA}`);
  });

  buatPemilihRekaman("sel-adzan-subuh", "Rekaman Adzan Subuh", "adzanSubuhFile", DAFTAR_REKAMAN_ADZAN);
  buatPemilihRekaman("sel-adzan-dzuhur", "Rekaman Adzan Dzuhur", "adzanDzuhurFile", DAFTAR_REKAMAN_ADZAN);
  buatPemilihRekaman("sel-adzan-ashar", "Rekaman Adzan Ashar", "adzanAsharFile", DAFTAR_REKAMAN_ADZAN);
  buatPemilihRekaman("sel-adzan-maghrib", "Rekaman Adzan Maghrib", "adzanMaghribFile", DAFTAR_REKAMAN_ADZAN);
  buatPemilihRekaman("sel-adzan-isya", "Rekaman Adzan Isya", "adzanIsyaFile", DAFTAR_REKAMAN_ADZAN);

  tambahLabelBagian(root, "4. Pemilihan 3 Audio Tarhim (Tombol Pop-Up Sesuai Pilihan Pengguna)", "judul-bagian-popup-tarhim");

  tambahTombol(root, `Pilih Tarhim Serentak 5 Waktu (Pop-Up 3 Audio) — Saat Ini: ${dapatkanLabelTarhim(cfg.tarhimSubuhFile)}`, "btn-purple", () => {
    bukaPopupPilihTarhim("Semua 5 Waktu Salat", "semua", menuPengaturanAdzan);
  }, "btn-popup-tarhim-semua");

  const daftarWaktuTarhim = [
    ["Subuh", "tarhimSubuhFile"],
    ["Dzuhur", "tarhimDzuhurFile"],
    ["Ashar", "tarhimAsharFile"],
    ["Maghrib", "tarhimMaghribFile"],
    ["Isya", "tarhimIsyaFile"]
  ];
  daftarWaktuTarhim.forEach(([namaW, keyT]) => {
    tambahTombol(root, `Pilih Tarhim ${namaW} (Buka Pop-Up) — Aktif: ${dapatkanLabelTarhim(cfg[keyT])}`, "btn-teal", () => {
      bukaPopupPilihTarhim(`Waktu ${namaW}`, keyT, menuPengaturanAdzan);
    }, `btn-popup-tarhim-${namaW.toLowerCase()}`);
  });

  tambahLabelBagian(root, "5. Pengaturan Rekaman Doa Habis Adzan & Surah Yasin Malam Jumat", "judul-bagian-doa-dan-yasin");
  tambahSakelarAksesibel(root, "Putar Otomatis Surah Yasin Setiap Malam Jumat (Maghrib & Isya)", "s_yasin_malam_jumat", "btn-sakelar-yasin-malam-jumat");

  tambahTombol(root, `Pilih & Pasang File Audio Doa Habis Adzan dari HP (Saat Ini: ${cfg.doaAdzanFile || "Suara Doa Bawaan Aplikasi"})`, "btn-blue", () => {
    const picker = document.getElementById("audio-file-picker");
    picker.onchange = function(e) {
      if (e.target.files && e.target.files.length > 0) {
        const fileTerpilih = e.target.files[0];
        simpanFileAudioKeDB(e.target.files, () => {
          cfg.doaAdzanFile = fileTerpilih.name;
          cfg.s_doa_adzan = true;
          simpanData();
          bicaraGoogleTTS(`Alhamdulillah, berkas ${fileTerpilih.name} berhasil dipasang sebagai rekaman Doa Habis Adzan.`);
          menuPengaturanAdzan();
        });
      }
    };
    picker.click();
  }, "btn-pasang-audio-doa-adzan");

  tambahTombol(root, "Hentikan Uji Putar Suara", "btn-red", () => {
    hentikanAudioDanSimpan();
    bicaraGoogleTTS("Uji putar dihentikan.");
  });
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 2: PENGATURAN DURASI (UPDATE IN-PLACE TANPA KEHILANGAN FOKUS!)
// -------------------------------------------------------------------------
function menuPengaturanDurasi() {
  const root = bersihkanLayar();
  tambahHeader(root, "Atur Durasi Murottal, Tarhim & Iqomah", "Pilih Angka Menit Durasi Siaran Pra-Adzan & Iqomah");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  function renderGrupDurasi(judul, keyVar, arrPilihan) {
    const h2 = tambahLabelBagian(root, "");
    const daftarBtn = [];

    function segarkanGrup() {
      const nilaiSkrg = Number(cfg[keyVar]) || 0;
      h2.textContent = `${judul} (Saat Ini: ${nilaiSkrg === 0 ? "Nonaktif / OFF" : nilaiSkrg + " Menit"})`;
      daftarBtn.forEach(({ btn, v }) => {
        const aktif = (nilaiSkrg === v);
        btn.className = `btn ${aktif ? "btn-green" : "btn-gray"}`;
        btn.setAttribute("aria-pressed", aktif ? "true" : "false");
        btn.textContent = `${aktif ? "[ TERPILIH ] " : ""}${v === 0 ? "Matikan (OFF)" : v + " Menit"} — ${judul}`;
      });
    }

    arrPilihan.forEach(v => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.id = `btn-durasi-${keyVar}-${v}`;
      btn.addEventListener("click", () => {
        cfg[keyVar] = v;
        simpanData();
        segarkanGrup();
        bicaraGoogleTTS(`${judul} diatur ke ${v === 0 ? "nonaktif" : v + " menit"}.`);
      });
      root.appendChild(btn);
      daftarBtn.push({ btn, v });
    });

    segarkanGrup();
  }

  renderGrupDurasi("1. Durasi Murottal Sebelum Adzan", "waktuMurottal", [10, 15, 20, 30, 45, 60]);
  renderGrupDurasi("2. Durasi Tarhim Sebelum Adzan", "waktuTarhim", [5, 6, 7, 8, 10, 15, 20]);
  renderGrupDurasi("3. Durasi Asmaul Husna Pra-Tarhim (Selain Subuh)", "waktuAsmaul", [0, 4, 5, 6, 7, 10, 15, 20]);
  renderGrupDurasi("4. Durasi Ya Arhamarrohimin (Pra-Murottal Subuh)", "waktuArham", [0, 5, 6, 7, 10, 15, 20]);
  renderGrupDurasi("5. Waktu Tunggu Iqomah Setelah Adzan", "waktuIqomah", [5, 7, 10, 12, 15, 20]);
  renderGrupDurasi("6. Durasi Mode Hening / Khusyuk Saat Salat", "durasiKhusyuk", [20, 30, 40, 60]);
  renderGrupDurasi("7. Jeda Laporan Asisten Marbot Sebelum 5 Waktu Salat", "menitLaporan5Waktu", [10, 15, 20, 25, 30]);

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 3: SAKELAR SUNNAH & LAPORAN 3 WAKTU PILIHAN (UPDATE IN-PLACE!)
// -------------------------------------------------------------------------
function menuSakelarSunnah() {
  const root = bersihkanLayar();
  tambahHeader(root, "Sakelar Laporan 5 Waktu Salat & Ibadah Penting", "Atur Pengingat Waktu Istiwa, Jumat, Tahajud, Imsak, Syuruq, Dhuha & Puasa");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  tambahLabelBagian(root, "1. Laporan 5 Waktu Salat & Waktu Penting Ibadah");
  tambahSakelarAksesibel(root, "Laporan 5 Waktu Salat & Waktu Penting Ibadah (Tahajud, Imsak, Pagi, Dhuha, Istiwa & Jumat)", "s_jam", "btn-sakelar-laporan-5waktu");
  tambahSakelarAksesibel(root, "Peringatan Waktu Istiwa / Zawal (Larangan Salat Menjelang Dzuhur)", "s_istiwa", "btn-sakelar-waktu-istiwa");
  tambahSakelarAksesibel(root, "Putar Otomatis Surah Yasin Setiap Malam Jumat (Maghrib & Isya)", "s_yasin_malam_jumat", "btn-sakelar-yasin-sunnah");
  tambahSakelarAksesibel(root, "Protokol Khusus Hari Jumat & Surah Al-Jumu'ah", "s_jumat", "btn-sakelar-jumat");

  tambahLabelBagian(root, "2. Sakelar Pengingat Ibadah Harian");
  tambahSakelarAksesibel(root, "Pengingat Sepertiga Malam / Salat Tahajud (02:30)", "s_tahajud");
  tambahSakelarAksesibel(root, "Pengingat Waktu Imsak (10 Menit Sebelum Subuh)", "s_imsak");
  tambahSakelarAksesibel(root, "Peringatan 10 Menit Menjelang Matahari Terbit", "s_preterbit");
  tambahSakelarAksesibel(root, "Penanda Waktu Matahari Terbit / Syuruq", "s_terbit");
  tambahSakelarAksesibel(root, "Pengingat Waktu Salat Sunnah Dhuha", "s_dhuha");
  tambahSakelarAksesibel(root, "Pengingat Salat Sunnah Rawatib Bakda Adzan", "s_rawatib");
  tambahSakelarAksesibel(root, "Pengingat Puasa Sunnah (Senin-Kamis & Ayyamul Bidh)", "s_puasa");
  tambahSakelarAksesibel(root, "Variasi Kalimat Hikmah & Dakwah Asisten Suara", "ttsVarian");
  tambahSakelarAksesibel(root, "Mode Hening Khusyuk Saat Waktu Salat", "s_khusyuk");
  tambahSakelarAksesibel(root, "Mode Musafir (Pengingat Rukhsoh Jamak & Qashar)", "s_musafir");

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

function menuPengaturanAudioMedia() {
  const root = bersihkanLayar();
  tambahHeader(root, "Volume Suara, Mode Murottal & Suara Asisten", "Atur Volume, Mode Murottal, Tambahan Audio & Kecepatan Bicara");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  tambahLabelBagian(root, "1. Pola Pemutaran Lantunan Murottal");
  const btnIkatan = document.createElement("button");
  const btnSambung = document.createElement("button");
  btnIkatan.type = "button";
  btnSambung.type = "button";
  btnIkatan.id = "btn-mode-murottal-ikatan";
  btnSambung.id = "btn-mode-murottal-sambung";
  function segarkanModeMurottal() {
    const isIkatan = (cfg.modeMurottal === "ikatan");
    btnIkatan.className = `btn ${isIkatan ? "btn-green" : "btn-gray"}`;
    btnSambung.className = `btn ${!isIkatan ? "btn-green" : "btn-gray"}`;
    btnIkatan.textContent = `${isIkatan ? "[ TERPILIH ] " : ""}Sesuai Jadwal Waktu Salat (Mode Ikatan)`;
    btnSambung.textContent = `${!isIkatan ? "[ TERPILIH ] " : ""}Lanjutkan dari Menit Terakhir (Mode Sambung)`;
  }
  btnIkatan.onclick = () => { cfg.modeMurottal = "ikatan"; simpanData(); segarkanModeMurottal(); bicaraGoogleTTS("Mode Murottal diatur ke Ikatan Waktu."); };
  btnSambung.onclick = () => { cfg.modeMurottal = "sambung"; simpanData(); segarkanModeMurottal(); bicaraGoogleTTS("Mode Murottal diatur ke Sambung Posisi Terakhir."); };
  segarkanModeMurottal();
  root.appendChild(btnIkatan);
  root.appendChild(btnSambung);

  const lblVolAdzan = tambahLabelBagian(root, `2. Tingkat Volume Kumandang Adzan: ${cfg.volAdzan}%`);
  tambahTombol(root, "Kecilkan Volume Adzan (-10%)", "btn-orange", () => {
    cfg.volAdzan = Math.max(10, cfg.volAdzan - 10);
    simpanData();
    lblVolAdzan.textContent = `2. Tingkat Volume Kumandang Adzan: ${cfg.volAdzan}%`;
    bicaraGoogleTTS(`Volume adzan ${cfg.volAdzan} persen`);
  });
  tambahTombol(root, "Besarkan Volume Adzan (+10%)", "btn-green", () => {
    cfg.volAdzan = Math.min(100, cfg.volAdzan + 10);
    simpanData();
    lblVolAdzan.textContent = `2. Tingkat Volume Kumandang Adzan: ${cfg.volAdzan}%`;
    bicaraGoogleTTS(`Volume adzan ${cfg.volAdzan} persen`);
  });

  const lblVolMur = tambahLabelBagian(root, `3. Tingkat Volume Murottal & Tarhim: ${cfg.volMurottal}%`);
  tambahTombol(root, "Kecilkan Volume Murottal (-10%)", "btn-orange", () => {
    cfg.volMurottal = Math.max(10, cfg.volMurottal - 10);
    simpanData();
    lblVolMur.textContent = `3. Tingkat Volume Murottal & Tarhim: ${cfg.volMurottal}%`;
    bicaraGoogleTTS(`Volume murottal ${cfg.volMurottal} persen`);
  });
  tambahTombol(root, "Besarkan Volume Murottal (+10%)", "btn-green", () => {
    cfg.volMurottal = Math.min(100, cfg.volMurottal + 10);
    simpanData();
    lblVolMur.textContent = `3. Tingkat Volume Murottal & Tarhim: ${cfg.volMurottal}%`;
    bicaraGoogleTTS(`Volume murottal ${cfg.volMurottal} persen`);
  });

  const lblTts = tambahLabelBagian(root, `4. Kecepatan & Nada Suara Asisten (Kecepatan: ${Number(cfg.ttsSpeed || 1.0).toFixed(1)}x | Nada: ${Number(cfg.ttsPitch || 1.0).toFixed(1)}x)`);
  tambahTombol(root, "Perlambat Kecepatan Bicara (-0.1x)", "btn-orange", () => {
    cfg.ttsSpeed = Math.max(0.5, Number((cfg.ttsSpeed - 0.1).toFixed(1)));
    simpanData();
    lblTts.textContent = `4. Kecepatan & Nada Suara Asisten (Kecepatan: ${cfg.ttsSpeed.toFixed(1)}x | Nada: ${Number(cfg.ttsPitch || 1.0).toFixed(1)}x)`;
    bicaraGoogleTTS(`Kecepatan bicara ${cfg.ttsSpeed.toFixed(1)} kali.`);
  });
  tambahTombol(root, "Reset Kecepatan & Nada Standar (1.0x)", "btn-dark", () => {
    cfg.ttsSpeed = 1.0; cfg.ttsPitch = 1.0;
    simpanData();
    lblTts.textContent = "4. Kecepatan & Nada Suara Asisten (Kecepatan: 1.0x | Nada: 1.0x)";
    bicaraGoogleTTS("Kecepatan dan nada suara dikembalikan ke standar.");
  });
  tambahTombol(root, "Percepat Kecepatan Bicara (+0.1x)", "btn-green", () => {
    cfg.ttsSpeed = Math.min(2.0, Number((cfg.ttsSpeed + 0.1).toFixed(1)));
    simpanData();
    lblTts.textContent = `4. Kecepatan & Nada Suara Asisten (Kecepatan: ${cfg.ttsSpeed.toFixed(1)}x | Nada: ${Number(cfg.ttsPitch || 1.0).toFixed(1)}x)`;
    bicaraGoogleTTS(`Kecepatan bicara ${cfg.ttsSpeed.toFixed(1)} kali.`);
  });

  tambahLabelBagian(root, "5. Tambahkan Berkas Audio Ekstra dari Memori HP (Opsional)");
  tambahTombol(root, "Pilih Berkas Audio MP3/OGG Tambahan dari HP", "btn-blue", () => {
    const picker = document.getElementById("audio-file-picker");
    picker.onchange = function(e) {
      if (e.target.files && e.target.files.length > 0) {
        simpanFileAudioKeDB(e.target.files, (jml) => {
          bicaraGoogleTTS(`Alhamdulillah, ${jml} berkas audio tambahan berhasil disimpan.`);
        });
      }
    };
    picker.click();
  });

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 5: ATUR WILAYAH, 17 KECAMATAN & 136 DESA SITUBONDO, PENCARIAN & KOREKSI
// -------------------------------------------------------------------------
function deteksiProvinsiDariKota(namaKota) {
  const kClean = String(namaKota || "").trim().toLowerCase();
  for (const [prov, listK] of Object.entries(K_DATA)) {
    for (const kItem of listK) {
      if (kItem.toLowerCase() === kClean || kItem.toLowerCase().replace(/^kota\s+/i, "") === kClean.replace(/^kota\s+|^kab\.\s*/i, "")) {
        return { prov, kotaResmi: kItem };
      }
    }
  }
  return null;
}

function terapkanWilayahKoordinat(namaKecamatan, lat, lon, labelLengkap, provPilihan = "", kotaPilihan = "", kecPilihan = "", desaPilihan = "") {
  if (provPilihan) cfg.provinsiTerpilih = provPilihan;
  if (kotaPilihan) {
    cfg.kota = kotaPilihan;
    cfg.kotaTerpilih = kotaPilihan;
  } else if (cfg.kota) {
    const det = deteksiProvinsiDariKota(cfg.kota);
    if (det) {
      cfg.provinsiTerpilih = det.prov;
      cfg.kotaTerpilih = det.kotaResmi;
    }
  }
  if (kecPilihan) cfg.kecamatanTerpilih = kecPilihan;
  if (desaPilihan) cfg.desaTerpilih = desaPilihan;

  cfg.kecamatan = namaKecamatan;
  cfg.lokasiDitemukan = labelLengkap;
  if (!cfg.kota || String(cfg.kota).toLowerCase().includes("belum diatur")) {
    cfg.kota = kotaPilihan || namaKecamatan || labelLengkap || "Wilayah Aktif";
  }
  cfg.latitude = Number(lat) || -7.7062;
  cfg.longitude = Number(lon) || 114.0095;
  cfg.sudutKiblat = hitungSudutKiblat(cfg.latitude, cfg.longitude);
  cfg.master_aktif = true;
  const semuaMati = !cfg.adzan_subuh_on && !cfg.adzan_dzuhur_on && !cfg.tarhim_subuh_on && !cfg.tarhim_dzuhur_on;
  if (semuaMati) {
    aktifkanCepatStandarMasjid();
  }
  cfg.jadwalSebulan = hitungJadwalKemenagBulanan(cfg.latitude, cfg.longitude);
  simpanData();
  tarikCuacaDanGempa();
  ambilTanggalHijriyah(0);
  bicaraGoogleTTS(`Mencari jadwal waktu nyata Kemenag untuk ${labelLengkap}.`);
  const jalankanSinkronUtama = () => {
    sinkronisasiJadwalV3Cerdas(kotaPilihan || cfg.kota || namaKecamatan, (sukses, lokasiResmi) => {
      if (!sukses && (!cfg.jadwalSebulan || !cfg.jadwalSebulan[dapatkanTanggalISO(0)])) {
        cfg.jadwalSebulan = hitungJadwalKemenagBulanan(cfg.latitude, cfg.longitude);
      }
      simpanData();
      if (sukses) {
        bicaraGoogleTTS(`Alhamdulillah, jadwal waktu nyata resmi Kemenag untuk ${labelLengkap} berhasil disimpan.`);
      } else {
        bicaraGoogleTTS(`Wilayah diatur ke ${labelLengkap}.`);
      }
      tampilkanMenuUtama();
    }, false);
  };

  if (desaPilihan && kecPilihan) {
    const desaBersih = String(desaPilihan).replace(/^(Desa|Kelurahan|Kecamatan)\s+/i, "").trim();
    getAPI(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(desaBersih + " " + kecPilihan)}&count=5&language=id&countryCode=ID`, function(sG, resG) {
      if (sG && resG) {
        try {
          const dG = JSON.parse(resG);
          if (dG && Array.isArray(dG.results) && dG.results.length > 0) {
            const kKab = ekstrakNamaKotaKemenag(kotaPilihan || cfg.kota).toLowerCase();
            const cocokDesa = dG.results.find(it => (it.admin2 || "").toLowerCase().includes(kKab) || (it.admin3 || "").toLowerCase().includes(kecPilihan.toLowerCase())) || dG.results[0];
            if (cocokDesa && cocokDesa.latitude && cocokDesa.longitude) {
              cfg.latitude = Number(cocokDesa.latitude);
              cfg.longitude = Number(cocokDesa.longitude);
              cfg.sudutKiblat = hitungSudutKiblat(cfg.latitude, cfg.longitude);
            }
          }
        } catch (eG) {}
      }
      jalankanSinkronUtama();
    });
    return;
  }
  jalankanSinkronUtama();
  if (false) sinkronisasiJadwalV3Cerdas(kotaPilihan || cfg.kota || namaKecamatan, (sukses, lokasiResmi) => {
    if (!sukses && (!cfg.jadwalSebulan || !cfg.jadwalSebulan[dapatkanTanggalISO(0)])) {
      cfg.jadwalSebulan = hitungJadwalKemenagBulanan(cfg.latitude, cfg.longitude);
    }
    simpanData();
    if (sukses) {
      bicaraGoogleTTS(`Alhamdulillah, jadwal waktu nyata resmi Kemenag untuk ${labelLengkap} berhasil disimpan.`);
    } else {
      bicaraGoogleTTS(`Wilayah diatur ke ${labelLengkap}.`);
    }
    tampilkanMenuUtama();
  }, false);
}

window.onNativeGPSResult = function(lat, lon, labelGeo) {
  if (!lat && !lon) {
    bicaraGoogleTTS("Lokasi GPS belum terkunci. Pastikan GPS aktif atau pilih langsung dari daftar kecamatan di atas.");
    return;
  }
  const lbl = labelGeo || `Lokasi GPS (${Number(lat).toFixed(4)}, ${Number(lon).toFixed(4)})`;
  terapkanWilayahKoordinat(lbl, lat, lon, lbl);
};

function menuPengaturanLokasi() {
  const root = bersihkanLayar();
  tambahHeader(root, "Atur Wilayah, Kecamatan & Desa", "Pilih dari Daftar Lengkap, Ketik Nama Wilayah, atau Deteksi GPS");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  const infoAktif = document.createElement("div");
  infoAktif.className = "summary-item";
  infoAktif.setAttribute("tabindex", "0");
  infoAktif.textContent = `Wilayah Aktif Saat Ini: ${cfg.lokasiDitemukan || cfg.kota} (Koordinat: ${Number(cfg.latitude || 0).toFixed(4)}, ${Number(cfg.longitude || 0).toFixed(4)} • Kiblat ${cfg.sudutKiblat || 294}°)`;
  root.appendChild(infoAktif);

  // BAGIAN 1: SPINNER PROVINSI -> KABUPATEN/KOTA -> 17 KECAMATAN -> 136 DESA
  tambahLabelBagian(root, "1. Pilih Wilayah dari Daftar (Provinsi, Kota, Kecamatan & Desa)");

  const formWrap = document.createElement("div");
  formWrap.innerHTML = `
    <div class="form-group">
      <label id="lbl-sp-prov" for="sp-prov">Pilih Provinsi:</label>
      <select id="sp-prov"></select>
    </div>
    <div class="form-group">
      <label id="lbl-sp-kota" for="sp-kota">Pilih Kabupaten / Kota:</label>
      <select id="sp-kota"></select>
    </div>
    <div class="form-group">
      <label id="lbl-sp-kec" for="sp-kec">Pilih Kecamatan:</label>
      <select id="sp-kec"></select>
    </div>
    <div class="form-group">
      <label id="lbl-sp-desa" for="sp-desa">Pilih Desa / Kelurahan / Wilayah Kecamatan:</label>
      <select id="sp-desa"></select>
    </div>
  `;
  root.appendChild(formWrap);

  const spProv = document.getElementById("sp-prov");
  const spKota = document.getElementById("sp-kota");
  const spKec = document.getElementById("sp-kec");
  const spDesa = document.getElementById("sp-desa");

  P_LIST.forEach(p => {
    const opt = document.createElement("option");
    opt.value = p;
    opt.textContent = p;
    spProv.appendChild(opt);
  });

  let cacheKoordinatKecamatan = {};

  function isiDesa(kota, kec, desaTarget = "") {
    spDesa.innerHTML = "";
    const lblDesaEl = document.getElementById("lbl-sp-desa");
    const dbLengkap = dapatkanDataLengkapKabKota(kota);
    const listDesa = (dbLengkap && dbLengkap[kec])
      ? dbLengkap[kec].desa
      : [`Kecamatan ${kec} (${kota})`];
    if (!dbLengkap) {
      muatDesaAsliKemendagri(kota, kec, spDesa, lblDesaEl, desaTarget);
    }
    if (lblDesaEl) lblDesaEl.textContent = `Pilih Desa / Kelurahan di Kecamatan ${kec}, ${kota} (${listDesa.length} Desa/Kelurahan):`;
    listDesa.forEach(d => {
      const opt = document.createElement("option");
      opt.value = d;
      opt.textContent = d;
      if (desaTarget && d === desaTarget) opt.selected = true;
      spDesa.appendChild(opt);
    });

    if (kota !== "Situbondo") {
      fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(kec)}&count=5&language=id&countryCode=ID`)
        .then(r => r.json())
        .then(d => {
          if (d && d.results && d.results.length > 0) {
            const match = d.results.find(it => (it.admin2 || "").toLowerCase().includes(kota.toLowerCase().replace(/^kota\s+/i, ""))) || d.results[0];
            cacheKoordinatKecamatan[`${kota}_${kec}`] = { lat: match.latitude, lon: match.longitude };
          }
        })
        .catch(() => {});
    }
  }

  function isiKecamatan(kota, kecTarget = "", desaTarget = "") {
    spKec.innerHTML = "";
    const listKec = dapatkanDaftarKecamatanKota(kota);
    const lblKecEl = document.getElementById("lbl-sp-kec");
    if (lblKecEl) lblKecEl.textContent = `Pilih Kecamatan di ${kota} (${listKec.length} Kecamatan):`;
    let kecTerpilih = listKec[0];
    listKec.forEach(k => {
      const opt = document.createElement("option");
      opt.value = k;
      opt.textContent = `Kecamatan ${k}`;
      if (kecTarget && k === kecTarget) {
        opt.selected = true;
        kecTerpilih = k;
      }
      spKec.appendChild(opt);
    });
    isiDesa(kota, kecTerpilih, desaTarget);
    muatKecamatanAsliKemendagri(spProv.value, kota, spKec, lblKecEl, kecTarget, () => {
      if (spKec.value) isiDesa(kota, spKec.value, desaTarget);
    });
  }

  function isiKota(prov, kotaTarget = "", kecTarget = "", desaTarget = "") {
    spKota.innerHTML = "";
    const listKota = K_DATA[prov] || K_DATA[P_LIST[0]];
    let kotaTerpilih = listKota[0];
    listKota.forEach(k => {
      const opt = document.createElement("option");
      opt.value = k;
      opt.textContent = k;
      if (kotaTarget && k.toLowerCase() === kotaTarget.toLowerCase()) {
        opt.selected = true;
        kotaTerpilih = k;
      }
      spKota.appendChild(opt);
    });
    isiKecamatan(kotaTerpilih, kecTarget, desaTarget);
  }

  // PENTING: Kunci Spinner pada Provinsi, Kota, Kecamatan & Desa yang terakhir dipilih pengguna (Jangan kembali ke Situbondo!)
  const provAwal = (cfg.provinsiTerpilih && P_LIST.includes(cfg.provinsiTerpilih)) ? cfg.provinsiTerpilih : P_LIST[0];
  spProv.value = provAwal;
  isiKota(provAwal, cfg.kotaTerpilih || cfg.kota, cfg.kecamatanTerpilih || "", cfg.desaTerpilih || "");

  spProv.onchange = () => {
    isiKota(spProv.value);
    bicaraGoogleTTS(`Provinsi ${spProv.value} dipilih. Silakan pilih Kabupaten atau Kota.`);
  };
  spKota.onchange = () => {
    isiKecamatan(spKota.value);
    const jmlKec = spKec.options.length;
    bicaraGoogleTTS(`${spKota.value} dipilih. Tersedia ${jmlKec} kecamatan aktif.`);
  };
  spKec.onchange = () => {
    isiDesa(spKota.value, spKec.value);
    bicaraGoogleTTS(`Kecamatan ${spKec.value}, ${spKota.value} dipilih.`);
  };

  tambahTombol(root, "Simpan & Aktifkan Wilayah (Provinsi, Kota, Kecamatan & Desa) di Atas", "btn-green", () => {
    const prov = spProv.value;
    const kota = spKota.value;
    const kec = spKec.value;
    const desa = spDesa.value;
    const idxKec = Math.max(0, spKec.selectedIndex);

    const dbLengkap = dapatkanDataLengkapKabKota(kota);
    if (dbLengkap && dbLengkap[kec]) {
      const info = dbLengkap[kec];
      const labelFull = `${desa}, Kec. ${kec}, Kab. ${kota}, ${prov}`;
      terapkanWilayahKoordinat(`${desa}, Kec. ${kec}`, info.lat, info.lon, labelFull, prov, kota, kec, desa);
    } else {
      const koorOnline = cacheKoordinatKecamatan[`${kota}_${kec}`];
      const koorAktif = koorOnline || dapatkanKoordinatKecamatanAktif(kota, kec);
      const labelFull = `${desa}, Kec. ${kec}, ${kota}, ${prov}`;
      terapkanWilayahKoordinat(`${desa}, Kec. ${kec}`, koorAktif.lat, koorAktif.lon, labelFull, prov, kota, kec, desa);
    }
  }, "btn-simpan-wilayah-spinner");

  // BAGIAN 2: PENCARIAN KETIK LANGSUNG & TOMBOL CEPAT 17 KECAMATAN SITUBONDO (DEKAT DENGAN SPINNER!)
  tambahLabelBagian(root, "2. Atau Ketik Nama Kota, Kabupaten, Kecamatan atau Desa");
  const searchWrap = document.createElement("div");
  searchWrap.className = "form-group";
  searchWrap.innerHTML = `
    <label for="input-cari-wilayah">Ketik Nama Wilayah (Kota, Kecamatan, atau Desa):</label>
    <input type="text" id="input-cari-wilayah" placeholder="Contoh: Situbondo, Panji, Besuki, Dawuhan, Surabaya" value="" />
  `;
  root.appendChild(searchWrap);

  const wadahHasil = document.createElement("div");
  wadahHasil.setAttribute("role", "region");
  wadahHasil.setAttribute("aria-label", "Hasil Pencarian Wilayah");
  root.appendChild(wadahHasil);

  function renderDaftar17KecamatanSitubondo() {
    wadahHasil.innerHTML = "";
    bicaraGoogleTTS("Menampilkan 17 kecamatan di Kabupaten Situbondo. Silakan pilih kecamatan untuk membuka daftar desa.");
    KEC_SITUBONDO_URUT.forEach((namaKec, idxK) => {
      const dKec = DATA_SITUBONDO_LENGKAP[namaKec];
      tambahTombol(wadahHasil, `${idxK + 1}. Kecamatan ${namaKec}, Kab. Situbondo (${dKec.desa.length} Desa/Kelurahan)`, "btn-teal", () => {
        wadahHasil.innerHTML = "";
        bicaraGoogleTTS(`Kecamatan ${namaKec}. Menampilkan ${dKec.desa.length} desa dan kelurahan.`);
        tambahTombol(wadahHasil, "« Kembali ke Daftar 17 Kecamatan Situbondo", "btn-gray", renderDaftar17KecamatanSitubondo);
        dKec.desa.forEach((namaDesa, idxD) => {
          const labelFull = `${namaDesa}, Kec. ${namaKec}, Kab. Situbondo, Jawa Timur`;
          tambahTombol(wadahHasil, `${idxD + 1}. Pilih ${labelFull}`, "btn-green", () => {
            cfg.kota = "Situbondo";
            terapkanWilayahKoordinat(`${namaDesa}, Kec. ${namaKec}`, dKec.lat, dKec.lon, labelFull, "Jawa Timur", "Situbondo", namaKec, namaDesa);
          });
        });
      });
    });
  }

  tambahTombol(root, "Cari & Tampilkan Daftar Wilayah yang Tersedia", "btn-blue", () => {
    const kata = (document.getElementById("input-cari-wilayah").value || "").trim();
    if (!kata || kata.toLowerCase().includes("situbondo")) {
      renderDaftar17KecamatanSitubondo();
      return;
    }
    wadahHasil.innerHTML = "";
    const kLower = kata.toLowerCase();
    let ditemukanLokal = 0;

    const daftarDbDesa = [
      ["Banyumas", "Jawa Tengah & DIY", DATA_BANYUMAS_LENGKAP],
      ["Situbondo", "Jawa Timur", DATA_SITUBONDO_LENGKAP],
      ["Kudus", "Jawa Tengah & DIY", DATA_KUDUS_LENGKAP],
      ["Pati", "Jawa Tengah & DIY", DATA_PATI_LENGKAP]
    ];
    daftarDbDesa.forEach(([namaKabD, namaProvD, dbObjD]) => {
      Object.entries(dbObjD).forEach(([namaKecD, dKecD]) => {
        if (namaKecD.toLowerCase().includes(kLower) || namaKabD.toLowerCase().includes(kLower)) {
          ditemukanLokal++;
          tambahTombol(wadahHasil, `Kecamatan ${namaKecD}, Kab. ${namaKabD} (${dKecD.desa.length} Desa Asli)`, "btn-teal", () => {
            wadahHasil.innerHTML = "";
            dKecD.desa.forEach((namaDesaD, idxDD) => {
              const lblFD = `${namaDesaD}, Kec. ${namaKecD}, Kab. ${namaKabD}, ${namaProvD}`;
              tambahTombol(wadahHasil, `${idxDD + 1}. Pilih ${lblFD}`, "btn-green", () => {
                terapkanWilayahKoordinat(`${namaDesaD}, Kec. ${namaKecD}`, dKecD.lat, dKecD.lon, lblFD, namaProvD, namaKabD, namaKecD, namaDesaD);
              });
            });
          });
        }
        dKecD.desa.forEach(namaDesaD => {
          if (namaDesaD.toLowerCase().includes(kLower)) {
            ditemukanLokal++;
            const lblFD = `${namaDesaD}, Kec. ${namaKecD}, Kab. ${namaKabD}, ${namaProvD}`;
            tambahTombol(wadahHasil, `Pilih Desa/Kelurahan Asli: ${lblFD}`, "btn-green", () => {
              terapkanWilayahKoordinat(`${namaDesaD}, Kec. ${namaKecD}`, dKecD.lat, dKecD.lon, lblFD, namaProvD, namaKabD, namaKecD, namaDesaD);
            });
          }
        });
      });
    });
    if (false) KEC_SITUBONDO_URUT.forEach(namaKec => {
      const dKec = DATA_SITUBONDO_LENGKAP[namaKec];
      if (namaKec.toLowerCase().includes(kLower)) {
        ditemukanLokal++;
        tambahTombol(wadahHasil, `Kecamatan ${namaKec}, Kab. Situbondo (Lihat ${dKec.desa.length} Desa)`, "btn-teal", () => {
          wadahHasil.innerHTML = "";
          dKec.desa.forEach((namaDesa, idxD) => {
            const labelFull = `${namaDesa}, Kec. ${namaKec}, Kab. Situbondo, Jawa Timur`;
            tambahTombol(wadahHasil, `${idxD + 1}. Pilih ${labelFull}`, "btn-green", () => {
              cfg.kota = "Situbondo";
              terapkanWilayahKoordinat(`${namaDesa}, Kec. ${namaKec}`, dKec.lat, dKec.lon, labelFull, "Jawa Timur", "Situbondo", namaKec, namaDesa);
            });
          });
        });
      }
      dKec.desa.forEach(namaDesa => {
        if (namaDesa.toLowerCase().includes(kLower)) {
          ditemukanLokal++;
          const labelFull = `${namaDesa}, Kec. ${namaKec}, Kab. Situbondo, Jawa Timur`;
          tambahTombol(wadahHasil, `Pilih: ${labelFull}`, "btn-green", () => {
            cfg.kota = "Situbondo";
            terapkanWilayahKoordinat(`${namaDesa}, Kec. ${namaKec}`, dKec.lat, dKec.lon, labelFull, "Jawa Timur", "Situbondo", namaKec, namaDesa);
          });
        }
      });
    });

    // Cari di seluruh Kecamatan Nasional (Jawa Timur, Jawa Tengah & DIY termasuk Kudus/Yogyakarta, DKI Jakarta, Jawa Barat)
    for (const [namaKotaN, listKecN] of Object.entries(DATA_KECAMATAN_NASIONAL)) {
      const detP = deteksiProvinsiDariKota(namaKotaN);
      const provN = detP ? detP.prov : "Jawa Tengah & DIY";
      if (namaKotaN.toLowerCase().includes(kLower)) {
        ditemukanLokal++;
        tambahTombol(wadahHasil, `Pilih ${namaKotaN}, ${provN} (${listKecN.length} Kecamatan)`, "btn-teal", () => {
          wadahHasil.innerHTML = "";
          bicaraGoogleTTS(`Menampilkan ${listKecN.length} kecamatan di ${namaKotaN}.`);
          listKecN.forEach((kecItem, idxKi) => {
            const koorK = dapatkanKoordinatKecamatanAktif(namaKotaN, kecItem, idxKi);
            const lblF = `Pusat Kecamatan ${kecItem}, Kec. ${kecItem}, ${namaKotaN}, ${provN}`;
            tambahTombol(wadahHasil, `${idxKi + 1}. Pilih Kecamatan ${kecItem}, ${namaKotaN}`, "btn-green", () => {
              terapkanWilayahKoordinat(`Kec. ${kecItem}, ${namaKotaN}`, koorK.lat, koorK.lon, lblF, provN, namaKotaN, kecItem, `Pusat Kecamatan ${kecItem}`);
            });
          });
        });
      }
      listKecN.forEach((kecItem, idxKi) => {
        if (kecItem.toLowerCase().includes(kLower)) {
          ditemukanLokal++;
          const koorK = dapatkanKoordinatKecamatanAktif(namaKotaN, kecItem, idxKi);
          const lblF = `Pusat Kecamatan ${kecItem}, Kec. ${kecItem}, ${namaKotaN}, ${provN}`;
          tambahTombol(wadahHasil, `Pilih Kecamatan ${kecItem}, ${namaKotaN} (${provN})`, "btn-green", () => {
            terapkanWilayahKoordinat(`Kec. ${kecItem}, ${namaKotaN}`, koorK.lat, koorK.lon, lblF, provN, namaKotaN, kecItem, `Pusat Kecamatan ${kecItem}`);
          });
        }
      });
    }

    for (const [kKey, vKoor] of Object.entries(KOORDINAT_KOTA_NASIONAL)) {
      if (kKey.includes(kLower) || vKoor.label.toLowerCase().includes(kLower)) {
        ditemukanLokal++;
        const detP = deteksiProvinsiDariKota(kKey);
        const provK = detP ? detP.prov : cfg.provinsiTerpilih;
        const kotaK = detP ? detP.kotaResmi : vKoor.label;
        const listK = dapatkanDaftarKecamatanKota(kotaK);
        tambahTombol(wadahHasil, `Pilih Kota/Kabupaten: ${vKoor.label}`, "btn-teal", () => {
          terapkanWilayahKoordinat(vKoor.label, vKoor.lat, vKoor.lon, vKoor.label, provK, kotaK, listK[0] || "", `Pusat Kecamatan ${listK[0] || kotaK}`);
        });
      }
    }

    if (ditemukanLokal > 0) {
      bicaraGoogleTTS(`Ditemukan ${ditemukanLokal} wilayah yang cocok di bawah tombol cari.`);
    }

    fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(kata)}&count=8&language=id&countryCode=ID`)
      .then(r => r.json())
      .then(d => {
        if (d.results && d.results.length > 0) {
          d.results.forEach(it => {
            const bag = [it.name, it.admin3 ? "Kec. " + it.admin3 : "", it.admin2 || "", it.admin1 || ""].filter(Boolean);
            const lbl = bag.join(", ");
            tambahTombol(wadahHasil, `Wilayah Nasional: ${lbl}`, "btn-blue", () => {
              cfg.kota = it.name;
              terapkanWilayahKoordinat(it.name, it.latitude, it.longitude, lbl);
            });
          });
          bicaraGoogleTTS("Daftar wilayah tersedia di bawah tombol cari. Silakan pilih.");
        } else if (ditemukanLokal === 0) {
          bicaraGoogleTTS("Wilayah tidak ditemukan. Silakan periksa ejaan nama kota atau kecamatan.");
        }
      })
      .catch(() => {});
  });

  function renderDaftarKecamatanLengkapKab(namaKab, namaProv, dbKab) {
    wadahHasil.innerHTML = "";
    const daftarK = Object.keys(dbKab);
    bicaraGoogleTTS(`Menampilkan ${daftarK.length} kecamatan asli di Kabupaten ${namaKab}. Silakan pilih kecamatan untuk membuka daftar desa.`);
    daftarK.forEach((namaKec, idxK) => {
      const dKec = dbKab[namaKec];
      tambahTombol(wadahHasil, `${idxK + 1}. Kecamatan ${namaKec}, Kab. ${namaKab} (${dKec.desa.length} Desa/Kelurahan)`, "btn-teal", () => {
        wadahHasil.innerHTML = "";
        bicaraGoogleTTS(`Kecamatan ${namaKec}, Kabupaten ${namaKab}. Menampilkan ${dKec.desa.length} desa dan kelurahan asli.`);
        tambahTombol(wadahHasil, `« Kembali ke Daftar Kecamatan Kab. ${namaKab}`, "btn-gray", () => renderDaftarKecamatanLengkapKab(namaKab, namaProv, dbKab));
        dKec.desa.forEach((namaDesa, idxD) => {
          const labelFull = `${namaDesa}, Kec. ${namaKec}, Kab. ${namaKab}, ${namaProv}`;
          tambahTombol(wadahHasil, `${idxD + 1}. Pilih ${labelFull}`, "btn-green", () => {
            terapkanWilayahKoordinat(`${namaDesa}, Kec. ${namaKec}`, dKec.lat, dKec.lon, labelFull, namaProv, namaKab, namaKec, namaDesa);
          });
        });
      });
    });
  }

  tambahTombol(root, "Tampilkan 27 Kecamatan & 331 Desa Asli Kabupaten Banyumas (Jawa Tengah)", "btn-green", () => renderDaftarKecamatanLengkapKab("Banyumas", "Jawa Tengah & DIY", DATA_BANYUMAS_LENGKAP), "btn-daftar-lengkap-banyumas");
  tambahTombol(root, "Tampilkan 17 Kecamatan & 136 Desa Asli Kabupaten Situbondo (Jawa Timur)", "btn-teal", () => renderDaftarKecamatanLengkapKab("Situbondo", "Jawa Timur", DATA_SITUBONDO_LENGKAP), "btn-daftar-lengkap-situbondo");
  tambahTombol(root, "Tampilkan 9 Kecamatan & 132 Desa Asli Kabupaten Kudus (Jawa Tengah)", "btn-blue", () => renderDaftarKecamatanLengkapKab("Kudus", "Jawa Tengah & DIY", DATA_KUDUS_LENGKAP), "btn-daftar-lengkap-kudus");
  tambahTombol(root, "Tampilkan 21 Kecamatan & Desa Asli Kabupaten Pati (Jawa Tengah)", "btn-purple", () => renderDaftarKecamatanLengkapKab("Pati", "Jawa Tengah & DIY", DATA_PATI_LENGKAP), "btn-daftar-lengkap-pati");

  // BAGIAN 3: GPS & FAVORIT
  tambahLabelBagian(root, "3. Deteksi Otomatis GPS & Wilayah Favorit");
  tambahTombol(root, "Deteksi Kecamatan & Desa Saya Otomatis (GPS)", "btn-teal", () => {
    bicaraGoogleTTS("Mendeteksi titik koordinat lokasi melalui sensor GPS.");
    if (window.AndroidBridge && window.AndroidBridge.requestGPS) {
      window.AndroidBridge.requestGPS();
      return;
    }
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(pos => {
        window.onNativeGPSResult(pos.coords.latitude, pos.coords.longitude, "");
      }, () => {
        bicaraGoogleTTS("Lokasi GPS belum terkunci. Silakan pilih dari daftar Kecamatan di atas.");
      });
    } else {
      bicaraGoogleTTS("Sensor GPS tidak tersedia.");
    }
  });
  tambahTombol(root, "Buka Daftar Wilayah Favorit Tersimpan", "btn-dark", menuProfilLokasi);

  // BAGIAN 4: KOREKSI IKHTIYATH DI BAGIAN BAWAH (UPDATE IN-PLACE TANPA MERUSAK FOKUS!)
  const lblIkhtiar = tambahLabelBagian(root, `4. Koreksi Menit Ikhtiyath Serentak: ${cfg.ikhtiar >= 0 ? "+" : ""}${cfg.ikhtiar} Menit`);
  tambahTombol(root, "Kurangi Ikhtiyath Serentak (-1 Menit)", "btn-orange", () => {
    cfg.ikhtiar = Math.max(-15, (cfg.ikhtiar || 0) - 1);
    simpanData();
    lblIkhtiar.textContent = `4. Koreksi Menit Ikhtiyath Serentak: ${cfg.ikhtiar >= 0 ? "+" : ""}${cfg.ikhtiar} Menit`;
    bicaraGoogleTTS(`Koreksi Ikhtiyath ${cfg.ikhtiar} menit`);
  });
  tambahTombol(root, "Reset Ikhtiyath Serentak (0 Menit)", "btn-gray", () => {
    cfg.ikhtiar = 0;
    simpanData();
    lblIkhtiar.textContent = "4. Koreksi Menit Ikhtiyath Serentak: 0 Menit";
    bicaraGoogleTTS("Koreksi Ikhtiyath 0 menit");
  });
  tambahTombol(root, "Tambah Ikhtiyath Serentak (+1 Menit)", "btn-green", () => {
    cfg.ikhtiar = Math.min(15, (cfg.ikhtiar || 0) + 1);
    simpanData();
    lblIkhtiar.textContent = `4. Koreksi Menit Ikhtiyath Serentak: ${cfg.ikhtiar >= 0 ? "+" : ""}${cfg.ikhtiar} Menit`;
    bicaraGoogleTTS(`Koreksi Ikhtiyath plus ${cfg.ikhtiar} menit`);
  });

  tambahLabelBagian(root, "5. Koreksi Menit Spesifik Per Waktu Salat");
  const daftarKor = [
    ["Koreksi Khusus Subuh", "kor_subuh"],
    ["Koreksi Khusus Dzuhur", "kor_dzuhur"],
    ["Koreksi Khusus Ashar", "kor_ashar"],
    ["Koreksi Khusus Maghrib", "kor_maghrib"],
    ["Koreksi Khusus Isya", "kor_isya"]
  ];
  daftarKor.forEach(([label, key]) => {
    const btnKurang = document.createElement("button");
    const btnTambah = document.createElement("button");
    btnKurang.type = "button";
    btnTambah.type = "button";
    btnKurang.id = `btn-kurangi-${key}`;
    btnTambah.id = `btn-tambah-${key}`;
    btnKurang.className = "btn btn-orange";
    btnTambah.className = "btn btn-green";
    function segarkanKor() {
      const val = Number(cfg[key]) || 0;
      const strVal = `${val >= 0 ? "+" : ""}${val} Menit`;
      btnKurang.textContent = `${label} (Saat Ini: ${strVal}) — Kurangi (-1 Menit)`;
      btnTambah.textContent = `${label} (Saat Ini: ${strVal}) — Tambah (+1 Menit)`;
    }
    btnKurang.onclick = () => {
      cfg[key] = Math.max(-10, (Number(cfg[key]) || 0) - 1);
      simpanData();
      segarkanKor();
      bicaraGoogleTTS(`${label} ${cfg[key]} menit`);
    };
    btnTambah.onclick = () => {
      cfg[key] = Math.min(10, (Number(cfg[key]) || 0) + 1);
      simpanData();
      segarkanKor();
      bicaraGoogleTTS(`${label} plus ${cfg[key]} menit`);
    };
    segarkanKor();
    root.appendChild(btnKurang);
    root.appendChild(btnTambah);
  });

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 6: DAFTAR WILAYAH FAVORIT
// -------------------------------------------------------------------------
function menuProfilLokasi() {
  const root = bersihkanLayar();
  tambahHeader(root, "Wilayah Favorit & Cadangan Pengaturan", "Simpan Wilayah Favorit atau Cadangkan Setelan Masjid Anda");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  tambahLabelBagian(root, "1. Cadangkan & Pulihkan Pengaturan Masjid (Backup & Restore)");
  tambahTombol(root, "Simpan Cadangan Seluruh Pengaturan Saya Saat Ini", "btn-green", () => {
    try {
      localStorage.setItem("nidaul_masjid_backup_user_v77", JSON.stringify(cfg));
      bicaraGoogleTTS("Alhamdulillah, seluruh pengaturan lokasi dan sakelar Anda berhasil dicadangkan.");
    } catch (e) {}
  }, "btn-simpan-cadangan");

  tambahTombol(root, "Pulihkan Pengaturan dari Cadangan Tersimpan", "btn-blue", () => {
    try {
      const rawB = localStorage.getItem("nidaul_masjid_backup_user_v77");
      if (!rawB) {
        bicaraGoogleTTS("Belum ada cadangan pengaturan yang disimpan.");
        return;
      }
      cfg = window.cfg = Object.assign(buatConfigDefault(), JSON.parse(rawB));
      pastikanJadwalTersedia();
      simpanData();
      bicaraGoogleTTS(`Alhamdulillah, pengaturan berhasil dipulihkan untuk wilayah ${cfg.lokasiDitemukan || cfg.kota}.`);
      tampilkanMenuUtama();
    } catch (e) {}
  }, "btn-pulihkan-cadangan");

  tambahLabelBagian(root, "2. Daftar Wilayah & Kecamatan Favorit");
  tambahTombol(root, "Simpan Wilayah Aktif Saat Ini ke Favorit", "btn-teal", () => {
    if (!apakahLokasiSudahDiatur()) {
      bicaraGoogleTTS("Silakan pilih wilayah terlebih dahulu sebelum menyimpan ke favorit.");
      return;
    }
    const nama = cfg.lokasiDitemukan || cfg.kecamatan || cfg.kota;
    cfg.profilLokasi = cfg.profilLokasi || {};
    cfg.profilLokasi[nama] = {
      prov: cfg.provinsiTerpilih,
      kota: cfg.kota,
      kecamatan: cfg.kecamatanTerpilih,
      desa: cfg.desaTerpilih,
      lokasi: cfg.lokasiDitemukan,
      lat: cfg.latitude,
      lon: cfg.longitude,
      kiblat: cfg.sudutKiblat
    };
    simpanData();
    bicaraGoogleTTS(`Wilayah ${nama} berhasil disimpan ke daftar favorit.`);
    menuProfilLokasi();
  });

  const pList = Object.entries(cfg.profilLokasi || {});
  if (pList.length === 0) {
    const infoKosong = document.createElement("div");
    infoKosong.className = "summary-item";
    infoKosong.setAttribute("tabindex", "0");
    infoKosong.textContent = "Belum ada wilayah favorit yang disimpan.";
    root.appendChild(infoKosong);
  } else {
    pList.forEach(([nama, d]) => {
      tambahTombol(root, `Aktifkan Favorit: ${d.lokasi} (Kiblat ${d.kiblat}°)`, "btn-green", () => {
        terapkanWilayahKoordinat(d.kecamatan || nama, d.lat, d.lon, d.lokasi, d.prov || "", d.kota || "", d.kecamatan || "", d.desa || "");
      });
    });
  }

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

window.onNativeCompass = function(azimuth) {
  if (!kompasListenerAktif) return;
  const elStatus = document.getElementById("kompas-status-live");
  const target = cfg.sudutKiblat || 294;
  const azBulat = Math.round(Number(azimuth) || 0);
  let diff = azBulat - target;
  if (diff > 180) diff -= 360;
  if (diff < -180) diff += 360;

  let arahTeks = "";
  if (Math.abs(diff) <= 5) {
    arahTeks = `TEPAT MENGHADAP KIBLAT! (${azBulat}° • Target ${target}°)`;
  } else if (diff > 0) {
    arahTeks = `Posisi HP: ${azBulat}° — Putar ke KIRI sebesar ${Math.abs(diff)}° menuju ${target}°`;
  } else {
    arahTeks = `Posisi HP: ${azBulat}° — Putar ke KANAN sebesar ${Math.abs(diff)}° menuju ${target}°`;
  }
  if (elStatus) elStatus.textContent = arahTeks;

  const now = Date.now();
  if (now - lastCompassSpeak >= 3200) {
    lastCompassSpeak = now;
    if (Math.abs(diff) <= 5) {
      bicaraGoogleTTS("Alhamdulillah tepat! Anda sudah menghadap arah Kiblat.", true);
    } else if (Math.abs(diff) <= 25) {
      bicaraGoogleTTS(diff > 0 ? "Geser ke kiri sedikit." : "Geser ke kanan sedikit.", true);
    } else {
      bicaraGoogleTTS(diff > 0 ? "Putar ke arah kiri." : "Putar ke arah kanan.", true);
    }
  }
};

function menuRadarKiblat() {
  const root = bersihkanLayar();
  tambahHeader(root, "Kompas Penunjuk Arah Kiblat Bersuara", "Panduan Suara & Getar Aktif Menuju Ka'bah");
  tambahTombol(root, "Matikan Kompas & Kembali ke Beranda Utama", "btn-red", tampilkanMenuUtama);

  const target = cfg.sudutKiblat || 294;
  const cardLive = document.createElement("div");
  cardLive.className = "summary-item";
  cardLive.id = "kompas-status-live";
  cardLive.setAttribute("tabindex", "0");
  cardLive.textContent = `Target Arah Kiblat: ${target}° dari Utara. Letakkan HP mendatar dan putar perlahan mengikuti panduan suara.`;
  root.appendChild(cardLive);

  const cardPanduan = document.createElement("div");
  cardPanduan.className = "legal-card";
  cardPanduan.setAttribute("tabindex", "0");
  cardPanduan.innerHTML = `
    <h2>Panduan Arah Kiblat Wilayah Anda</h2>
    <p>Wilayah: <strong>${cfg.lokasiDitemukan || cfg.kota}</strong></p>
    <p>Sudut Presisi Ka'bah: <strong>${target} Derajat dari Utara</strong> (Barat Serong Utara sebesar ${target - 270} Derajat).</p>
    <p>Pegang ponsel secara mendatar. Asisten suara akan memandu Anda berputar ke kiri atau ke kanan hingga tepat menghadap Kiblat disertai getaran.</p>
  `;
  root.appendChild(cardPanduan);

  kompasListenerAktif = true;
  bicaraGoogleTTS(`Kompas kiblat aktif. Target arah kiblat wilayah Anda ${target} derajat dari utara. Pegang ponsel mendatar dan ikuti panduan suara.`);

  if (window.AndroidBridge && window.AndroidBridge.startCompass) {
    try { window.AndroidBridge.startCompass(target); } catch (e) {}
  } else if (window.DeviceOrientationEvent) {
    window.addEventListener("deviceorientation", function(e) {
      if (!kompasListenerAktif) return;
      let heading = e.webkitCompassHeading || (e.alpha !== null ? (360 - e.alpha) % 360 : null);
      if (heading !== null) window.onNativeCompass(heading);
    });
  }

  tambahTombol(root, "Bacakan Sudut & Panduan Arah Kiblat", "btn-teal", () => {
    bicaraGoogleTTS(`Target arah kiblat wilayah ${cfg.lokasiDitemukan || cfg.kota} adalah ${target} derajat dari utara, atau menghadap ke Barat lalu serong ke kanan sebesar ${target - 270} derajat.`);
  });
  tambahTombol(root, "Matikan Kompas & Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 8: KALENDER HIJRIYAH & PASARAN JAWA (TERSTRUKTUR PER BARIS!)
// -------------------------------------------------------------------------
let offsetKalender = 0;
function menuKalenderHijriyah() {
  const root = bersihkanLayar();
  tambahHeader(root, "Kalender Hijriyah, Pasaran Jawa & Hari Besar", "Penanggalan Islam & Koreksi Rukyatul Hilal");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  const listKal = document.createElement("div");
  listKal.className = "summary-list";
  listKal.setAttribute("role", "list");

  function renderIsiKalender(bacaSuara) {
    listKal.innerHTML = "";
    const tMasehi = formatTanggalIndo(dapatkanTanggalISO(offsetKalender));
    const jwObj = hitungKalenderJawaLengkap(offsetKalender);
    const hObj = hitungHijriyahLokal(offsetKalender);
    const ketHariBesar = infoHariBesarIslam(offsetKalender);
    const ketPuasaSunnah = infoPuasaDanAmalanTerdekat(offsetKalender);
    const baris = [
      `Tanggal Masehi: ${tMasehi}`,
      `Kalender Jawa & Weton: ${jwObj.weton}, ${jwObj.tglJawa} ${jwObj.bulanJawa} ${jwObj.tahunJawa} Tahun ${jwObj.namaTahunJawa} (Windu ${jwObj.namaWindu})`,
      `Hitungan Neptu & Wuku Jawa: ${jwObj.teksNeptu} • ${jwObj.teksWuku}`,
      `Tanggal Hijriyah: ${hObj.teksLengkap}`,
      `Peringatan Hari Besar Islam: ${ketHariBesar}`,
      `Jadwal Puasa & Amalan Sunnah: ${ketPuasaSunnah}`
    ];
    baris.forEach((b, idx) => {
      const d = document.createElement("div");
      d.className = "summary-item";
      d.id = `item-kalender-baris-${idx}`;
      d.setAttribute("role", "listitem");
      d.setAttribute("tabindex", "0");
      d.textContent = b;
      d.onclick = () => bicaraGoogleTTS(b);
      listKal.appendChild(d);
    });
    if (bacaSuara) bicaraGoogleTTS(baris.join(". "));

    // Sinkronisasi langsung dengan API Resmi untuk tanggal yang sedang dijelajahi
    const offsetSaatIni = offsetKalender;
    ambilTanggalHijriyah(offsetSaatIni, function(teksApi) {
      if (offsetKalender !== offsetSaatIni) return;
      const jwBaru = hitungKalenderJawaLengkap(offsetSaatIni);
      const elBaris1 = document.getElementById("item-kalender-baris-1");
      const elBaris2 = document.getElementById("item-kalender-baris-2");
      const elBaris3 = document.getElementById("item-kalender-baris-3");
      const elBaris4 = document.getElementById("item-kalender-baris-4");
      const elBaris5 = document.getElementById("item-kalender-baris-5");
      if (elBaris1) elBaris1.textContent = `Kalender Jawa & Weton: ${jwBaru.weton}, ${jwBaru.tglJawa} ${jwBaru.bulanJawa} ${jwBaru.tahunJawa} Tahun ${jwBaru.namaTahunJawa} (Windu ${jwBaru.namaWindu})`;
      if (elBaris2) elBaris2.textContent = `Hitungan Neptu & Wuku Jawa: ${jwBaru.teksNeptu} • ${jwBaru.teksWuku}`;
      if (elBaris3) elBaris3.textContent = `Tanggal Hijriyah: ${teksApi}`;
      if (elBaris4) elBaris4.textContent = `Peringatan Hari Besar Islam: ${infoHariBesarIslam(offsetSaatIni)}`;
      if (elBaris5) elBaris5.textContent = `Jadwal Puasa & Amalan Sunnah: ${infoPuasaDanAmalanTerdekat(offsetSaatIni)}`;
    });
  }
  root.appendChild(listKal);
  renderIsiKalender(true);

  const lblHilal = tambahLabelBagian(root, `Penyesuaian Rukyatul Hilal: ${cfg.koreksiHijriyah || 0} Hari`);
  tambahTombol(root, "Mundurkan Hilal (-1 Hari)", "btn-orange", () => {
    cfg.koreksiHijriyah = (cfg.koreksiHijriyah || 0) - 1;
    simpanData();
    lblHilal.textContent = `Penyesuaian Rukyatul Hilal: ${cfg.koreksiHijriyah} Hari`;
    renderIsiKalender(true);
  });
  tambahTombol(root, "Majukan Hilal (+1 Hari)", "btn-green", () => {
    cfg.koreksiHijriyah = (cfg.koreksiHijriyah || 0) + 1;
    simpanData();
    lblHilal.textContent = `Penyesuaian Rukyatul Hilal: ${cfg.koreksiHijriyah} Hari`;
    renderIsiKalender(true);
  });

  tambahLabelBagian(root, "Jelajahi Tanggal");
  tambahTombol(root, "Lihat Hari Berikutnya (+1 Hari)", "btn-teal", () => { offsetKalender++; renderIsiKalender(true); });
  tambahTombol(root, "Kembali ke Tanggal Hari Ini", "btn-dark", () => { offsetKalender = 0; renderIsiKalender(true); });
  tambahTombol(root, "Lihat Hari Sebelumnya (-1 Hari)", "btn-teal", () => { offsetKalender--; renderIsiKalender(true); });
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 9: TABEL JADWAL SALAT HARIAN LENGKAP (8 BARIS FOKUS TERPISAH!)
// -------------------------------------------------------------------------
let offsetJadwal = 0;
function menuJadwalBulanan() {
  const root = bersihkanLayar();
  tambahHeader(root, "Tabel Jadwal Salat Harian Lengkap", "Periksa Jadwal Hari Ini, Besok, atau Hari Lainnya");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  const wadahTabel = document.createElement("div");
  root.appendChild(wadahTabel);

  function renderTabelHari(bacaSuara) {
    wadahTabel.innerHTML = "";
    const tgl = dapatkanTanggalISO(offsetJadwal);
    const dt = new Date(Date.now() + offsetJadwal * 86400000);
    const j = hitungJadwalKemenagSatuHari(cfg.latitude || -7.7062, cfg.longitude || 114.0095, dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
    buatKotakJadwalTerstruktur(wadahTabel, `JADWAL SALAT — ${formatTanggalIndo(tgl)}`, j);
    if (bacaSuara) {
      const sSubuh = waktuSholatTerkoreksi(j, "Subuh");
      bicaraGoogleTTS(`Jadwal salat ${formatTanggalIndo(tgl)}. Imsak ${tambahMenit(sSubuh, -10)}. Subuh ${sSubuh}. Terbit ${j.Terbit}. Dhuha ${j.Dhuha}. Dzuhur ${waktuSholatTerkoreksi(j, "Dzuhur")}. Ashar ${waktuSholatTerkoreksi(j, "Ashar")}. Maghrib ${waktuSholatTerkoreksi(j, "Maghrib")}. Isya ${waktuSholatTerkoreksi(j, "Isya")}.`);
    }
  }
  renderTabelHari(true);

  tambahTombol(root, "Lihat Jadwal Hari Berikutnya (+1 Hari)", "btn-teal", () => { offsetJadwal++; renderTabelHari(true); });
  tambahTombol(root, "Lihat Jadwal Hari Ini", "btn-green", () => { offsetJadwal = 0; renderTabelHari(true); });
  tambahTombol(root, "Lihat Jadwal Hari Sebelumnya (-1 Hari)", "btn-orange", () => { offsetJadwal--; renderTabelHari(true); });
  tambahTombol(root, "Pasang Pengingat Jam Khusus (Alarm Ibadah)", "btn-blue", menuAlarmPribadi);
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 10: ALARM PRIBADI IBADAH
// -------------------------------------------------------------------------
function menuAlarmPribadi() {
  const root = bersihkanLayar();
  tambahHeader(root, "Pengingat Waktu Khusus (Alarm Ibadah)", "Atur Jam Pengingat & Pesan Suara");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  const wrap = document.createElement("div");
  wrap.innerHTML = `
    <div class="form-group">
      <label for="in-alarm-jam">Jam Pengingat Khusus (Format JJ:MM, contoh 03:15):</label>
      <input type="text" id="in-alarm-jam" placeholder="Contoh: 03:15" value="${cfg.alarm_waktu || ""}" />
    </div>
    <div class="form-group">
      <label for="in-alarm-pesan">Pesan Suara Pengingat:</label>
      <input type="text" id="in-alarm-pesan" placeholder="Contoh: Saatnya bangun untuk salat malam dan zikir" value="${cfg.alarm_pesan || ""}" />
    </div>
  `;
  root.appendChild(wrap);

  tambahTombol(root, "Simpan & Aktifkan Pengingat Khusus", "btn-green", () => {
    const w = (document.getElementById("in-alarm-jam").value || "").trim();
    const p = (document.getElementById("in-alarm-pesan").value || "").trim();
    if (w && hitungMenitAbsolut(w) === -1) {
      bicaraGoogleTTS("Format jam belum tepat. Gunakan dua angka jam titik dua dua angka menit, misalnya 03:15.");
      return;
    }
    cfg.alarm_waktu = w;
    cfg.alarm_pesan = p;
    simpanData();
    bicaraGoogleTTS(`Pengingat khusus berhasil disimpan untuk pukul ${w}`);
    tampilkanMenuUtama();
  });

  tambahTombol(root, "Matikan & Hapus Pengingat Khusus", "btn-red", () => {
    cfg.alarm_waktu = "";
    cfg.alarm_pesan = "";
    simpanData();
    bicaraGoogleTTS("Pengingat waktu khusus telah dinonaktifkan.");
    tampilkanMenuUtama();
  });

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 11: INFO CUACA & GEMPA BMKG
// -------------------------------------------------------------------------
function menuInfoAlam() {
  const root = bersihkanLayar();
  tambahHeader(root, "Pantauan Cuaca Lokal & Gempa BMKG", "Informasi Satelit Cuaca & Seismik Terkini");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  tambahLabelBagian(root, "1. Prakiraan Cuaca Wilayah Anda");
  const kCuaca = document.createElement("div");
  kCuaca.className = "summary-item";
  kCuaca.setAttribute("tabindex", "0");
  kCuaca.textContent = cacheCuaca;
  root.appendChild(kCuaca);
  tambahTombol(root, "Bacakan Laporan Cuaca Sekarang", "btn-teal", () => bicaraGoogleTTS(cacheCuacaSuara));

  tambahLabelBagian(root, "2. Informasi Gempa Bumi Terkini (BMKG)");
  const kGempa = document.createElement("div");
  kGempa.className = "summary-item";
  kGempa.setAttribute("tabindex", "0");
  kGempa.textContent = cacheGempa;
  root.appendChild(kGempa);
  tambahTombol(root, "Bacakan Informasi Gempa BMKG Sekarang", "btn-blue", () => bicaraGoogleTTS(cacheGempa));

  tambahTombol(root, "Perbarui Data Cuaca & Gempa dari Server", "btn-orange", () => {
    bicaraGoogleTTS("Memperbarui data cuaca dan gempa dari peladen.");
    tarikCuacaDanGempa(() => {
      kCuaca.textContent = cacheCuaca;
      kGempa.textContent = cacheGempa;
      bicaraGoogleTTS("Data cuaca dan gempa berhasil diperbarui. " + cacheCuacaSuara);
    });
  });

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 12: DASBOR UJI COBA 21 SUARA (TERHUBUNG KE 23 AUDIO ASLI DI APK!)
// -------------------------------------------------------------------------
function menuTesAudio() {
  const root = bersihkanLayar();
  tambahHeader(root, "Dasbor Uji Coba 21 Suara & Siaran", "Seluruh 23 Berkas Audio Asli Sudah Tertanam di Dalam Aplikasi");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
  tambahTombol(root, "Hentikan Suara yang Sedang Diputar", "btn-red", () => { hentikanAudioDanSimpan(); bicaraGoogleTTS("Pemutaran suara dihentikan."); });

  tambahLabelBagian(root, "1. Uji Suara Asisten, Bel Masjid & Pra-Adzan");
  tambahTombol(root, "1. Uji Sapaan Asisten Suara (TTS)", "btn-teal", () => bicaraGoogleTTS("Alhamdulillah, asisten suara Nurul Masjid Pro berfungsi dengan sangat baik."));
  tambahTombol(root, "2. Uji Sapaan Rangkuman Pagi (Pukul 05.00)", "btn-teal", () => bicaraGoogleTTS(buatRangkumanPagiTeks()));
  tambahTombol(root, "3. Uji Dentang Bel Masjid (bel_pendek.mp3)", "btn-teal", () => putarAudio("sistem", "audio/bel_pendek.mp3"));
  tambahTombol(root, "4. Uji Lantunan Asmaul Husna — Hijjaz (asmaul_husna.mp3)", "btn-teal", () => putarAsmaulHusnaAman(), "btn-tes-asmaul-husna");
  tambahTombol(root, "4b. Uji Rekaman Doa Habis Adzan — Syekh Saad Al-Ghamidi (doa_adzan.mp3)", "btn-green", () => putarAudio("sistem", cfg.doaAdzanFile || "audio/doa_adzan.mp3"), "btn-tes-doa-habis-adzan");
  tambahTombol(root, "5. Uji Lantunan Ya Arhamarrohimin (Arhamarrohimin Tarhim.ogg)", "btn-teal", () => putarAudio("sistem", "audio/Arhamarrohimin Tarhim.ogg"));
  tambahTombol(root, "6. Uji Nada Pembuka Siaran (bumper.mp3)", "btn-teal", () => putarAudio("sistem", "audio/bumper.mp3"));
  tambahTombol(root, "7. Uji Lantunan Tarhim Standar (tarhim.ogg)", "btn-teal", () => putarAudio("sistem", "audio/tarhim.ogg"));
  tambahTombol(root, "8. Uji Lantunan Tarhim Syaikh Mahmud Al-Hussary", "btn-teal", () => putarAudio("sistem", "audio/Tarhim Mahmud Al Hussary.ogg"));

  tambahLabelBagian(root, "2. Uji Lantunan Murottal Al-Qur'an (7 Rekaman Tertanam)");
  tambahTombol(root, "9. Putar Murottal Pengantar Subuh (subuh-01.ogg)", "btn-blue", () => putarAudio("murottal", "audio/murottal/subuh-01.ogg"));
  tambahTombol(root, "10. Putar Murottal Pengantar Dzuhur (dzuhur-01.ogg)", "btn-blue", () => putarAudio("murottal", "audio/murottal/dzuhur-01.ogg"));
  tambahTombol(root, "11. Putar Murottal Pengantar Ashar (ashar-01.ogg)", "btn-blue", () => putarAudio("murottal", "audio/murottal/ashar-01.ogg"));
  tambahTombol(root, "12. Putar Murottal Pengantar Maghrib (maghrib-01.ogg)", "btn-blue", () => putarAudio("murottal", "audio/murottal/maghrib-01.ogg"));
  tambahTombol(root, "13. Putar Murottal Pengantar Isya (isya-01.ogg)", "btn-blue", () => putarAudio("murottal", "audio/murottal/isya-01.ogg"));
  tambahTombol(root, "14. Putar Murottal Surah Al-Jumu'ah (aljumuah.ogg)", "btn-blue", () => putarAudio("murottal", "audio/aljumuah.ogg"));
  tambahTombol(root, "15. Putar Murottal Surah Yasin (yasin.ogg)", "btn-blue", () => putarAudio("murottal", "audio/yasin.ogg"));

  tambahLabelBagian(root, "3. Uji Estafet Operator Waktu Terbit (128 kbps), Sholawat & Tahajud");
  tambahTombol(root, "16A. UJI RANGKAIAN LENGKAP 10 MENIT MENJELANG TERBIT (Timer 10 Detik ➔ Peringatan Terbit 128 kbps ➔ Ya Muhaimin Ya Salam)", "btn-green", () => jalankanEstafetPeringatanTerbit());
  tambahTombol(root, "16B. UJI RANGKAIAN LENGKAP MASUK WAKTU TERBIT (Sirine Terbit ➔ Pengumuman Waktu Terbit 128 kbps)", "btn-green", () => jalankanEstafetWaktuTerbit());
  tambahTombol(root, "16C. Uji Nada Hitung Mundur 10 Detik (timer_terbit.mp3)", "btn-teal", () => putarAudio("sistem", "audio/timer_terbit.mp3"));
  tambahTombol(root, "16D. Uji Suara Operator Peringatan Terbit 128 kbps (peringatan terbit.mp3)", "btn-teal", () => putarAudio("sistem", "audio/peringatan terbit.mp3"));
  tambahTombol(root, "16E. Uji Lantunan Ya Muhaimin Ya Salam — Benyamin Salafuddin (ya_muhaimin_ya_salam.mp3)", "btn-teal", () => putarAudio("murottal", "audio/ya_muhaimin_ya_salam.mp3"));
  tambahTombol(root, "17A. Uji Sirine Penanda Masuk Terbit (sirine_terbit.mp3)", "btn-teal", () => putarAudio("sistem", "audio/sirine_terbit.mp3"));
  tambahTombol(root, "17B. Uji Suara Operator Waktu Syuruq / Terbit 128 kbps (terbit.mp3)", "btn-green", () => putarAudio("sistem", "audio/terbit.mp3"));
  tambahTombol(root, "18. Pengingat Salat Dhuha (dhuha.ogg)", "btn-green", () => putarAudio("sistem", "audio/dhuha.ogg"));
  tambahTombol(root, "19. Pengingat Qiyamul Lail / Tahajud (tahajud.mp3)", "btn-green", () => putarAudio("sistem", "audio/tahajud.mp3"));

  tambahLabelBagian(root, "4. Uji Kumandang Adzan 5 Waktu & Iqomah");
  tambahTombol(root, "20. Uji Kumandang Adzan Subuh (adzan_subuh.ogg)", "", () => putarAudio("adzan", "Subuh"));
  tambahTombol(root, "21. Uji Kumandang Adzan Subuh Syahdu (Azan Sbh Syahdu.ogg)", "", () => putarAudio("sistem", "audio/Azan Sbh Syahdu.ogg"));
  tambahTombol(root, "22. Uji Kumandang Adzan Dzuhur / Standar (adzan.ogg)", "", () => putarAudio("adzan", "Dzuhur"));
  tambahTombol(root, "23. Uji Kumandang Adzan Makkah (adzan_makkah_standar.mp3)", "", () => putarAudio("sistem", "audio/murottal/adzan_makkah_standar.mp3"));
  tambahTombol(root, "24. Uji Kumandang Adzan Masjid Kampung (Ajan Masjid Kampung.ogg)", "", () => putarAudio("sistem", "audio/Ajan Masjid Kampung.ogg"));
  tambahTombol(root, "25. Uji Kumandang Panggilan Iqomah (iqomah.mp3)", "btn-purple", () => putarAudio("sistem", "audio/iqomah.mp3"));

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}


// -------------------------------------------------------------------------
// SISTEM UPDATE OTOMATIS DARI SERVER GITHUB TANPA INSTAL ULANG APK (OTA LIVE UPDATE + AUDIO BARU)
// -------------------------------------------------------------------------
const OTA_MANIFEST_URL_DEFAULT = "https://raw.githubusercontent.com/r81616256-source/nurull-masjid-PRO-BY-NUR-DAN-MAS-YENI-SETIAWAN/main/ota_manifest.json";
const OTA_MANIFEST_URL_FALLBACKS = [
  "https://raw.githubusercontent.com/r81616256-source/nurull-masjid-PRO-BY-NUR-DAN-MAS-Yeni-setiawan/main/ota_manifest.json",
  "https://raw.githubusercontent.com/r81616256-source/nurull-masjid-PRO-BY-NUR-DAN-MAS-YENI-SETIAWAN/main/ota_manifest.json",
  "https://raw.githubusercontent.com/r81616256-source/nurull-masjid-PRO-BY-NUR-DAN-MAS-Yeni-setiawan/master/ota_manifest.json",
  "https://raw.githubusercontent.com/r81616256-source/nurull-masjid-PRO-BY-NUR-DAN-MAS-YENI-SETIAWAN/master/ota_manifest.json",
  "https://raw.githubusercontent.com/r81616256-source/nidaul-masjid-PRO-BY-NUR-dan-mas-Yeni-setiawan/main/ota_manifest.json"
];

window.onOtaAudioDownloaded = function(namaFile, sukses) {
  if (sukses) {
    cfg.daftarAudioOta = cfg.daftarAudioOta || [];
    if (!cfg.daftarAudioOta.includes(namaFile)) {
      cfg.daftarAudioOta.push(namaFile);
      simpanData();
    }
    bicaraGoogleTTS(`Alhamdulillah, berkas audio baru ${namaFile} dari server berhasil ditambahkan secara otomatis tanpa instal ulang.`);
  }
};

async function periksaUpdateOtomatisServer(tampilkanPesanJikaSudahTerbaru = false) {
  const urlManifest = cfg.otaServerUrl || OTA_MANIFEST_URL_DEFAULT;
  try {
    if (tampilkanPesanJikaSudahTerbaru) {
      bicaraGoogleTTS("Memeriksa pembaruan otomatis dan berkas audio baru dari server Nurul Masjid Pro.");
    }
    let resp = null;
    const kandidatUrls = cfg.otaServerUrl ? [cfg.otaServerUrl] : OTA_MANIFEST_URL_FALLBACKS;
    for (let u of kandidatUrls) {
      try {
        const r = await fetch(u + "?t=" + Date.now());
        if (r && r.ok) {
          resp = r;
          break;
        }
      } catch (errUrl) {}
    }
    if (!resp || !resp.ok) {
      if (tampilkanPesanJikaSudahTerbaru) {
        bicaraGoogleTTS("Aplikasi Nurul Masjid Pro Anda sudah berada pada versi terbaru.");
      }
      return;
    }
    const manifest = await resp.json();

    // 1. Cek apakah ada daftar berkas audio baru di server (manifest.audio_baru = [{ nama: "adzan_baru.mp3", url: "https://...", kategori: "adzan" }])
    if (manifest && Array.isArray(manifest.audio_baru)) {
      cfg.daftarAudioOta = cfg.daftarAudioOta || [];
      manifest.audio_baru.forEach(itemAud => {
        if (itemAud && itemAud.nama && itemAud.url && !cfg.daftarAudioOta.includes(itemAud.nama)) {
          if (window.AndroidBridge && window.AndroidBridge.downloadOtaAudio) {
            window.AndroidBridge.downloadOtaAudio(itemAud.url, itemAud.nama);
          }
          if (itemAud.kategori === "tarhim") {
            DAFTAR_REKAMAN_TARHIM.push({ label: itemAud.label || itemAud.nama, file: itemAud.nama });
          } else if (itemAud.kategori === "adzan") {
            DAFTAR_REKAMAN_ADZAN.push({ label: itemAud.label || itemAud.nama, file: itemAud.nama });
          }
        }
      });
    }

    // 2. Cek apakah ada skrip pembaruan fitur OTA (manifest.version > versi lokal)
    const verLokal = Number(localStorage.getItem("nurul_masjid_ota_ver") || 94);
    if (manifest && Number(manifest.version) > verLokal && manifest.script_url) {
      const rScript = await fetch(manifest.script_url + "?t=" + Date.now());
      if (rScript.ok) {
        const kodeBaru = await rScript.text();
        if (kodeBaru && kodeBaru.length > 1000) {
          localStorage.setItem("nurul_masjid_ota_script", kodeBaru);
          localStorage.setItem("nurul_masjid_ota_ver", String(manifest.version));
          bicaraGoogleTTS(`Alhamdulillah, pembaruan otomatis versi ${manifest.version} berhasil diterapkan dari server tanpa instal ulang.`);
          return;
        }
      }
    }

    if (tampilkanPesanJikaSudahTerbaru) {
      bicaraGoogleTTS("Alhamdulillah, aplikasi Nurul Masjid Pro Anda sudah menggunakan versi paling mutakhir.");
    }
  } catch (e) {
    if (tampilkanPesanJikaSudahTerbaru) {
      bicaraGoogleTTS("Tidak dapat terhubung ke server pembaruan atau aplikasi Anda sudah versi terbaru.");
    }
  }
}

// -------------------------------------------------------------------------
// MENU 13: STATUS SISTEM, IZIN BATERAI & PANDUAN
// -------------------------------------------------------------------------
function menuDiagnostik() {
  const root = bersihkanLayar();
  tambahHeader(root, "Status Sistem, Izin Baterai & Panduan", "Pemeriksaan Mesin Latar Belakang, Audio & Baterai");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

  const listDiag = document.createElement("div");
  listDiag.className = "summary-list";
  listDiag.setAttribute("role", "list");
  const selisihDetak = Math.max(0, Math.floor(Date.now() / 1000) - (window.DetakJantung || Math.floor(Date.now() / 1000)));
  const itemsD = [
    `1. Status API Kemenag RI (myQuran): ${cfg.idKota ? "TERHUBUNG (ID Kota: " + cfg.idKota + ")" : "MENUNGGU SINKRONISASI"}`,
    `2. Detak Jantung Masjid (Watchdog): AKTIF (Sesi #${window.SesiMesinAktif || 1} • Detak ${selisihDetak} detik lalu)`,
    `3. Status Mesin Siaran: ${cfg.master_aktif ? "AKTIF 24 JAM (ForegroundService Native)" : "NONAKTIF"}`,
    `Wilayah Aktif: ${cfg.lokasiDitemukan || cfg.kota}`,
    `Koordinat & Kiblat: ${Number(cfg.latitude || 0).toFixed(4)}, ${Number(cfg.longitude || 0).toFixed(4)} (Arah Kiblat ${cfg.sudutKiblat || 294}°)`,
    `Status Berkas Audio Masjid: 23 Berkas Audio Asli Tertanam Langsung di Dalam APK (Siap Mengudara)`,
    `Pola Pemutaran Murottal: ${cfg.modeMurottal.toUpperCase()}`,
    `Jalur Saluran Keluaran Audio (Streaming): ${typeof dapatkanInfoJalurAudioAktif === "function" ? dapatkanInfoJalurAudioAktif().label : "Jalur Media / Musik"}`
  ];
  itemsD.forEach(t => {
    const d = document.createElement("div");
    d.className = "summary-item";
    d.setAttribute("role", "listitem");
    d.setAttribute("tabindex", "0");
    d.textContent = t;
    listDiag.appendChild(d);
  });
  root.appendChild(listDiag);

  tambahTombol(root, "Periksa Pembaruan Otomatis & Audio Baru dari Server Sekarang (Tanpa Instal Ulang APK)", "btn-green", () => {
    periksaUpdateOtomatisServer(true);
  }, "btn-cek-update-server-ota");

  tambahTombol(root, "Bacakan Laporan Status Sistem", "btn-teal", () => bicaraGoogleTTS(itemsD.join(". ")));
  tambahTombol(root, "Buka Pengaturan Izin Baterai (Pilih Tanpa Pembatasan)", "btn-red", () => {
    if (window.AndroidBridge && window.AndroidBridge.openBatterySettings) {
      window.AndroidBridge.openBatterySettings();
    } else {
      bicaraGoogleTTS("Silakan buka Pengaturan HP, pilih Aplikasi, pilih Nurul Masjid Pro, lalu atur Baterai ke Tanpa Pembatasan.");
    }
  });
  tambahTombol(root, "Reset Pabrik ke Kondisi Awal Kosong / Nol (Matikan Semua & Kosongkan Lokasi)", "btn-orange", () => {
    resetKeNolTotal();
    bicaraGoogleTTS("Reset pabrik selesai. Seluruh lokasi dan sakelar telah dikosongkan ke posisi nol.");
    tampilkanMenuUtama();
  });
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
}

// -------------------------------------------------------------------------
// MENU 14: TENTANG APLIKASI, LISENSI RESMI UU HAK CIPTA 2014 & WHATSAPP DEVELOPER
//          (TERSTRUKTUR RAPI DALAM 7 KARTU FOKUS UNTUK TUNANETRA!)
// -------------------------------------------------------------------------
// -------------------------------------------------------------------------
// MENU TASBIH & ZIKIR DIGITAL BERSUARA + GETAR BAKDA SALAT (33x / 99x / 100x / 1000x)
// -------------------------------------------------------------------------
const DAFTAR_ZIKIR_BAKDA_SALAT = [
  { kode: "subhanallah", pendek: "Subhanallah", bacaan: "Subhanallah (Maha Suci Allah)", target: 33 },
  { kode: "alhamdulillah", pendek: "Alhamdulillah", bacaan: "Alhamdulillah (Segala Puji Bagi Allah)", target: 33 },
  { kode: "allahuakbar", pendek: "Allahu Akbar", bacaan: "Allahu Akbar (Allah Maha Besar)", target: 33 },
  { kode: "penggenap100", pendek: "Tahlil Penggenap 100", bacaan: "La ilaha illallahu wahdahu la syarika lah, lahul mulku wa lahul hamdu wa huwa 'ala kulli syai'in qadir", target: 1 }
];

const DAFTAR_MODE_ZIKIR_PILIHAN = [
  { id: "paket_bakda_salat", label: "Paket Sunnah Bakda Salat (33 Subhanallah + 33 Alhamdulillah + 33 Allahu Akbar + 1 Penggenap 100)", pendek: "Paket Bakda Salat", targetDefault: 33 },
  { id: "istighfar", label: "Istighfar — Astaghfirullahal 'Azhim", pendek: "Astaghfirullah", targetDefault: 33 },
  { id: "subhanallah", label: "Tasbih — Subhanallah", pendek: "Subhanallah", targetDefault: 33 },
  { id: "alhamdulillah", label: "Tahmid — Alhamdulillah", pendek: "Alhamdulillah", targetDefault: 33 },
  { id: "allahuakbar", label: "Takbir — Allahu Akbar", pendek: "Allahu Akbar", targetDefault: 33 },
  { id: "tahlil", label: "Tahlil — La ilaha illallah", pendek: "La ilaha illallah", targetDefault: 100 },
  { id: "shalawat", label: "Shalawat Nabi — Allahumma shalli 'ala Sayyidina Muhammad", pendek: "Shalawat Nabi", targetDefault: 100 },
  { id: "tasbih_malaikat", label: "Tasbih Malaikat — Subhanallahi wa bihamdihi Subhanallahil 'azhim", pendek: "Subhanallahi wa bihamdih", targetDefault: 100 }
];

let stateTasbih = {
  modeId: "paket_bakda_salat",
  tahapPaketIdx: 0,
  hitungan: 0,
  targetKustom: 33,
  totalHariIni: 0,
  suaraTiapKetuk: true,
  getarAktif: true
};

function muatStateTasbih() {
  try {
    const rawT = localStorage.getItem("nurul_masjid_tasbih_v85");
    if (rawT) {
      stateTasbih = Object.assign(stateTasbih, JSON.parse(rawT));
    }
  } catch (e) {}
}

function simpanStateTasbih() {
  try {
    localStorage.setItem("nurul_masjid_tasbih_v85", JSON.stringify(stateTasbih));
  } catch (e) {}
}

function dapatkanInfoZikirAktif() {
  if (stateTasbih.modeId === "paket_bakda_salat") {
    const idx = Math.min(stateTasbih.tahapPaketIdx || 0, DAFTAR_ZIKIR_BAKDA_SALAT.length - 1);
    const item = DAFTAR_ZIKIR_BAKDA_SALAT[idx];
    return {
      judul: item.bacaan,
      pendek: item.pendek,
      target: item.target,
      infoTahap: `Tahap ${idx + 1} dari 4 (Paket Zikir Bakda Salat 100x)`
    };
  }
  const m = DAFTAR_MODE_ZIKIR_PILIHAN.find(it => it.id === stateTasbih.modeId) || DAFTAR_MODE_ZIKIR_PILIHAN[1];
  return {
    judul: m.label,
    pendek: m.pendek,
    target: Number(stateTasbih.targetKustom) || m.targetDefault || 33,
    infoTahap: `Mode Zikir Mandiri (Target ${Number(stateTasbih.targetKustom) || 33} Kali)`
  };
}

function bukaMenuTasbihDigital() {
  muatStateTasbih();
  const root = bersihkanLayar("tasbih");
  tambahHeader(root, "Tasbih & Zikir Digital Bersuara + Getar", "Dilengkapi Suara Hitungan Otomatis, Getar Bertingkat & Paket Zikir Bakda Salat");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-tasbih-kembali-atas");

  // 1. Kartu Status Zikir & Total Hitungan
  const kartuInfo = document.createElement("div");
  kartuInfo.id = "kartu-info-tasbih-aktif";
  kartuInfo.className = "summary-item";
  kartuInfo.setAttribute("tabindex", "0");
  root.appendChild(kartuInfo);

  // 2. Tombol Utama Ketuk Hitung Tasbih (Ukuran Ekstra Besar & Nyaman Diketuk Berulang Kali)
  const btnHitung = document.createElement("button");
  btnHitung.type = "button";
  btnHitung.id = "btn-tasbih-hitung-utama";
  btnHitung.className = "btn btn-green";
  btnHitung.style.cssText = "padding:28px 16px;font-size:1.22rem;text-align:center;border:3px solid #A7F3D0;margin:8px 0;";
  root.appendChild(btnHitung);

  function perbaruiLayarTasbih() {
    const info = dapatkanInfoZikirAktif();
    const teksKartu = `${info.infoTahap} • Bacaan Aktif: ${info.judul} • Hitungan Sekarang: ${stateTasbih.hitungan} dari ${info.target} • Total Zikir Tersimpan: ${stateTasbih.totalHariIni} kali`;
    kartuInfo.textContent = teksKartu;
    kartuInfo.setAttribute("aria-label", teksKartu);

    const teksTombol = `KETUK HITUNG TASBIH: ${stateTasbih.hitungan} / ${info.target} — ${info.pendek}`;
    btnHitung.textContent = teksTombol;
    btnHitung.setAttribute("aria-label", `${stateTasbih.hitungan} dari ${info.target}, ${info.pendek}. Ketuk dua kali untuk menambah hitungan.`);
  }
  perbaruiLayarTasbih();

  function tambahSatuHitunganTasbih() {
    const info = dapatkanInfoZikirAktif();
    stateTasbih.hitungan++;
    stateTasbih.totalHariIni = (Number(stateTasbih.totalHariIni) || 0) + 1;
    const capaiTarget = (stateTasbih.hitungan >= info.target);
    const kelipatanSepuluh = (stateTasbih.hitungan % 10 === 0);

    // Getar bertingkat: 400ms saat tamat target, 130ms tiap kelipatan 10, 50ms tiap ketukan biasa
    if (stateTasbih.getarAktif && window.AndroidBridge && window.AndroidBridge.vibrateDevice) {
      window.AndroidBridge.vibrateDevice(capaiTarget ? 400 : (kelipatanSepuluh ? 130 : 50));
    }

    if (capaiTarget) {
      const bacaanSelesai = info.pendek;
      const targetSelesai = info.target;
      if (stateTasbih.modeId === "paket_bakda_salat") {
        if (stateTasbih.tahapPaketIdx < DAFTAR_ZIKIR_BAKDA_SALAT.length - 1) {
          stateTasbih.tahapPaketIdx++;
          stateTasbih.hitungan = 0;
          simpanStateTasbih();
          perbaruiLayarTasbih();
          const infoBaru = dapatkanInfoZikirAktif();
          bicaraGoogleTTS(`${targetSelesai}. Alhamdulillah ${bacaanSelesai} genap ${targetSelesai} kali. Lanjut ke ${infoBaru.judul}.`, true);
        } else {
          stateTasbih.tahapPaketIdx = 0;
          stateTasbih.hitungan = 0;
          simpanStateTasbih();
          perbaruiLayarTasbih();
          if (cfg.s_bel) bunyikanBelMasjid();
          bicaraGoogleTTS("Alhamdulillah, paket zikir bakda salat telah sempurna seratus kali. Semoga amal ibadah dan zikir Anda diterima oleh Allah Subhanahu wa Ta'ala.", true);
        }
      } else {
        stateTasbih.hitungan = 0;
        simpanStateTasbih();
        perbaruiLayarTasbih();
        if (cfg.s_bel) bunyikanBelMasjid();
        bicaraGoogleTTS(`${targetSelesai}. Alhamdulillah, zikir ${bacaanSelesai} telah mencapai target ${targetSelesai} kali.`, true);
      }
    } else {
      simpanStateTasbih();
      perbaruiLayarTasbih();
      if (stateTasbih.suaraTiapKetuk) {
        if (kelipatanSepuluh) {
          bicaraGoogleTTS(`${stateTasbih.hitungan}, ${info.pendek}`, true);
        } else {
          bicaraGoogleTTS(`${stateTasbih.hitungan}`, true);
        }
      }
    }
  }

  btnHitung.addEventListener("click", tambahSatuHitunganTasbih);

  // 3. Tombol Kendali Hitungan (-1 Koreksi, Bacakan Status, Reset Putaran Ini, Reset Total)
  tambahLabelBagian(root, "Kendali Hitungan & Suara Tasbih", "judul-kendali-tasbih");

  const btnSakelarSuara = document.createElement("button");
  btnSakelarSuara.type = "button";
  btnSakelarSuara.id = "btn-tasbih-sakelar-suara";
  function segarkanSakelarSuaraTasbih() {
    btnSakelarSuara.className = `btn ${stateTasbih.suaraTiapKetuk ? "btn-teal" : "btn-gray"}`;
    const tSuara = `Suara Angka Setiap Ketuk: ${stateTasbih.suaraTiapKetuk ? "AKTIF (Menyebutkan Angka Tiap Ketuk)" : "HENING (Hanya Getar & Bunyi Saat Genap Target)"}`;
    btnSakelarSuara.textContent = tSuara;
    btnSakelarSuara.setAttribute("aria-label", tSuara);
  }
  segarkanSakelarSuaraTasbih();
  btnSakelarSuara.addEventListener("click", () => {
    stateTasbih.suaraTiapKetuk = !stateTasbih.suaraTiapKetuk;
    simpanStateTasbih();
    segarkanSakelarSuaraTasbih();
    bicaraGoogleTTS(stateTasbih.suaraTiapKetuk ? "Suara angka setiap ketuk diaktifkan." : "Mode hening, hanya bergetar dan bersuara saat genap target.", true);
  });
  root.appendChild(btnSakelarSuara);

  tambahTombol(root, "Kurangi 1 Hitungan (-1 Jika Kelebihan Ketuk)", "btn-orange", () => {
    if (stateTasbih.hitungan > 0) {
      stateTasbih.hitungan--;
      if (stateTasbih.totalHariIni > 0) stateTasbih.totalHariIni--;
      simpanStateTasbih();
      perbaruiLayarTasbih();
      bicaraGoogleTTS(`Hitungan dikurangi menjadi ${stateTasbih.hitungan}.`, true);
    } else {
      bicaraGoogleTTS("Hitungan saat ini sudah nol.", true);
    }
  }, "btn-tasbih-kurangi-satu");

  tambahTombol(root, "Ulangi Putaran Zikir Ini dari Nol (0)", "btn-red", () => {
    stateTasbih.hitungan = 0;
    stateTasbih.tahapPaketIdx = 0;
    simpanStateTasbih();
    perbaruiLayarTasbih();
    bicaraGoogleTTS("Hitungan putaran zikir ini dikembalikan ke nol.", true);
  }, "btn-reset-tasbih");

  // 4. Pilihan Bacaan Zikir (8 Pilihan Lengkap)
  tambahLabelBagian(root, "Pilih Bacaan Zikir", "judul-pilih-bacaan-zikir");
  DAFTAR_MODE_ZIKIR_PILIHAN.forEach((m, idxM) => {
    const aktif = (stateTasbih.modeId === m.id);
    tambahTombol(root, `${aktif ? "[ AKTIF ] " : ""}${m.label}`, aktif ? "btn-green" : "btn-blue", () => {
      stateTasbih.modeId = m.id;
      stateTasbih.tahapPaketIdx = 0;
      stateTasbih.hitungan = 0;
      stateTasbih.targetKustom = m.targetDefault || 33;
      simpanStateTasbih();
      bicaraGoogleTTS(`Bacaan zikir diatur ke ${m.label}. Hitungan dimulai dari nol.`, true);
      bukaMenuTasbihDigital();
    }, `btn-pilih-zikir-${idxM + 1}`);
  });

  // 5. Pilihan Target Hitungan (Khusus Mode Mandiri: 33x, 99x, 100x, 300x, 1000x)
  if (stateTasbih.modeId !== "paket_bakda_salat") {
    tambahLabelBagian(root, "Pilih Target Jumlah Hitungan Zikir", "judul-target-tasbih");
    [33, 99, 100, 300, 1000].forEach(angkaT => {
      const aktifT = (Number(stateTasbih.targetKustom) === angkaT);
      tambahTombol(root, `${aktifT ? "[ TERPILIH ] " : ""}Target ${angkaT} Kali`, aktifT ? "btn-green" : "btn-teal", () => {
        stateTasbih.targetKustom = angkaT;
        stateTasbih.hitungan = 0;
        simpanStateTasbih();
        bicaraGoogleTTS(`Target hitungan zikir diatur ke ${angkaT} kali.`, true);
        bukaMenuTasbihDigital();
      }, `btn-target-tasbih-${angkaT}`);
    });
  }

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-tasbih-kembali-bawah");
}

// -------------------------------------------------------------------------
// MENU 15: TENTANG APLIKASI & PROFIL PENGEMBANG
//          (MENU TERSENDIRI • 1 BLOK FOKUS UTUH • TANPA SUARA TTS APLIKASI!)
// -------------------------------------------------------------------------
// Fungsi pembuat Kartu Bacaan Terpadu:
// - Bagi Pengguna Awas: Tampil sangat rapi, profesional, berjenjang dengan subjudul emas, lencana identitas, dan paragraf kontras tinggi.
// - Bagi Pengguna Tunanetra (Jieshuo / TalkBack): Merupakan 1 elemen fokus tunggal utuh (tepat 1 kali geser kanan dari judul halaman langsung membacakan seluruh isi dari awal sampai akhir tanpa harus menggeser berkali-kali!).
function tambahkanKartuBacaanUtuhSatuKaliGeser(root, idKartu, daftarBagianVisual, teksBacaanUtuhLengkap) {
  const card = document.createElement("button");
  card.type = "button";
  card.id = idKartu;
  card.className = "legal-card";
  card.style.cssText = "display:block;width:100%;text-align:left;background:#0B3B2E;color:#ECFDF5;border:3px solid #FBBF24;border-radius:18px;padding:18px 16px;margin:10px 0 14px 0;box-shadow:0 10px 28px rgba(0,0,0,0.45);cursor:pointer;font-family:inherit;";
  card.setAttribute("aria-label", teksBacaanUtuhLengkap);

  // Seluruh elemen visual di dalamnya diberi aria-hidden="true" dan memakai <span> blok
  // agar WebView Android tidak memecah fokus Jieshuo/TalkBack menjadi banyak geseran.
  let htmlVisual = "";
  daftarBagianVisual.forEach((bag, idxBag) => {
    const borderTop = idxBag > 0 ? "border-top:1px solid rgba(251,191,36,0.35);padding-top:12px;margin-top:12px;" : "";
    htmlVisual += `<span aria-hidden="true" style="display:block;${borderTop}">`;
    htmlVisual += `<span aria-hidden="true" style="display:block;color:#FDE68A;font-size:1.12rem;font-weight:800;margin-bottom:8px;line-height:1.35;">${bag.judul}</span>`;
    (bag.paragraf || []).forEach((pTeks) => {
      htmlVisual += `<span aria-hidden="true" style="display:block;color:#ECFDF5;font-size:0.98rem;font-weight:500;line-height:1.6;margin-bottom:8px;">${pTeks}</span>`;
    });
    htmlVisual += `</span>`;
  });

  card.innerHTML = htmlVisual;
  card.addEventListener("click", () => {
    bicaraGoogleTTS(teksBacaanUtuhLengkap);
  });
  root.appendChild(card);
}

function tambahkanKartuBacaanNyata(root, idKartu, judulBagian, daftarParagraf) {
  const teksUtuh = judulBagian + ". " + (daftarParagraf || []).join(" ");
  tambahkanKartuBacaanUtuhSatuKaliGeser(root, idKartu, [{ judul: judulBagian, paragraf: daftarParagraf }], teksUtuh);
}

function bukaMenuTentangAplikasi() {
  hentikanAudioDanSimpan();
  const root = bersihkanLayar("tentang");
  tambahHeader(
    root,
    "Tentang Aplikasi & Profil Pengembang Resmi",
    "Geser Kanan Satu Kali untuk Membaca Penuh Deskripsi Aplikasi & Profil Pengembang"
  );

  const bagianVisualTentang = [
    {
      judul: "1. Deskripsi & Keunggulan Aplikasi Nurul Masjid Pro",
      paragraf: [
        "Nurul Masjid Pro adalah aplikasi Android mandiri berstandar profesional yang memadukan Jam Digital Masjid Otomatis 24 Jam dengan Asisten Ibadah Harian Islam.",
        "Aplikasi ini dirancang secara khusus dengan antarmuka visual kontras tinggi yang elegan dan nyaman dipandang oleh pengguna awas, sekaligus 100 persen ramah aksesibilitas layar penuh bagi pengguna tunanetra (pengguna pembaca layar Jieshuo maupun TalkBack) di seluruh Indonesia."
      ]
    },
    {
      judul: "2. Tujuan & Ketepatan Hisab Kementerian Agama RI",
      paragraf: [
        "Dihadirkan sebagai sarana amal jariyah dan kemudahan ibadah bagi masjid, musholla, maupun keluarga Muslim di rumah agar penyiaran jadwal ibadah harian berjalan otomatis 24 jam, tertib, dan akurat sesuai standar hisab Kementerian Agama Republik Indonesia hingga tingkat Provinsi, Kabupaten/Kota, Kecamatan, dan Desa/Kelurahan asli di seluruh Indonesia."
      ]
    },
    {
      judul: "3. Fitur & Fungsi Utama Terpadu",
      paragraf: [
        "Menghitung jadwal salat 9 waktu harian secara presisi (Imsak, Subuh, Terbit/Syuruq, Dhuha, Waktu Istiwa/Zawal, Dzuhur, Ashar, Maghrib, dan Isya) beserta koreksi koordinat geografis nyata tingkat Desa dan Kecamatan.",
        "Menjalankan Mesin Siaran Otomatis 24 Jam di latar belakang lengkap dengan Pengumuman Asisten Marbot 15 Menit Menjelang 5 Waktu Salat, Peringatan 15 Menit Waktu Kehati-hatian Akhir Waktu Salat, Estafet Peringatan 10 Menit Menjelang Matahari Terbit, Lantunan Ya Arhamarrohimin Pra-Subuh, Murottal Al-Qur'an (termasuk Surah Yasin Malam Jumat dan Surah Al-Jumu'ah Hari Jumat), Asmaul Husna Hijjaz, Tarhim Pilihan, Kumandang Adzan 5 Waktu dengan Kualitas Audio Studio Original 100 Persen, Doa Bakda Adzan, hingga Panggilan Iqomah.",
        "Dilengkapi Pilihan 5 Jalur Saluran Audio/Streaming (Media, Nada Dering, Notifikasi, Alarm, dan Sistem) dengan perlindungan anti-reset volume, Kompas Arah Kiblat Bersuara dan Getar, Kalender Hijriyah Kemenag RI dan Kalender Jawa Sultan Agung Lengkap (Weton, Neptu, Wuku, Tahun Jawa, dan Hitung Mundur Hari Besar Islam 12 Bulan), Tasbih Digital Bakda Salat, serta Pantauan Cuaca Satelit dan Info Gempa Bumi BMKG."
      ]
    },
    {
      judul: "4. Profil Pengembang Resmi (Kolaborasi Jawa Timur & Banyumas, Jawa Tengah)",
      paragraf: [
        "Pengembang Pertama (Inisiator Utama, Perancang Arsitektur Sistem & Spesialis Aksesibilitas Tunanetra): Nur — Berasal dari Provinsi Jawa Timur.",
        "Pengembang Kedua (Co-Developer, Pengembang Sistem Penyiaran Masjid & Pengujian Lapangan): Mas Yeni Setiawan — Berasal dari Kabupaten Banyumas, Provinsi Jawa Tengah.",
        "Dedikasi Kolaborasi: Karya kolaborasi antara Nur (Jawa Timur) dan Mas Yeni Setiawan (Banyumas, Jawa Tengah) ini dipersembahkan untuk menghadirkan teknologi ibadah yang setara, mandiri, dan memberdayakan bagi seluruh umat Islam, baik tunanetra maupun awas.",
        "Kontak Resmi WhatsApp & Dukungan Pengembang: 0877-8158-6983."
      ]
    }
  ];

  const teksUtuhTentangDanProfil =
    "Tentang Aplikasi Nurul Masjid Pro dan Profil Pengembang Resmi. " +
    "Bagian Pertama, Deskripsi dan Keunggulan Aplikasi: " +
    "Nurul Masjid Pro adalah aplikasi Android mandiri berstandar profesional yang memadukan Jam Digital Masjid Otomatis 24 Jam dengan Asisten Ibadah Harian Islam. " +
    "Aplikasi ini dirancang secara khusus dengan antarmuka visual kontras tinggi yang elegan dan nyaman dipandang oleh pengguna awas, sekaligus 100 persen ramah aksesibilitas bagi pengguna tunanetra pengguna Jieshuo maupun TalkBack di seluruh Indonesia. " +
    "Bagian Kedua, Tujuan Pembuatan Aplikasi: " +
    "Dihadirkan untuk membantu masjid, musholla, maupun keluarga Muslim di rumah agar dapat menjalankan penyiaran ibadah harian secara otomatis 24 jam, tepat waktu, dan tertib sesuai standar hisab Kementerian Agama Republik Indonesia hingga tingkat Kecamatan dan Desa atau Kelurahan asli di seluruh Indonesia. " +
    "Bagian Ketiga, Fungsi Utama Aplikasi: " +
    "Menghitung jadwal salat 9 waktu harian secara akurat dari Imsak, Subuh, Terbit atau Syuruq, Dhuha, Waktu Istiwa, Dzuhur, Ashar, Maghrib, hingga Isya berdasarkan koordinat asli Desa dan Kecamatan. " +
    "Menjalankan mesin siaran masjid otomatis 24 jam lengkap dengan Pengumuman Asisten Marbot 15 menit menjelang 5 waktu salat, Peringatan 15 menit waktu kehati-hatian akhir waktu salat, Estafet Peringatan Terbit, Ya Arhamarrohimin Pra-Subuh, Murottal Al-Qur'an termasuk Surah Yasin Malam Jumat dan Surah Al-Jumu'ah Hari Jumat, Asmaul Husna Hijjaz, Tarhim, Adzan 5 Waktu berkualitas audio original 100 persen, Doa Setelah Adzan, hingga Panggilan Iqomah. " +
    "Juga dilengkapi Pilihan 5 Jalur Saluran Audio Streaming yaitu Media, Nada Dering, Notifikasi, Alarm, dan Sistem, Kompas Arah Kiblat Bersuara, Kalender Hijriyah dan Kalender Jawa Lengkap beserta Hitung Mundur Hari Besar Islam, Tasbih Digital, serta Info Cuaca dan Gempa BMKG. " +
    "Bagian Keempat, Identitas dan Profil Pengembang Resmi: " +
    "Pengembang Pertama sekaligus Inisiator Utama, Perancang Arsitektur Sistem, dan Spesialis Aksesibilitas Tunanetra adalah Nur, berasal dari Provinsi Jawa Timur. " +
    "Pengembang Kedua sekaligus Co-Developer, Pengembang Sistem Penyiaran Masjid, dan Pengujian Lapangan adalah Mas Yeni Setiawan, berasal dari Kabupaten Banyumas, Provinsi Jawa Tengah. " +
    "Karya kolaborasi Nur dari Jawa Timur dan Mas Yeni Setiawan dari Banyumas Jawa Tengah ini dilindungi Undang-Undang Hak Cipta Republik Indonesia Nomor 28 Tahun 2014. " +
    "Kontak Resmi WhatsApp dan GoPay Pengembang: 0877-8158-6983. Ketuk dua kali pada kartu ini jika ingin mendengarkan ulang melalui suara asisten.";

  // Tepat 1 kali geser kanan dari judul halaman langsung membaca seluruh kartu utuh ini!
  tambahkanKartuBacaanUtuhSatuKaliGeser(
    root,
    "kartu-tentang-dan-profil-utuh",
    bagianVisualTentang,
    teksUtuhTentangDanProfil
  );

  tambahTombol(root, "Hubungi Pengembang via WhatsApp (Nur & Mas Yeni Setiawan: 0877-8158-6983)", "btn-green", () => {
    const pesanWA = "Assalamu'alaikum Nur (Jawa Timur) & Mas Yeni Setiawan (Banyumas), saya pengguna aplikasi Nurul Masjid Pro.";
    if (window.AndroidBridge && window.AndroidBridge.openWhatsApp) {
      window.AndroidBridge.openWhatsApp("6287781586983", pesanWA);
    } else {
      window.open("https://api.whatsapp.com/send?phone=6287781586983&text=" + encodeURIComponent(pesanWA), "_blank");
    }
  }, "btn-wa-developer-tentang");

  tambahTombol(root, "Traktir Pengembang (Dukungan Sukarela GoPay)", "btn-blue", bukaMenuTraktirPengembang, "btn-pintas-traktir");
  tambahTombol(root, "Buka Halaman Lisensi Resmi & Hak Cipta (UU No. 28 Tahun 2014)", "btn-dark", bukaMenuLisensiResmi, "btn-pintas-lisensi");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-tentang-kembali-bawah");
}

function bukaMenuLisensiResmi() {
  hentikanAudioDanSimpan();
  const root = bersihkanLayar("lisensi");
  tambahHeader(
    root,
    "Lisensi Resmi & Perlindungan Hak Cipta",
    "Geser Kanan Satu Kali untuk Membaca Penuh Undang-Undang RI Nomor 28 Tahun 2014"
  );

  const bagianVisualLisensi = [
    {
      judul: "1. Dasar Perlindungan Hukum & Pemegang Hak Cipta Resmi",
      paragraf: [
        "Nama Ciptaan: Aplikasi Jam Digital Masjid & Asisten Ibadah 24 Jam NURUL MASJID PRO.",
        "Pemegang Hak Cipta & Pengembang Resmi: Nur (Jawa Timur) dan Mas Yeni Setiawan (Banyumas, Jawa Tengah).",
        "Seluruh perangkat lunak, kode sumber (source code), arsitektur logika penyiaran, tata letak antarmuka aksesibel, dan paket aplikasi Nurul Masjid Pro merupakan karya cipta intelektual berupa Program Komputer yang dilindungi secara sah berdasarkan Undang-Undang Republik Indonesia Nomor 28 Tahun 2014 tentang Hak Cipta (Pasal 1 Angka 8 dan Pasal 40 Ayat 1 Huruf s)."
      ]
    },
    {
      judul: "2. Hak Moral Pencipta (Pasal 5 Ayat 1 UU RI Nomor 28 Tahun 2014)",
      paragraf: [
        "Hak moral merupakan hak yang melekat secara abadi pada diri Pencipta. Dilarang keras menghilangkan, menghapus, menyembunyikan, atau mengganti nama Pencipta dan Pengembang Resmi yakni Nur (Jawa Timur) dan Mas Yeni Setiawan (Banyumas, Jawa Tengah), serta dilarang mengubah judul maupun memodifikasi isi ciptaan tanpa izin tertulis dari Pemegang Hak Cipta."
      ]
    },
    {
      judul: "3. Hak Ekonomi & Larangan Pengedaran Ilegal (Pasal 9 Ayat 1 & Ayat 3)",
      paragraf: [
        "Setiap orang yang bukan Pemegang Hak Cipta dilarang keras melakukan penggandaan, pembongkaran kode (reverse engineering atau dekompilasi), pendistribusian ulang di luar izin resmi, maupun memperjualbelikan aplikasi ini untuk tujuan komersial tanpa persetujuan tertulis dari Nur dan Mas Yeni Setiawan."
      ]
    },
    {
      judul: "4. Sanksi & Ketentuan Pidana (Pasal 113 Ayat 3 & Ayat 4 UU RI Nomor 28 Tahun 2014)",
      paragraf: [
        "Pasal 113 Ayat (3): Setiap Orang yang dengan tanpa hak dan/atau tanpa izin Pencipta atau pemegang Hak Cipta melakukan pelanggaran hak ekonomi Pencipta untuk Penggunaan Secara Komersial dipidana dengan pidana penjara paling lama 4 (empat) tahun dan/atau pidana denda paling banyak Rp1.000.000.000,00 (satu miliar rupiah).",
        "Pasal 113 Ayat (4): Setiap Orang yang memenuhi unsur sebagaimana dimaksud pada ayat (3) yang dilakukan dalam bentuk pembajakan, dipidana dengan pidana penjara paling lama 10 (sepuluh) tahun dan/atau pidana denda paling banyak Rp4.000.000.000,00 (empat miliar rupiah)."
      ]
    }
  ];

  const teksUtuhLisensiResmi =
    "Lisensi Resmi dan Perlindungan Hukum Hak Cipta Aplikasi Nurul Masjid Pro berdasarkan Undang-Undang Republik Indonesia Nomor 28 Tahun 2014 tentang Hak Cipta. " +
    "Pertama, Dasar Perlindungan Hukum dan Pemegang Hak Cipta Resmi: " +
    "Aplikasi Nurul Masjid Pro adalah karya cipta asli milik Pemegang Hak Cipta dan Pengembang Resmi: Nur dari Jawa Timur, dan Mas Yeni Setiawan dari Banyumas, Jawa Tengah. " +
    "Seluruh perangkat lunak, kode sumber, arsitektur logika, tata letak antarmuka, dan paket aplikasi Nurul Masjid Pro merupakan karya cipta intelektual berupa Program Komputer yang dilindungi secara sah berdasarkan Undang-Undang Republik Indonesia Nomor 28 Tahun 2014 tentang Hak Cipta, khususnya Pasal 1 Angka 8 dan Pasal 40 Ayat 1 Huruf s. " +
    "Kedua, Hak Moral Pencipta berdasarkan Pasal 5 Ayat 1 Undang-Undang Nomor 28 Tahun 2014: " +
    "Hak moral melekat secara abadi pada diri Pencipta. Dilarang keras menghilangkan, menghapus, menyembunyikan, atau mengganti nama Pencipta dan Pengembang Resmi yaitu Nur dari Jawa Timur dan Mas Yeni Setiawan dari Banyumas Jawa Tengah, serta dilarang mengubah judul maupun memodifikasi isi ciptaan tanpa izin tertulis dari Pemegang Hak Cipta. " +
    "Ketiga, Hak Ekonomi dan Larangan Pengedaran Ilegal berdasarkan Pasal 9 Ayat 1 dan Ayat 3: " +
    "Setiap orang yang bukan Pemegang Hak Cipta dilarang melakukan penggandaan, pembongkaran kode atau dekompilasi, pendistribusian ulang di luar izin resmi, maupun memperjualbelikan aplikasi ini untuk tujuan komersial tanpa persetujuan tertulis dari Nur dan Mas Yeni Setiawan. " +
    "Keempat, Sanksi dan Ketentuan Pidana berdasarkan Pasal 113 Ayat 3 dan Ayat 4 Undang-Undang Republik Indonesia Nomor 28 Tahun 2014: " +
    "Pasal 113 Ayat 3 menyatakan: Setiap orang yang dengan tanpa hak dan atau tanpa izin Pencipta melakukan pelanggaran hak ekonomi untuk Penggunaan Secara Komersial dipidana dengan pidana penjara paling lama 4 tahun dan atau pidana denda paling banyak 1 miliar rupiah. " +
    "Pasal 113 Ayat 4 menyatakan: Setiap orang yang memenuhi unsur pelanggaran sebagaimana dimaksud pada Ayat 3 yang dilakukan dalam bentuk pembajakan, dipidana dengan pidana penjara paling lama 10 tahun dan atau pidana denda paling banyak 4 miliar rupiah. " +
    "Ketuk dua kali pada kartu ini jika ingin mendengarkan ulang pembacaan lisensi melalui suara asisten.";

  // Tepat 1 kali geser kanan dari judul halaman langsung membaca seluruh lisensi & undang-undang ini!
  tambahkanKartuBacaanUtuhSatuKaliGeser(
    root,
    "kartu-lisensi-resmi-utuh",
    bagianVisualLisensi,
    teksUtuhLisensiResmi
  );

  tambahTombol(root, "Buka Halaman Tentang Aplikasi & Profil Pengembang (Nur & Mas Yeni Setiawan)", "btn-teal", bukaMenuTentangAplikasi, "btn-lisensi-ke-tentang");
  tambahTombol(root, "Hubungi Pengembang Resmi via WhatsApp (0877-8158-6983)", "btn-green", () => {
    const pesanWA = "Assalamu'alaikum Nur (Jawa Timur) & Mas Yeni Setiawan (Banyumas), saya pengguna aplikasi Nurul Masjid Pro.";
    if (window.AndroidBridge && window.AndroidBridge.openWhatsApp) {
      window.AndroidBridge.openWhatsApp("6287781586983", pesanWA);
    } else {
      window.open("https://api.whatsapp.com/send?phone=6287781586983&text=" + encodeURIComponent(pesanWA), "_blank");
    }
  }, "btn-wa-developer-lisensi");
  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-lisensi-kembali-bawah");
}

function salinNomorGoPayKeClipboard() {
  const kode = [48, 56, 55, 55, 56, 49, 53, 56, 54, 57, 56, 51];
  const nomor = String.fromCharCode(...kode);
  if (window.AndroidBridge && window.AndroidBridge.copyToClipboard) {
    window.AndroidBridge.copyToClipboard("GoPay Pengembang", nomor);
  } else {
    try {
      const ta = document.createElement("textarea");
      ta.value = nomor;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    } catch (e) {}
  }
  return nomor;
}

function bukaMenuTraktirPengembang() {
  hentikanAudioDanSimpan();
  const root = bersihkanLayar("traktir");
  tambahHeader(
    root,
    "Traktir Pengembang (Apresiasi Sukarela)",
    "Geser Kanan Satu Kali untuk Membaca Penuh Penjelasan Dukungan Sukarela"
  );

  const bagianVisualTraktir = [
    {
      judul: "Apresiasi & Dukungan Sukarela (100% Gratis Tanpa Syarat Premium)",
      paragraf: [
        "Aplikasi Nurul Masjid Pro karya Nur (Jawa Timur) dan Mas Yeni Setiawan (Banyumas, Jawa Tengah) ini sepenuhnya gratis (100 persen bebas biaya langganan dan seluruh fitur terbuka penuh tanpa syarat premium) sebagai amal jariyah dan sarana kemudahan ibadah bagi umat Islam, baik pengguna tunanetra maupun masyarakat umum.",
        "Apabila Anda merasa terbantu dengan kehadiran aplikasi ini dan ingin berbagi rezeki sekadar mentraktir kopi atau mendukung pengembangan berkelanjutan bersama Nur dan Mas Yeni Setiawan secara sukarela, Anda dapat menyalurkannya melalui dompet digital GoPay di nomor 0877-8158-6983.",
        "Saat Anda menekan tombol Buka Aplikasi GoPay di bawah ini, nomor tujuan GoPay pengembang (0877-8158-6983) akan otomatis tersalin ke papan klip ponsel Anda sehingga tinggal ditempelkan pada kolom tujuan transfer.",
        "Jazakumullahu khairan katsiran atas doa, dukungan, dan apresiasi Anda. Semoga menjadi amal kebaikan yang membawa keberkahan bagi kita semua."
      ]
    }
  ];

  const teksUtuhTraktir =
    "Apresiasi dan Dukungan Sukarela Tanpa Syarat Premium. " +
    "Aplikasi Nurul Masjid Pro karya Nur dari Jawa Timur dan Mas Yeni Setiawan dari Banyumas Jawa Tengah ini sepenuhnya gratis, 100 persen bebas biaya langganan, dan seluruh fitur terbuka penuh tanpa syarat premium sebagai amal jariyah bagi umat Islam, baik pengguna tunanetra maupun masyarakat umum. " +
    "Apabila Anda merasa terbantu dengan kehadiran aplikasi ini dan ingin berbagi rezeki sekadar mentraktir kopi atau mendukung pengembangan berkelanjutan bersama Nur dan Mas Yeni Setiawan secara sukarela, Anda dapat menyalurkannya melalui dompet digital GoPay di nomor 0877-8158-6983. " +
    "Saat Anda menekan tombol Buka Aplikasi GoPay di bawah ini, nomor tujuan GoPay pengembang akan otomatis tersalin ke papan klip ponsel Anda sehingga tinggal ditempelkan pada kolom tujuan transfer. " +
    "Jazakumullahu khairan katsiran atas doa, dukungan, dan apresiasi Anda.";

  tambahkanKartuBacaanUtuhSatuKaliGeser(
    root,
    "kartu-traktir-penjelasan-utuh",
    bagianVisualTraktir,
    teksUtuhTraktir
  );

  tambahTombol(root, "Buka Aplikasi GoPay (Otomatis Salin Nomor 0877-8158-6983)", "btn-blue", () => {
    const nomor = salinNomorGoPayKeClipboard();
    if (window.AndroidBridge && window.AndroidBridge.openGoPay) {
      window.AndroidBridge.openGoPay(nomor);
    } else {
      bicaraGoogleTTS("Nomor tujuan GoPay pengembang berhasil disalin ke papan klip ponsel Anda.", true);
    }
  }, "btn-buka-gopay-langsung");

  tambahTombol(root, "Salin Nomor GoPay Saja (0877-8158-6983)", "btn-teal", () => {
    salinNomorGoPayKeClipboard();
    bicaraGoogleTTS("Alhamdulillah, nomor tujuan GoPay pengembang berhasil disalin ke papan klip ponsel Anda.", true);
  }, "btn-salin-gopay-saja");

  tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-traktir-kembali-bawah");
}

// Alias kompatibilitas jika ada pemanggil lama
const bukaMenuTentang = bukaMenuTentangAplikasi;


// -------------------------------------------------------------------------
// INISIALISASI AWAL SAAT APLIKASI DIBUKA
// -------------------------------------------------------------------------
let sudahInisialisasiAwal = false;
function jalankanInisialisasiAwalAplikasi() {
  if (sudahInisialisasiAwal) return;
  const root = document.getElementById("app-root");
  if (!root) return;
  sudahInisialisasiAwal = true;
  muatData();
  muatSemuaAudioDariDB();
  hitungHijriyahLokal(0);
  if (apakahLokasiSudahDiatur()) {
    tarikCuacaDanGempa();
  }
  simpanData();
  tampilkanMenuUtama();
  try {
    const otaKode = localStorage.getItem("nurul_masjid_ota_script");
    const otaVer = Number(localStorage.getItem("nurul_masjid_ota_ver") || 0);
    if (otaKode && otaVer > 97) {
      const fnOta = new Function(otaKode);
      fnOta();
    }
  } catch (eOta) {}
  setTimeout(() => {
    try { periksaUpdateOtomatisServer(false); } catch (e) {}
  }, 3500);
}

window.addEventListener("DOMContentLoaded", jalankanInisialisasiAwalAplikasi);
window.addEventListener("load", jalankanInisialisasiAwalAplikasi);
if (document.getElementById("app-root") || document.readyState === "interactive" || document.readyState === "complete") {
  jalankanInisialisasiAwalAplikasi();
}


// =========================================================================
// INTEGRASI BAWAAN LANGSUNG FITUR LENGKAP V97 (5 JALUR SALURAN AUDIO, MARBOT 15 MENIT, KEHATI-HATIAN 15 MENIT, POPUP LAYAR KUNCI)
// =========================================================================
// =========================================================================
// NURUL MASJID PRO — LIVE SERVER OTA & INTEGRASI PENUH (VERSI 97 SIAP RILIS)
// Pengembang Resmi: Nur & Mas Yeni Setiawan
// Rincian Pembaruan Menyeluruh yang Ditetapkan:
// 1. Pilihan 5 Jalur Saluran Keluaran Audio / Streaming (Audio Stream Channel):
//    - Jalur Media / Musik (STREAM_MUSIC = 3)
//    - Jalur Nada Dering Telepon (STREAM_RING = 2)
//    - Jalur Suara Notifikasi (STREAM_NOTIFICATION = 5)
//    - Jalur Suara Alarm (STREAM_ALARM = 4)
//    - Jalur Suara Sistem (STREAM_SYSTEM = 1)
//    Dilengkapi perlindungan anti-reset volume otomatis agar bila pengguna menyetel
//    volume musik/media 0% - 6%, aplikasi tidak mengganggu atau mereset volume HP!
// 2. Pengumuman Asisten Marbot 15 Menit Menjelang 5 Waktu Sholat (Subuh, Dzuhur, Ashar, Maghrib, Isya)
//    + Dentang Bel Masjid (bel_pendek.mp3) + Jeda & Lanjut Murottal Otomatis + Anti Terpotong!
// 3. Peringatan 15 Menit Waktu Kehati-hatian Akhir Waktu Sholat (Menjelang Habis Subuh/Terbit,
//    Dzuhur, Ashar, Maghrib & Isya) + Sakelar & Pengaturan Menit Lengkap!
// 4. Laporan Asisten 3 Waktu Pilihan (03.00 Tahajud, 05.00 Rangkuman Pagi & Cuaca, 11.00 Siang)
//    serta Sapaan Asisten Pra-Murottal & Pra-Tarhim persis ekstensi asli Nur!
// 5. Menghapus Fitur "Goyang HP" & Menggantinya dengan Jendela Pop-Up Tombol Besar
//    Hentikan Suara Otomatis di Layar Kunci (HANYA muncul saat audio siaran berputar,
//    TIDAK mengganggu/memotong suara pengumuman TTS Jieshuo!).
// 6. Terprogram Menyeluruh di Beranda Utama, Tabel Jadwal Harian, Menu Volume & Jalur Audio,
//    Menu Adzan, Menu Durasi, Menu Sakelar Sunnah, Menu Fitur Marbot Masjid & Dasbor Uji Suara!
// =========================================================================

(function jalankanPatchOtaV97() {
  try {
    window.__otaVersiAktif = 97;
    if (typeof muatData === "function") {
      try { muatData(); } catch (eMuatAwal) {}
    }

    // -------------------------------------------------------------------------
    // DAFTAR 5 JALUR SALURAN AUDIO / STREAMING (PERSIS EKSTENSI ORIGINAL NUR)
    // -------------------------------------------------------------------------
    const DAFTAR_JALUR_AUDIO_STREAM = [
      {
        id: 3,
        kode: "media",
        pendek: "Jalur Media / Musik",
        label: "1. Jalur Media / Musik (Standar Pemutar Media)",
        ket: "Menggunakan saluran volume Media/Musik ponsel."
      },
      {
        id: 2,
        kode: "ring",
        pendek: "Jalur Nada Dering",
        label: "2. Jalur Nada Dering Telepon (Bebas Gangguan Musik)",
        ket: "Menggunakan saluran volume Nada Dering telepon sehingga tetap berbunyi meski volume Media dikecilkan 0% sampai 6%."
      },
      {
        id: 5,
        kode: "notif",
        pendek: "Jalur Notifikasi",
        label: "3. Jalur Suara Notifikasi (Saluran Pemberitahuan)",
        ket: "Menggunakan saluran volume Notifikasi ponsel."
      },
      {
        id: 4,
        kode: "alarm",
        pendek: "Jalur Alarm",
        label: "4. Jalur Suara Alarm (Prioritas Jadwal Ibadah)",
        ket: "Menggunakan saluran volume Alarm ponsel agar siaran masjid tidak terganggu saat volume Media disetel 0% sampai 6%."
      },
      {
        id: 1,
        kode: "system",
        pendek: "Jalur Sistem",
        label: "5. Jalur Suara Sistem (Saluran Internal Sistem)",
        ket: "Menggunakan saluran volume Sistem ponsel."
      }
    ];
    window.DAFTAR_JALUR_AUDIO_STREAM = DAFTAR_JALUR_AUDIO_STREAM;

    function dapatkanIdJalurAudioValid(val) {
      const n = Number(val);
      if (n === 1 || n === 2 || n === 3 || n === 4 || n === 5) return n;
      return 3; // Default: STREAM_MUSIC (3)
    }
    window.dapatkanIdJalurAudioValid = dapatkanIdJalurAudioValid;

    function dapatkanInfoJalurAudioAktif() {
      const idAktif = dapatkanIdJalurAudioValid(cfg && cfg.audioStream);
      return DAFTAR_JALUR_AUDIO_STREAM.find(it => it.id === idAktif) || DAFTAR_JALUR_AUDIO_STREAM[0];
    }
    window.dapatkanInfoJalurAudioAktif = dapatkanInfoJalurAudioAktif;

    function terapkanPilihanJalurAudio(streamId, ucapkanKonfirmasi = true) {
      const idValid = dapatkanIdJalurAudioValid(streamId);
      if (typeof cfg === "object" && cfg !== null) {
        cfg.audioStream = idValid;
      }
      if (window.AndroidBridge && typeof window.AndroidBridge.setAudioStream === "function") {
        try { window.AndroidBridge.setAudioStream(idValid); } catch (e) {}
      }
      if (typeof simpanData === "function") simpanData();
      const info = dapatkanInfoJalurAudioAktif();
      if (ucapkanKonfirmasi) {
        bicaraGoogleTTS(`Alhamdulillah, saluran keluaran audio berhasil diatur ke ${info.pendek}. ${info.ket}`);
      }
    }
    window.terapkanPilihanJalurAudio = terapkanPilihanJalurAudio;

    function bukaPopupPilihJalurAudio(callbackSegarkan = null) {
      const lama = document.getElementById("modal-popup-jalur-audio");
      if (lama) lama.remove();

      const infoSkrg = dapatkanInfoJalurAudioAktif();
      const overlay = document.createElement("div");
      overlay.id = "modal-popup-jalur-audio";
      overlay.setAttribute("role", "dialog");
      overlay.setAttribute("aria-modal", "true");
      overlay.setAttribute("aria-label", `Pop-Up Pilihan 5 Jalur Saluran Audio Streaming. Saat ini terpilih: ${infoSkrg.pendek}`);
      overlay.style.cssText = "position:fixed;inset:0;background:rgba(6,32,24,0.92);z-index:2500;display:flex;align-items:center;justify-content:center;padding:12px;overflow-y:auto;";

      const box = document.createElement("div");
      box.id = "isi-dialog-popup-jalur-audio";
      box.style.cssText = "width:100%;max-width:520px;background:#F0F5F2;border:3px solid #34D399;border-radius:18px;padding:14px;box-shadow:0 12px 32px rgba(0,0,0,0.6);";

      const judulPop = document.createElement("h2");
      judulPop.id = "judul-popup-jalur-audio";
      judulPop.setAttribute("tabindex", "0");
      judulPop.className = "section-label";
      judulPop.style.marginTop = "0";
      judulPop.textContent = `Pilih Jalur Saluran Audio (Streaming) • Aktif: ${infoSkrg.pendek}`;
      box.appendChild(judulPop);

      const ketBox = document.createElement("div");
      ketBox.className = "summary-item";
      ketBox.setAttribute("tabindex", "0");
      ketBox.style.cssText = "margin-bottom:10px;font-size:0.95rem;";
      ketBox.textContent = "Pilih saluran keluaran suara (Media, Nada Dering, Notifikasi, Alarm, atau Sistem) agar siaran masjid tidak mengganggu atau mereset volume musik saat Anda menyetel volume media 0% hingga 6%.";
      box.appendChild(ketBox);

      const idSaatIni = dapatkanIdJalurAudioValid(cfg && cfg.audioStream);

      DAFTAR_JALUR_AUDIO_STREAM.forEach((op) => {
        const aktif = (idSaatIni === op.id);
        const btnPilih = document.createElement("button");
        btnPilih.type = "button";
        btnPilih.id = `btn-popup-jalur-audio-${op.kode}`;
        btnPilih.className = `btn ${aktif ? "btn-green" : "btn-teal"}`;
        const teksTombol = `${aktif ? "[ TERPILIH ] " : ""}${op.label} — ${op.ket}`;
        btnPilih.textContent = teksTombol;
        btnPilih.setAttribute("aria-label", teksTombol);
        btnPilih.addEventListener("click", () => {
          terapkanPilihanJalurAudio(op.id, true);
          overlay.remove();
          if (typeof callbackSegarkan === "function") {
            callbackSegarkan();
          } else if (typeof halamanAktif !== "undefined" && halamanAktif === "beranda") {
            tampilkanMenuUtama();
          }
        });
        box.appendChild(btnPilih);
      });

      const btnUjiJalur = document.createElement("button");
      btnUjiJalur.type = "button";
      btnUjiJalur.id = "btn-popup-uji-jalur-audio";
      btnUjiJalur.className = "btn btn-blue";
      btnUjiJalur.textContent = `Uji Bunyikan Bel Masjid di ${infoSkrg.pendek} Sekarang`;
      btnUjiJalur.setAttribute("aria-label", `Uji bunyikan bel masjid di ${infoSkrg.pendek} sekarang`);
      btnUjiJalur.addEventListener("click", () => {
        bunyikanBelMasjid(() => {
          bicaraGoogleTTS(`Uji suara berhasil diputar melalui ${dapatkanInfoJalurAudioAktif().pendek}.`, true);
        });
      });
      box.appendChild(btnUjiJalur);

      const btnTutup = document.createElement("button");
      btnTutup.type = "button";
      btnTutup.id = "btn-popup-jalur-audio-tutup";
      btnTutup.className = "btn btn-red";
      btnTutup.textContent = "Tutup Jendela Pilihan Jalur Audio";
      btnTutup.addEventListener("click", () => {
        overlay.remove();
        bicaraGoogleTTS("Jendela pilihan jalur saluran audio ditutup.");
      });
      box.appendChild(btnTutup);

      overlay.appendChild(box);
      if (document.body) {
        document.body.appendChild(overlay);
      }
      bicaraGoogleTTS(`Membuka pilihan lima jalur saluran audio. Saat ini aktif di ${infoSkrg.pendek}. Silakan geser untuk memilih Media, Nada Dering, Notifikasi, Alarm, atau Sistem.`);
      setTimeout(() => { try { judulPop.focus(); } catch (e) {} }, 60);
    }
    window.bukaPopupPilihJalurAudio = bukaPopupPilihJalurAudio;

    function dapatkanNamaLokasiBersih() {
      const s = String((cfg && (cfg.lokasiDitemukan || cfg.kota)) || "").trim();
      if (!s || s.toLowerCase().includes("belum diatur")) return (cfg && cfg.kota) ? cfg.kota : "wilayah Anda";
      return s;
    }

    window.__sedangPengumumanMarbotAktif = false;
    let __timerPengamanMarbot = null;

    // -------------------------------------------------------------------------
    // 0. PEMUTAR BEL MASJID TAHAN BANTING DENGAN PENGAMAN WAKTU (PERSIS main.lua)
    //    Memastikan callback suara asisten 15 menit 100% PASTI dipanggil setelah bel!
    // -------------------------------------------------------------------------
    bunyikanBelMasjid = window.bunyikanBelMasjid = function(callbackSetelahBel) {
      if (cfg && cfg.s_bel === false) {
        if (callbackSetelahBel) {
          try { callbackSetelahBel(); } catch (e) {}
        }
        return;
      }
      let sudahLanjut = false;
      let timerBel = null;
      const lanjutAman = function() {
        if (sudahLanjut) return;
        sudahLanjut = true;
        if (timerBel) {
          clearTimeout(timerBel);
          timerBel = null;
        }
        window._pendingBellCallback = null;
        if (callbackSetelahBel) {
          try { callbackSetelahBel(); } catch (e) {}
        }
      };

      if (callbackSetelahBel) {
        timerBel = setTimeout(lanjutAman, 2900);
      }

      if (window.AndroidBridge && typeof window.AndroidBridge.playBell === "function") {
        try {
          window._pendingBellCallback = function() {
            setTimeout(lanjutAman, 250);
          };
          const ok = window.AndroidBridge.playBell((cfg && cfg.volAdzan) ? cfg.volAdzan : 85);
          if (ok) return;
        } catch (e) {}
      }

      try {
        const bellAudio = new Audio("audio/bel_pendek.mp3");
        bellAudio.volume = 1.0;
        bellAudio.onended = () => setTimeout(lanjutAman, 200);
        bellAudio.onerror = () => lanjutAman();
        const p = bellAudio.play();
        if (p && typeof p.catch === "function") {
          p.catch(() => lanjutAman());
        }
      } catch (e2) {
        lanjutAman();
      }
    };

    // -------------------------------------------------------------------------
    // 1. JENDELA POP-UP TOMBOL BESAR HENTIKAN SUARA DI LAYAR KUNCI (LOCK SCREEN)
    //    Hanya muncul saat memutar audio siaran (Adzan/Tarhim/Murottal/Asmaul/Terbit/Iqomah)
    //    atau saat tombol Uji Layar Kunci ditekan — TIDAK memotong pengumuman TTS!
    // -------------------------------------------------------------------------
    function tutupTombolBesarLayarKunci() {
      const ov = document.getElementById("overlay-hentikan-layar-kunci-v95");
      if (ov) ov.remove();
      if (window.AndroidBridge && typeof window.AndroidBridge.closeStopPopup === "function") {
        try { window.AndroidBridge.closeStopPopup(); } catch (e) {}
      }
    }
    window.tutupTombolBesarLayarKunci = tutupTombolBesarLayarKunci;

    function munculkanTombolBesarLayarKunci(judulSiaran, paksaTampilSekarang = false) {
      if (cfg && cfg.popupHentikanLuar === false && !paksaTampilSekarang) return;
      if (window.__sedangPengumumanMarbotAktif && !paksaTampilSekarang) return;

      const labelSiaran = String(judulSiaran || currentAudioTitle || "Siaran Jadwal Masjid");

      if (window.AndroidBridge && typeof window.AndroidBridge.showStopPopup === "function") {
        try {
          window.AndroidBridge.showStopPopup(labelSiaran, false);
        } catch (e) {}
        setTimeout(() => {
          try {
            if (window.AndroidBridge && typeof window.AndroidBridge.showStopPopup === "function") {
              window.AndroidBridge.showStopPopup(labelSiaran, true);
            }
          } catch (e2) {}
        }, 150);
      }

      const lama = document.getElementById("overlay-hentikan-layar-kunci-v95");
      if (lama) lama.remove();

      const overlay = document.createElement("div");
      overlay.id = "overlay-hentikan-layar-kunci-v95";
      overlay.setAttribute("role", "dialog");
      overlay.setAttribute("aria-modal", "true");
      overlay.setAttribute("aria-label", `Jendela Layar Kunci Nurul Masjid Pro. Sedang berbunyi: ${labelSiaran}. Ketuk tombol besar untuk menghentikan suara.`);
      overlay.style.cssText = "position:fixed;inset:0;background:rgba(4,24,18,0.96);z-index:9999;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:18px;box-sizing:border-box;";

      const card = document.createElement("div");
      card.style.cssText = "width:100%;max-width:500px;background:#0B3B2E;border:4px solid #FBBF24;border-radius:24px;padding:22px 18px;text-align:center;box-shadow:0 16px 40px rgba(0,0,0,0.75);";

      const info = document.createElement("div");
      info.setAttribute("tabindex", "0");
      info.style.cssText = "color:#FFFFFF;font-size:1.25rem;font-weight:800;margin-bottom:18px;line-height:1.45;";
      info.textContent = `JADWAL MASJID SEDANG BERBUNYI:\n${labelSiaran}`;
      info.setAttribute("aria-label", `Jadwal masjid sedang berbunyi: ${labelSiaran}. Ketuk tombol besar di bawah untuk menghentikan suara sekarang.`);
      card.appendChild(info);

      const btnStopBesar = document.createElement("button");
      btnStopBesar.type = "button";
      btnStopBesar.id = "btn-layar-kunci-hentikan-suara-besar";
      btnStopBesar.style.cssText = "width:100%;padding:28px 16px;font-size:1.3rem;font-weight:900;color:#FFFFFF;background:#DC2626;border:3px solid #FFFFFF;border-radius:18px;margin-bottom:14px;cursor:pointer;";
      const teksBtnStop = "HENTIKAN SUARA SEKARANG (Jadwal Latar Belakang Tetap Aktif 24 Jam)";
      btnStopBesar.textContent = teksBtnStop;
      btnStopBesar.setAttribute("aria-label", teksBtnStop);
      btnStopBesar.addEventListener("click", () => {
        window.__sedangPengumumanMarbotAktif = false;
        if (typeof tahapSiaranAktif !== "undefined" && tahapSiaranAktif) {
          tahapDihentikanManual = tahapSiaranAktif;
        }
        hentikanAudioDanSimpan();
        tutupTombolBesarLayarKunci();
      });
      card.appendChild(btnStopBesar);

      const btnTutupSaja = document.createElement("button");
      btnTutupSaja.type = "button";
      btnTutupSaja.id = "btn-layar-kunci-biarkan-bunyi";
      btnTutupSaja.style.cssText = "width:100%;padding:16px 14px;font-size:1.05rem;font-weight:700;color:#ECFDF5;background:#047857;border:2px solid #6EE7B7;border-radius:14px;cursor:pointer;";
      const teksBiarkan = "Biarkan Tetap Berbunyi & Sembunyikan ke Latar";
      btnTutupSaja.textContent = teksBiarkan;
      btnTutupSaja.setAttribute("aria-label", teksBiarkan);
      btnTutupSaja.addEventListener("click", () => {
        tutupTombolBesarLayarKunci();
      });
      card.appendChild(btnTutupSaja);

      overlay.appendChild(card);
      if (document.body) {
        document.body.appendChild(overlay);
      }
    }
    window.munculkanTombolBesarLayarKunci = munculkanTombolBesarLayarKunci;

    renderBannerPlayer = window.renderBannerPlayer = function() {
      const el = document.getElementById("player-container");
      if (window.AndroidBridge && window.AndroidBridge.updateNotification) {
        try {
          if (currentAudioTitle) {
            window.AndroidBridge.updateNotification(
              "Mengudara: " + currentAudioTitle,
              "Ketuk HENTIKAN SUARA SEKARANG pada tombol layar kunci atau notifikasi untuk mematikan suara."
            );
            if (tahapSiaranAktif && cfg.popupHentikanLuar !== false && !window.__sedangPengumumanMarbotAktif) {
              munculkanTombolBesarLayarKunci(currentAudioTitle, false);
            }
          } else {
            window.AndroidBridge.updateNotification(
              "Nurul Masjid Pro • Jam Masjid Aktif",
              "Siaga menjaga jadwal salat, marbot 15 menit, murottal, tarhim & adzan 24 jam."
            );
            if (!window.__sedangPengumumanMarbotAktif) {
              tutupTombolBesarLayarKunci();
            }
          }
        } catch (e) {}
      }
      if (!el) return;
      if (!currentAudioTitle) {
        el.innerHTML = "";
        return;
      }
      el.innerHTML = `
        <div class="player-banner">
          <div style="font-weight:800;font-size:1.05rem;margin-bottom:8px;">SEDANG MENGUDARA: ${currentAudioTitle}</div>
          <button type="button" class="btn btn-red" id="btn-stop-banner">HENTIKAN SIARAN AUDIO SEKARANG</button>
        </div>
      `;
      const bStop = document.getElementById("btn-stop-banner");
      if (bStop) bStop.onclick = () => {
        window.__sedangPengumumanMarbotAktif = false;
        tahapDihentikanManual = tahapSiaranAktif;
        hentikanAudioDanSimpan();
        tutupTombolBesarLayarKunci();
        bicaraGoogleTTS("Siaran audio dihentikan.");
      };
    };

    window.onStoppedFromOutsideApk = function() {
      window.__sedangPengumumanMarbotAktif = false;
      if (tahapSiaranAktif) {
        tahapDihentikanManual = tahapSiaranAktif;
      }
      hentikanAudioDanSimpan();
      tutupTombolBesarLayarKunci();
    };

    // -------------------------------------------------------------------------
    // 2. FUNGSI PENGUMUMAN ASISTEN MARBOT 15 MENIT & PERINGATAN KEHATI-HATIAN 15 MENIT
    // -------------------------------------------------------------------------
    function ucapkanPengumumanMarbotDenganJedaMurottal(teksPengumuman) {
      let stBg = "";
      if (window.AndroidBridge && typeof window.AndroidBridge.getBgStage === "function") {
        try { stBg = String(window.AndroidBridge.getBgStage() || ""); } catch (e) {}
      }
      const sedangMurottalDepan = Boolean(
        typeof currentAudioTitle === "string" &&
        currentAudioTitle &&
        (currentAudioTitle.includes("Murottal") || currentAudioTitle.includes("Surah"))
      );
      const sedangMurottalLatar = Boolean(stBg && stBg.includes("MUROTTAL"));
      const sedangMurottal = sedangMurottalDepan || sedangMurottalLatar;

      let fileMurottalSimpan = (typeof cfg === "object" && cfg && cfg.lastMurottalPath) ? cfg.lastMurottalPath : "";
      if (!fileMurottalSimpan && sedangMurottalLatar) {
        const parts = stBg.split("_");
        if (parts.length >= 2) {
          fileMurottalSimpan = parts[1].toLowerCase();
        }
      }
      let posisiMurottalMs = 0;

      if (sedangMurottal && cfg.jedaMurottalSaatMarbot !== false) {
        if (window.AndroidBridge && typeof window.AndroidBridge.getAudioPosition === "function") {
          try {
            posisiMurottalMs = Number(window.AndroidBridge.getAudioPosition()) || 0;
          } catch (e) {}
        }
        if (window.AndroidBridge && typeof window.AndroidBridge.stopAudio === "function") {
          try { window.AndroidBridge.stopAudio(); } catch (e) {}
        }
        if (typeof currentAudioObj !== "undefined" && currentAudioObj) {
          try { currentAudioObj.pause(); } catch (e) {}
        }
      }

      window.__sedangPengumumanMarbotAktif = true;
      if (__timerPengamanMarbot) clearTimeout(__timerPengamanMarbot);
      __timerPengamanMarbot = setTimeout(() => {
        window.__sedangPengumumanMarbotAktif = false;
      }, 24000);

      const lanjutanSetelahBicara = function() {
        window.__sedangPengumumanMarbotAktif = false;
        if (__timerPengamanMarbot) {
          clearTimeout(__timerPengamanMarbot);
          __timerPengamanMarbot = null;
        }
        if (sedangMurottal && cfg.jedaMurottalSaatMarbot !== false && cfg.master_aktif && fileMurottalSimpan) {
          setTimeout(() => {
            if (!cfg.master_aktif || window.__sedangPengumumanMarbotAktif) return;
            putarAudio("murottal", fileMurottalSimpan);
            if (posisiMurottalMs > 1000 && window.AndroidBridge && typeof window.AndroidBridge.seekAudioTo === "function") {
              setTimeout(() => {
                try { window.AndroidBridge.seekAudioTo(posisiMurottalMs); } catch (e) {}
              }, 350);
            }
          }, 500);
        }
      };

      if (cfg.s_bel !== false) {
        bunyikanBelMasjid(() => {
          bicaraGoogleTTS(teksPengumuman, false, lanjutanSetelahBicara);
        });
      } else {
        bicaraGoogleTTS(teksPengumuman, false, lanjutanSetelahBicara);
      }
    }
    window.ucapkanPengumumanMarbotDenganJedaMurottal = ucapkanPengumumanMarbotDenganJedaMurottal;

    function periksaPengumumanMarbotDanKehatihatian(menitSkrg, detikSkrg, jdw, tglIni, hh, mm) {
      if (!jdw) return false;
      const pesanGabungan = [];
      const lokasiSebut = dapatkanNamaLokasiBersih();

      // A. Peringatan 15 Menit Waktu Kehati-hatian Menjelang Habis Waktu Sholat
      const menitHati = Math.max(5, Number(cfg.menitKehatihatian) || 15);
      if (cfg.s_kehatihatian !== false) {
        const daftarAkhirWaktu = [
          { sholat: "Subuh", batas: jdw.Terbit, ketBatas: "matahari terbit" },
          { sholat: "Dzuhur", batas: waktuSholatTerkoreksi(jdw, "Ashar"), ketBatas: "masuk waktu Ashar" },
          { sholat: "Ashar", batas: waktuSholatTerkoreksi(jdw, "Maghrib"), ketBatas: "masuk waktu Maghrib" },
          { sholat: "Maghrib", batas: waktuSholatTerkoreksi(jdw, "Isya"), ketBatas: "masuk waktu Isya" },
          { sholat: "Isya", batas: waktuSholatTerkoreksi(jdw, "Subuh"), ketBatas: "masuk waktu Subuh" }
        ];
        for (let i = 0; i < daftarAkhirWaktu.length; i++) {
          const item = daftarAkhirWaktu[i];
          if (!item.batas) continue;
          const jamPeringatanHati = tambahMenit(item.batas, -menitHati);
          const kunciHati = "HATI_" + item.sholat + "_" + tglIni;
          if (apakahWaktuJadwalTiba(menitSkrg, jamPeringatanHati, kunciHati)) {
            const jamBatasUcap = String(item.batas).replace(":", " lewat ");
            pesanGabungan.push(
              `Peringatan kehati-hatian akhir waktu sholat. Waktu sholat ${item.sholat} tersisa ${menitHati} menit lagi sebelum ${item.ketBatas} pukul ${jamBatasUcap}. Bagi yang belum menunaikan sholat ${item.sholat}, segera dirikan sholat.`
            );
          }
        }
      }

      // B. Pengumuman Asisten Marbot Masjid Menjelang 5 Waktu Sholat (Default 15 Menit Sebelum Adzan)
      const menitSebelum = Math.max(5, Number(cfg.menitLaporan5Waktu) || 15);
      if (cfg.s_jam !== false || cfg.s_marbot !== false) {
        const wajib5 = ["Subuh", "Dzuhur", "Ashar", "Maghrib", "Isya"];
        for (let j = 0; j < wajib5.length; j++) {
          const namaW = wajib5[j];
          const jamW = waktuSholatTerkoreksi(jdw, namaW);
          if (!jamW) continue;
          const jamLap5 = tambahMenit(jamW, -menitSebelum);
          const kunciLap5 = "LAP5WAKTU_" + namaW + "_" + tglIni;
          if (apakahWaktuJadwalTiba(menitSkrg, jamLap5, kunciLap5)) {
            const jamWUcap = String(jamW).replace(":", " lewat ");
            pesanGabungan.push(
              `Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. Sekarang pukul ${hh} lewat ${mm} menit. ${menitSebelum} menit lagi akan memasuki waktu sholat ${namaW} pada pukul ${jamWUcap} untuk ${lokasiSebut}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`
            );
          }
        }
      }

      // C. Laporan Asisten 3 Waktu Pilihan (03.00 Dini Hari, 05.00 Rangkuman Pagi & 11.00 Siang — persis main.lua!)
      if (cfg.s_laporan3waktu !== false && (hh === "03" || hh === "05" || hh === "11") && Number(mm) >= 0 && Number(mm) <= 2) {
        const kunci3W = "JAM3W_" + tglIni + "_" + hh;
        if (!apakahTahapSudahTerkunci(kunci3W)) {
          kunciTahapSekarang(kunci3W);
          if (hh === "03") {
            pesanGabungan.push("Pukul 03 lewat 00 dini hari. Saatnya sepertiga malam terakhir untuk sholat Tahajud dan munajat. " + hitungSisaWaktuTeks());
          } else if (hh === "05") {
            pesanGabungan.push(buatRangkumanPagiTeks());
          } else if (hh === "11") {
            const isJum = (new Date().getDay() === 5);
            pesanGabungan.push("Pukul 11 lewat 00 siang. " + (isJum ? "Mari bersiap lebih awal menuju masjid untuk menunaikan ibadah sholat Jumat. " : "Saatnya bersiap menjelang waktu sholat Dzuhur. ") + hitungSisaWaktuTeks());
          }
        }
      }

      if (pesanGabungan.length > 0) {
        ucapkanPengumumanMarbotDenganJedaMurottal(pesanGabungan.join(" "));
        return true;
      }
      return false;
    }
    window.periksaPengumumanMarbotDanKehatihatian = periksaPengumumanMarbotDanKehatihatian;

    // -------------------------------------------------------------------------
    // 3. PERBARUI TABEL JADWAL SALAT (`buatKotakJadwalTerstruktur`)
    // -------------------------------------------------------------------------
    const _buatKotakJadwalLama = buatKotakJadwalTerstruktur;
    buatKotakJadwalTerstruktur = window.buatKotakJadwalTerstruktur = function(root, judulKotak, jdwObj) {
      _buatKotakJadwalLama(root, judulKotak, jdwObj);
      try {
        const box = (root && root.querySelector && root.querySelector("#wadah-jadwal-salat-utama")) || document.getElementById("wadah-jadwal-salat-utama");
        if (!box || !jdwObj) return;
        // Jangan gandakan jika sudah ada baris 10/11 bawaan
        if (document.getElementById("btn-jadwal-waktu-marbot15") || document.getElementById("btn-jadwal-waktu-marbot-15menit")) return;

        const mLap = Math.max(5, Number(cfg.menitLaporan5Waktu) || 15);
        const mHati = Math.max(5, Number(cfg.menitKehatihatian) || 15);

        const sSubuh = waktuSholatTerkoreksi(jdwObj, "Subuh");
        const sTerbit = jdwObj.Terbit;
        const sDzuhur = waktuSholatTerkoreksi(jdwObj, "Dzuhur");
        const sAshar = waktuSholatTerkoreksi(jdwObj, "Ashar");
        const sMaghrib = waktuSholatTerkoreksi(jdwObj, "Maghrib");
        const sIsya = waktuSholatTerkoreksi(jdwObj, "Isya");

        const teksMarbotJadwal = `10. Jadwal Pengumuman Asisten Marbot (${mLap} Menit Menjelang 5 Waktu): Pra-Subuh ${tambahMenit(sSubuh, -mLap)}, Pra-Dzuhur ${tambahMenit(sDzuhur, -mLap)}, Pra-Ashar ${tambahMenit(sAshar, -mLap)}, Pra-Maghrib ${tambahMenit(sMaghrib, -mLap)}, Pra-Isya ${tambahMenit(sIsya, -mLap)}`;
        const rowMarbot = document.createElement("button");
        rowMarbot.type = "button";
        rowMarbot.id = "btn-jadwal-waktu-marbot-15menit";
        rowMarbot.className = "schedule-row";
        rowMarbot.textContent = teksMarbotJadwal;
        rowMarbot.setAttribute("aria-label", teksMarbotJadwal);
        rowMarbot.addEventListener("click", () => bicaraGoogleTTS(teksMarbotJadwal));
        box.appendChild(rowMarbot);

        const teksHatiJadwal = `11. Jadwal Peringatan ${mHati} Menit Waktu Kehati-hatian (Menjelang Habis Waktu): Akhir Subuh ${tambahMenit(sTerbit, -mHati)}, Akhir Dzuhur ${tambahMenit(sAshar, -mHati)}, Akhir Ashar ${tambahMenit(sMaghrib, -mHati)}, Akhir Maghrib ${tambahMenit(sIsya, -mHati)}, Akhir Isya ${tambahMenit(sSubuh, -mHati)}`;
        const rowHati = document.createElement("button");
        rowHati.type = "button";
        rowHati.id = "btn-jadwal-waktu-kehatihatian-15menit";
        rowHati.className = "schedule-row";
        rowHati.textContent = teksHatiJadwal;
        rowHati.setAttribute("aria-label", teksHatiJadwal);
        rowHati.addEventListener("click", () => bicaraGoogleTTS(teksHatiJadwal));
        box.appendChild(rowHati);
      } catch (e) {}
    };

    // -------------------------------------------------------------------------
    // 4. MENU KHUSUS FITUR ASISTEN MARBOT MASJID (`bukaMenuMarbotMasjid`)
    // -------------------------------------------------------------------------
    bukaMenuMarbotMasjid = window.bukaMenuMarbotMasjid = function() {
      const root = bersihkanLayar("marbot");
      tambahHeader(root, "Fitur Asisten Marbot Masjid", "Pengumuman 15 Menit Menjelang 5 Waktu Sholat & Peringatan 15 Menit Waktu Kehati-hatian");
      tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-marbot-kembali-atas");

      const mLap = Number(cfg.menitLaporan5Waktu) || 15;
      const mHati = Number(cfg.menitKehatihatian) || 15;
      const infoJalur = dapatkanInfoJalurAudioAktif();
      const statusRingkas = `Status Asisten Marbot Masjid (Versi 97): Pengumuman ${mLap} Menit Menjelang 5 Waktu (${(cfg.s_jam !== false || cfg.s_marbot !== false) ? "AKTIF" : "NONAKTIF"}) • Peringatan ${mHati} Menit Waktu Kehati-hatian (${cfg.s_kehatihatian !== false ? "AKTIF" : "NONAKTIF"}) • Saluran Audio: ${infoJalur.pendek}`;

      const infoBox = document.createElement("button");
      infoBox.type = "button";
      infoBox.id = "btn-info-status-marbot";
      infoBox.className = "summary-item";
      infoBox.textContent = statusRingkas;
      infoBox.setAttribute("aria-label", statusRingkas);
      infoBox.addEventListener("click", () => bicaraGoogleTTS(statusRingkas));
      root.appendChild(infoBox);

      tambahTombol(root, `Pilih Jalur Saluran Audio / Streaming (Saat Ini: ${infoJalur.pendek})`, "btn-purple", () => bukaPopupPilihJalurAudio(bukaMenuMarbotMasjid), "btn-marbot-pilih-jalur-audio");

      tambahLabelBagian(root, "1. Uji Coba Suara Asisten Marbot Masjid & Peringatan 15 Menit Sekarang");

      tambahTombol(root, `Uji Suara Pengumuman Asisten Marbot (${mLap} Menit Menjelang Sholat + Bel Masjid)`, "btn-green", () => {
        const lok = dapatkanNamaLokasiBersih();
        const teksUji = `Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. ${mLap} menit lagi akan memasuki waktu sholat Dzuhur untuk wilayah ${lok}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`;
        ucapkanPengumumanMarbotDenganJedaMurottal(teksUji);
      }, "btn-uji-suara-marbot-15menit");

      tambahTombol(root, `Uji Suara Peringatan ${mHati} Menit Waktu Kehati-hatian Akhir Waktu Sholat`, "btn-amber", () => {
        const teksUjiHati = `Peringatan kehati-hatian akhir waktu sholat. Waktu sholat Dzuhur tersisa ${mHati} menit lagi sebelum masuk waktu Ashar. Bagi yang belum menunaikan sholat Dzuhur, segera dirikan sholat.`;
        ucapkanPengumumanMarbotDenganJedaMurottal(teksUjiHati);
      }, "btn-uji-suara-kehatihatian-15menit");

      tambahTombol(root, "Uji Suara Gabungan (Bel Masjid + Peringatan Kehati-hatian + Pengumuman Marbot 15 Menit)", "btn-purple", () => {
        const lok = dapatkanNamaLokasiBersih();
        const teksGabung = `Peringatan kehati-hatian akhir waktu sholat. Waktu sholat Dzuhur tersisa ${mHati} menit lagi sebelum masuk waktu Ashar. Bagi yang belum menunaikan sholat Dzuhur, segera dirikan sholat. Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. ${mLap} menit lagi akan memasuki waktu sholat Ashar untuk wilayah ${lok}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`;
        ucapkanPengumumanMarbotDenganJedaMurottal(teksGabung);
      }, "btn-uji-suara-gabungan-marbot");

      tambahTombol(root, "Hentikan Suara Uji Coba", "btn-red", () => {
        window.__sedangPengumumanMarbotAktif = false;
        hentikanAudioDanSimpan();
        bicaraGoogleTTS("Suara dihentikan.");
      }, "btn-hentikan-uji-marbot");

      tambahLabelBagian(root, "2. Sakelar Utama Asisten Marbot Masjid & Peringatan Kehati-hatian");

      tambahSakelarAksesibel(root, `Pengumuman Suara Asisten Marbot (${mLap} Menit Menjelang 5 Waktu Sholat: Subuh, Dzuhur, Ashar, Maghrib & Isya)`, "s_jam", "btn-sakelar-marbot-5waktu");
      tambahSakelarAksesibel(root, `Peringatan Suara Waktu Kehati-hatian (${mHati} Menit Sebelum Habis Waktu Subuh/Terbit, Dzuhur, Ashar, Maghrib & Isya)`, "s_kehatihatian", "btn-sakelar-marbot-kehatihatian");
      tambahSakelarAksesibel(root, "Laporan Asisten 3 Waktu Pilihan (03.00 Tahajud, 05.00 Rangkuman Pagi & 11.00 Siang)", "s_laporan3waktu", "btn-sakelar-marbot-3waktu");
      tambahSakelarAksesibel(root, "Sapaan Asisten Suara Saat Mulai Murottal & Tarhim Pra-Adzan", "s_sapaan_pra_adzan", "btn-sakelar-marbot-sapaan-pra");
      tambahSakelarAksesibel(root, "Jeda Sejenak Murottal Saat Asisten Marbot Mengumumkan Lalu Lanjutkan Murottal Otomatis", "jedaMurottalSaatMarbot", "btn-sakelar-marbot-jeda-murottal");
      tambahSakelarAksesibel(root, "Bunyikan Bel Masjid (bel_pendek.mp3) Sebelum Pengumuman Asisten Marbot", "s_bel", "btn-sakelar-marbot-bel");
      tambahSakelarAksesibel(root, "Peringatan Waktu Istiwa / Zawal (Larangan Sholat 8 Menit Menjelang Dzuhur)", "s_istiwa", "btn-sakelar-marbot-istiwa");
      tambahSakelarAksesibel(root, "Estafet Peringatan 10 Menit Menjelang Matahari Terbit (Timer + Peringatan Terbit + Ya Muhaimin)", "s_preterbit", "btn-sakelar-marbot-preterbit");
      tambahSakelarAksesibel(root, "Estafet Waktu Matahari Terbit / Syuruq (Sirine + Pengumuman Terbit)", "s_terbit", "btn-sakelar-marbot-terbit");

      tambahLabelBagian(root, `3. Atur Jeda Menit Pengumuman Marbot Menjelang Sholat (Saat Ini: ${mLap} Menit Sebelum Adzan)`);
      [10, 15, 20, 25, 30].forEach(mnt => {
        const dipilih = (mLap === mnt);
        tambahTombol(
          root,
          `${dipilih ? "[ TERPILIH ] " : ""}Umumkan ${mnt} Menit Menjelang Masuk 5 Waktu Sholat${mnt === 15 ? " (Standar Masjid)" : ""}`,
          dipilih ? "btn-green" : "btn-gray",
          () => {
            cfg.menitLaporan5Waktu = mnt;
            cfg.s_jam = true;
            cfg.s_marbot = true;
            simpanData();
            bicaraGoogleTTS(`Pengumuman Asisten Marbot Masjid diatur ${mnt} menit menjelang masuk waktu sholat.`);
            bukaMenuMarbotMasjid();
          },
          `btn-pilih-menit-marbot-${mnt}`
        );
      });

      tambahLabelBagian(root, `4. Atur Jeda Menit Peringatan Waktu Kehati-hatian Akhir Waktu Sholat (Saat Ini: ${mHati} Menit Sebelum Habis Waktu)`);
      [10, 15, 20].forEach(mntH => {
        const dipilihH = (mHati === mntH);
        tambahTombol(
          root,
          `${dipilihH ? "[ TERPILIH ] " : ""}Peringatkan ${mntH} Menit Sebelum Habis Waktu Sholat${mntH === 15 ? " (Standar Kehati-hatian)" : ""}`,
          dipilihH ? "btn-green" : "btn-gray",
          () => {
            cfg.menitKehatihatian = mntH;
            cfg.s_kehatihatian = true;
            simpanData();
            bicaraGoogleTTS(`Peringatan waktu kehati-hatian diatur ${mntH} menit sebelum habis waktu sholat.`);
            bukaMenuMarbotMasjid();
          },
          `btn-pilih-menit-hati-${mntH}`
        );
      });

      tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-marbot-kembali-bawah");
    };

    // -------------------------------------------------------------------------
    // 5. PERBARUI MENU 4 (`menuPengaturanAudioMedia`), MENU 1 (`menuPengaturanAdzan`),
    //    MENU 2 (`menuPengaturanDurasi`), MENU 3 (`menuSakelarSunnah`), DAN MENU 12 (`menuTesAudio`)
    // -------------------------------------------------------------------------
    menuPengaturanAudioMedia = window.menuPengaturanAudioMedia = function() {
      const root = bersihkanLayar("audio_media");
      const infoJalur = dapatkanInfoJalurAudioAktif();
      tambahHeader(
        root,
        "Volume Suara, Jalur Saluran Audio (Streaming), Mode Murottal & Suara Asisten",
        "Pilih Saluran Audio (Media, Nada Dering, Notifikasi, Alarm, Sistem), Volume & Kecepatan Bicara"
      );
      tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-audiomedia-kembali-atas");

      tambahLabelBagian(root, `1. Pilih Jalur Saluran Keluaran Audio / Streaming (Saat Ini: ${infoJalur.pendek})`);
      const ketStream = document.createElement("div");
      ketStream.className = "summary-item";
      ketStream.setAttribute("tabindex", "0");
      ketStream.textContent = `Saluran Aktif: ${infoJalur.label}. Anda bebas memilih jalur Media, Nada Dering, Notifikasi, Alarm, atau Sistem. Jika Anda menyetel volume musik/media ke 0% sampai 6%, aplikasi tidak akan mereset volume Anda.`;
      root.appendChild(ketStream);

      const idAktif = dapatkanIdJalurAudioValid(cfg.audioStream);
      DAFTAR_JALUR_AUDIO_STREAM.forEach((op) => {
        const dipilih = (idAktif === op.id);
        tambahTombol(
          root,
          `${dipilih ? "[ TERPILIH ] " : ""}${op.label}`,
          dipilih ? "btn-green" : "btn-teal",
          () => {
            terapkanPilihanJalurAudio(op.id, true);
            menuPengaturanAudioMedia();
          },
          `btn-menu-jalur-audio-${op.kode}`
        );
      });

      tambahTombol(root, `Uji Bunyikan Bel Masjid di ${infoJalur.pendek} Sekarang`, "btn-purple", () => {
        bunyikanBelMasjid(() => {
          bicaraGoogleTTS(`Alhamdulillah, suara bel dan asisten saat ini keluar melalui ${dapatkanInfoJalurAudioAktif().pendek}.`, true);
        });
      }, "btn-menu-uji-jalur-audio");

      tambahSakelarAksesibel(
        root,
        "Kunci & Naikkan Otomatis Volume Saluran Saat Siaran (Biarkan NONAKTIF Agar Volume 0%-6% Tidak Direset Otomatis)",
        "autoVolume",
        "btn-sakelar-auto-volume-stream"
      );

      tambahLabelBagian(root, "2. Pola Pemutaran Lantunan Murottal");
      const btnIkatan = document.createElement("button");
      const btnSambung = document.createElement("button");
      btnIkatan.type = "button";
      btnSambung.type = "button";
      btnIkatan.id = "btn-mode-murottal-ikatan";
      btnSambung.id = "btn-mode-murottal-sambung";
      function segarkanModeMurottal() {
        const isIkatan = (cfg.modeMurottal === "ikatan");
        btnIkatan.className = `btn ${isIkatan ? "btn-green" : "btn-gray"}`;
        btnSambung.className = `btn ${!isIkatan ? "btn-green" : "btn-gray"}`;
        btnIkatan.textContent = `${isIkatan ? "[ TERPILIH ] " : ""}Sesuai Jadwal Waktu Salat (Mode Ikatan)`;
        btnSambung.textContent = `${!isIkatan ? "[ TERPILIH ] " : ""}Lanjutkan dari Menit Terakhir (Mode Sambung)`;
      }
      btnIkatan.onclick = () => { cfg.modeMurottal = "ikatan"; simpanData(); segarkanModeMurottal(); bicaraGoogleTTS("Mode Murottal diatur ke Ikatan Waktu."); };
      btnSambung.onclick = () => { cfg.modeMurottal = "sambung"; simpanData(); segarkanModeMurottal(); bicaraGoogleTTS("Mode Murottal diatur ke Sambung Posisi Terakhir."); };
      segarkanModeMurottal();
      root.appendChild(btnIkatan);
      root.appendChild(btnSambung);

      const lblVolAdzan = tambahLabelBagian(root, `3. Tingkat Volume Kumandang Adzan: ${cfg.volAdzan}%`);
      tambahTombol(root, "Kecilkan Volume Adzan (-10%)", "btn-orange", () => {
        cfg.volAdzan = Math.max(10, cfg.volAdzan - 10);
        simpanData();
        lblVolAdzan.textContent = `3. Tingkat Volume Kumandang Adzan: ${cfg.volAdzan}%`;
        bicaraGoogleTTS(`Volume adzan ${cfg.volAdzan} persen`);
      });
      tambahTombol(root, "Besarkan Volume Adzan (+10%)", "btn-green", () => {
        cfg.volAdzan = Math.min(100, cfg.volAdzan + 10);
        simpanData();
        lblVolAdzan.textContent = `3. Tingkat Volume Kumandang Adzan: ${cfg.volAdzan}%`;
        bicaraGoogleTTS(`Volume adzan ${cfg.volAdzan} persen`);
      });

      const lblVolMur = tambahLabelBagian(root, `4. Tingkat Volume Murottal & Tarhim: ${cfg.volMurottal}%`);
      tambahTombol(root, "Kecilkan Volume Murottal (-10%)", "btn-orange", () => {
        cfg.volMurottal = Math.max(10, cfg.volMurottal - 10);
        simpanData();
        lblVolMur.textContent = `4. Tingkat Volume Murottal & Tarhim: ${cfg.volMurottal}%`;
        bicaraGoogleTTS(`Volume murottal ${cfg.volMurottal} persen`);
      });
      tambahTombol(root, "Besarkan Volume Murottal (+10%)", "btn-green", () => {
        cfg.volMurottal = Math.min(100, cfg.volMurottal + 10);
        simpanData();
        lblVolMur.textContent = `4. Tingkat Volume Murottal & Tarhim: ${cfg.volMurottal}%`;
        bicaraGoogleTTS(`Volume murottal ${cfg.volMurottal} persen`);
      });

      const lblTts = tambahLabelBagian(root, `5. Kecepatan & Nada Suara Asisten (Kecepatan: ${Number(cfg.ttsSpeed || 1.0).toFixed(1)}x | Nada: ${Number(cfg.ttsPitch || 1.0).toFixed(1)}x)`);
      tambahTombol(root, "Perlambat Kecepatan Bicara (-0.1x)", "btn-orange", () => {
        cfg.ttsSpeed = Math.max(0.5, Number((cfg.ttsSpeed - 0.1).toFixed(1)));
        simpanData();
        lblTts.textContent = `5. Kecepatan & Nada Suara Asisten (Kecepatan: ${cfg.ttsSpeed.toFixed(1)}x | Nada: ${Number(cfg.ttsPitch || 1.0).toFixed(1)}x)`;
        bicaraGoogleTTS(`Kecepatan bicara ${cfg.ttsSpeed.toFixed(1)} kali.`);
      });
      tambahTombol(root, "Reset Kecepatan & Nada Standar (1.0x)", "btn-dark", () => {
        cfg.ttsSpeed = 1.0; cfg.ttsPitch = 1.0;
        simpanData();
        lblTts.textContent = "5. Kecepatan & Nada Suara Asisten (Kecepatan: 1.0x | Nada: 1.0x)";
        bicaraGoogleTTS("Kecepatan dan nada suara dikembalikan ke standar.");
      });
      tambahTombol(root, "Percepat Kecepatan Bicara (+0.1x)", "btn-green", () => {
        cfg.ttsSpeed = Math.min(2.0, Number((cfg.ttsSpeed + 0.1).toFixed(1)));
        simpanData();
        lblTts.textContent = `5. Kecepatan & Nada Suara Asisten (Kecepatan: ${cfg.ttsSpeed.toFixed(1)}x | Nada: ${Number(cfg.ttsPitch || 1.0).toFixed(1)}x)`;
        bicaraGoogleTTS(`Kecepatan bicara ${cfg.ttsSpeed.toFixed(1)} kali.`);
      });

      tambahLabelBagian(root, "6. Tambahkan Berkas Audio Ekstra dari Memori HP (Opsional)");
      tambahTombol(root, "Pilih Berkas Audio MP3/OGG Tambahan dari HP", "btn-blue", () => {
        const picker = document.getElementById("audio-file-picker");
        if (!picker) return;
        picker.onchange = function(e) {
          if (e.target.files && e.target.files.length > 0) {
            simpanFileAudioKeDB(e.target.files, (jml) => {
              bicaraGoogleTTS(`Alhamdulillah, ${jml} berkas audio tambahan berhasil disimpan.`);
            });
          }
        };
        picker.click();
      });

      tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-audiomedia-kembali-bawah");
    };

    const _menuPengaturanAdzanLama = menuPengaturanAdzan;
    menuPengaturanAdzan = window.menuPengaturanAdzan = function() {
      _menuPengaturanAdzanLama();
      const root = document.getElementById("app-root");
      if (!root) return;
      const infoJalur = dapatkanInfoJalurAudioAktif();
      tambahLabelBagian(root, "6. Pengaturan Cepat Jalur Saluran Audio, Asisten Marbot 15 Menit & Waktu Kehati-hatian");
      tambahTombol(root, `Pilih Jalur Saluran Audio / Streaming (Saat Ini: ${infoJalur.pendek})`, "btn-purple", () => bukaPopupPilihJalurAudio(menuPengaturanAdzan), "btn-adzan-pilih-jalur-audio");
      tambahTombol(root, "Buka Menu Lengkap Fitur Asisten Marbot Masjid (15 Menit Menjelang Sholat & Kehati-hatian)", "btn-teal", bukaMenuMarbotMasjid, "btn-adzan-ke-marbot");
      tambahSakelarAksesibel(root, "Pengumuman Suara Asisten Marbot (15 Menit Menjelang 5 Waktu Salat)", "s_jam", "btn-adzan-sakelar-marbot");
      tambahSakelarAksesibel(root, "Peringatan 15 Menit Waktu Kehati-hatian Menjelang Habis Waktu Salat", "s_kehatihatian", "btn-adzan-sakelar-kehatihatian");
    };

    const _menuPengaturanDurasiLama = menuPengaturanDurasi;
    menuPengaturanDurasi = window.menuPengaturanDurasi = function() {
      _menuPengaturanDurasiLama();
      const root = document.getElementById("app-root");
      if (!root) return;
      const mHatiSkrg = Number(cfg.menitKehatihatian) || 15;
      tambahLabelBagian(root, `8. Jeda Peringatan Waktu Kehati-hatian Sebelum Habis Waktu Salat (Saat Ini: ${mHatiSkrg} Menit)`);
      [10, 15, 20].forEach(v => {
        const aktif = (mHatiSkrg === v);
        tambahTombol(
          root,
          `${aktif ? "[ TERPILIH ] " : ""}${v} Menit Sebelum Habis Waktu Salat${v === 15 ? " (Standar Kehati-hatian)" : ""}`,
          aktif ? "btn-green" : "btn-gray",
          () => {
            cfg.menitKehatihatian = v;
            cfg.s_kehatihatian = true;
            simpanData();
            bicaraGoogleTTS(`Jeda peringatan waktu kehati-hatian diatur ke ${v} menit sebelum habis waktu salat.`);
            menuPengaturanDurasi();
          },
          `btn-durasi-menitKehatihatian-${v}`
        );
      });
      tambahTombol(root, "Buka Menu Lengkap Fitur Asisten Marbot Masjid", "btn-teal", bukaMenuMarbotMasjid, "btn-durasi-ke-marbot");
    };

    menuSakelarSunnah = window.menuSakelarSunnah = function() {
      const root = bersihkanLayar();
      tambahHeader(root, "Sakelar Asisten Marbot 15 Menit, Waktu Kehati-hatian & Ibadah Penting", "Atur Pengumuman 15 Menit Menjelang Sholat, Peringatan 15 Menit Waktu Kehati-hatian, Istiwa, Jumat, Tahajud, Imsak, Syuruq, Dhuha & Puasa");
      tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);

      tambahLabelBagian(root, "1. Fitur Asisten Marbot Masjid & Peringatan 15 Menit Waktu Kehati-hatian");
      tambahTombol(root, "Buka Menu Lengkap & Uji Suara Asisten Marbot Masjid (15 Menit Menjelang Sholat & Kehati-hatian)", "btn-teal", bukaMenuMarbotMasjid, "btn-buka-marbot-dari-sunnah");
      tambahSakelarAksesibel(root, "Pengumuman Suara Asisten Marbot (15 Menit Menjelang 5 Waktu Salat: Subuh, Dzuhur, Ashar, Maghrib & Isya)", "s_jam", "btn-sakelar-laporan-5waktu");
      tambahSakelarAksesibel(root, "Peringatan 15 Menit Waktu Kehati-hatian (Menjelang Habis Waktu Subuh/Terbit, Dzuhur, Ashar, Maghrib & Isya)", "s_kehatihatian", "btn-sakelar-waktu-kehatihatian");
      tambahSakelarAksesibel(root, "Laporan Asisten 3 Waktu Pilihan (03.00 Tahajud, 05.00 Rangkuman Pagi & 11.00 Siang)", "s_laporan3waktu", "btn-sakelar-laporan-3waktu");
      tambahSakelarAksesibel(root, "Sapaan Asisten Suara Saat Mulai Murottal & Tarhim Pra-Adzan", "s_sapaan_pra_adzan", "btn-sakelar-sapaan-pra-adzan");
      tambahSakelarAksesibel(root, "Jeda Sejenak Murottal Saat Asisten Marbot Mengumumkan Lalu Lanjutkan Otomatis", "jedaMurottalSaatMarbot", "btn-sakelar-jeda-murottal-marbot");
      tambahSakelarAksesibel(root, "Peringatan Waktu Istiwa / Zawal (Larangan Salat Menjelang Dzuhur)", "s_istiwa", "btn-sakelar-waktu-istiwa");
      tambahSakelarAksesibel(root, "Putar Otomatis Surah Yasin Setiap Malam Jumat (Maghrib & Isya)", "s_yasin_malam_jumat", "btn-sakelar-yasin-sunnah");
      tambahSakelarAksesibel(root, "Protokol Khusus Hari Jumat & Surah Al-Jumu'ah", "s_jumat", "btn-sakelar-jumat");

      tambahLabelBagian(root, "2. Sakelar Pengingat Ibadah Harian");
      tambahSakelarAksesibel(root, "Pengingat Sepertiga Malam / Salat Tahajud (2/3 Malam Nyata)", "s_tahajud");
      tambahSakelarAksesibel(root, "Pengingat Waktu Imsak (10 Menit Sebelum Subuh)", "s_imsak");
      tambahSakelarAksesibel(root, "Peringatan 10 Menit Menjelang Matahari Terbit (Timer + Peringatan Terbit + Ya Muhaimin)", "s_preterbit");
      tambahSakelarAksesibel(root, "Penanda Waktu Matahari Terbit / Syuruq (Sirine + Pengumuman Terbit)", "s_terbit");
      tambahSakelarAksesibel(root, "Pengingat Waktu Salat Sunnah Dhuha", "s_dhuha");
      tambahSakelarAksesibel(root, "Pengingat Salat Sunnah Rawatib Bakda Adzan", "s_rawatib");
      tambahSakelarAksesibel(root, "Pengingat Puasa Sunnah (Senin-Kamis & Ayyamul Bidh)", "s_puasa");
      tambahSakelarAksesibel(root, "Variasi Kalimat Hikmah & Dakwah Asisten Suara", "ttsVarian");
      tambahSakelarAksesibel(root, "Mode Hening Khusyuk Saat Waktu Salat", "s_khusyuk");
      tambahSakelarAksesibel(root, "Mode Musafir (Pengingat Rukhsoh Jamak & Qashar)", "s_musafir");

      tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama);
    };

    const _menuTesAudioLama = menuTesAudio;
    menuTesAudio = window.menuTesAudio = function() {
      _menuTesAudioLama();
      const root = document.getElementById("app-root");
      if (!root) return;
      const mLap = Number(cfg.menitLaporan5Waktu) || 15;
      const mHati = Number(cfg.menitKehatihatian) || 15;
      const infoJalur = dapatkanInfoJalurAudioAktif();

      const wadahMarbotTes = document.createElement("div");
      wadahMarbotTes.id = "wadah-tes-suara-marbot-v97";
      tambahLabelBagian(wadahMarbotTes, `0. Pilihan Jalur Saluran Audio & Uji Suara Marbot 15 Menit (Aktif: ${infoJalur.pendek})`);
      tambahTombol(wadahMarbotTes, `0A. Pilih Jalur Saluran Audio / Streaming (Saat Ini: ${infoJalur.pendek} — Media / Nada Dering / Notifikasi / Alarm / Sistem)`, "btn-purple", () => bukaPopupPilihJalurAudio(menuTesAudio), "btn-tes-pilih-jalur-audio");
      tambahTombol(wadahMarbotTes, `0B. Uji Pengumuman Asisten Marbot (${mLap} Menit Menjelang 5 Waktu Sholat + Bel Masjid)`, "btn-green", () => {
        const lok = dapatkanNamaLokasiBersih();
        ucapkanPengumumanMarbotDenganJedaMurottal(
          `Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. ${mLap} menit lagi akan memasuki waktu sholat Dzuhur untuk wilayah ${lok}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`
        );
      }, "btn-tes-audio-marbot-15menit");
      tambahTombol(wadahMarbotTes, `0C. Uji Peringatan ${mHati} Menit Waktu Kehati-hatian Akhir Waktu Sholat`, "btn-amber", () => {
        ucapkanPengumumanMarbotDenganJedaMurottal(
          `Peringatan kehati-hatian akhir waktu sholat. Waktu sholat Dzuhur tersisa ${mHati} menit lagi sebelum masuk waktu Ashar. Bagi yang belum menunaikan sholat Dzuhur, segera dirikan sholat.`
        );
      }, "btn-tes-audio-kehatihatian-15menit");
      tambahTombol(wadahMarbotTes, "0D. Uji Munculkan Jendela Tombol Besar Hentikan Suara di Layar Kunci", "btn-blue", () => {
        munculkanTombolBesarLayarKunci("Simulasi Jadwal Masuk di Layar Kunci", true);
      }, "btn-tes-audio-popup-layar-kunci");

      if (root.children.length >= 3) {
        root.insertBefore(wadahMarbotTes, root.children[3]);
      } else {
        root.appendChild(wadahMarbotTes);
      }
    };

    // -------------------------------------------------------------------------
    // 6. PASTIKAN `simpanData` & `aktifkanCepatStandarMasjid` MENYIMPAN JALUR AUDIO
    // -------------------------------------------------------------------------
    const _simpanDataLama = simpanData;
    simpanData = window.simpanData = function() {
      if (typeof cfg === "object" && cfg !== null) {
        cfg.goyangHentikan = false;
        cfg.audioStream = dapatkanIdJalurAudioValid(cfg.audioStream);
      }
      if (typeof _simpanDataLama === "function") _simpanDataLama();
    };

    const _aktifkanLama = aktifkanCepatStandarMasjid;
    aktifkanCepatStandarMasjid = window.aktifkanCepatStandarMasjid = function() {
      if (typeof _aktifkanLama === "function") _aktifkanLama();
      cfg.s_jam = true;
      cfg.s_marbot = true;
      cfg.s_kehatihatian = true;
      cfg.s_laporan3waktu = true;
      cfg.s_sapaan_pra_adzan = true;
      cfg.popupHentikanLuar = true;
      cfg.goyangHentikan = false;
      cfg.jedaMurottalSaatMarbot = true;
      cfg.audioStream = dapatkanIdJalurAudioValid(cfg.audioStream);
      cfg.menitLaporan5Waktu = Number(cfg.menitLaporan5Waktu) || 15;
      cfg.menitKehatihatian = Number(cfg.menitKehatihatian) || 15;
      simpanData();
    };

    // -------------------------------------------------------------------------
    // 7. PERBARUI `periksaUpdateOtomatisServer`
    // -------------------------------------------------------------------------
    periksaUpdateOtomatisServer = window.periksaUpdateOtomatisServer = async function(tampilkanPesanJikaSudahTerbaru = false) {
      try {
        if (tampilkanPesanJikaSudahTerbaru) {
          bicaraGoogleTTS("Memeriksa pembaruan otomatis dari server Nurul Masjid Pro.");
        }
        let resp = null;
        const kandidatUrls = (cfg && cfg.otaServerUrl) ? [cfg.otaServerUrl] : OTA_MANIFEST_URL_FALLBACKS;
        for (let u of kandidatUrls) {
          try {
            const r = await fetch(u + "?t=" + Date.now());
            if (r && r.ok) {
              resp = r;
              break;
            }
          } catch (errUrl) {}
        }
        if (!resp || !resp.ok) {
          if (tampilkanPesanJikaSudahTerbaru) {
            bicaraGoogleTTS("Aplikasi Nurul Masjid Pro Anda sudah berada pada versi terbaru.");
          }
          return;
        }
        const manifest = await resp.json();
        if (manifest && Array.isArray(manifest.audio_baru)) {
          cfg.daftarAudioOta = cfg.daftarAudioOta || [];
          manifest.audio_baru.forEach(itemAud => {
            if (itemAud && itemAud.nama && itemAud.url && !cfg.daftarAudioOta.includes(itemAud.nama)) {
              if (window.AndroidBridge && window.AndroidBridge.downloadOtaAudio) {
                window.AndroidBridge.downloadOtaAudio(itemAud.url, itemAud.nama);
              }
            }
          });
        }
        const verLokal = Number(localStorage.getItem("nurul_masjid_ota_ver") || 97);
        if (manifest && manifest.script_url && (Number(manifest.version) > verLokal || tampilkanPesanJikaSudahTerbaru)) {
          const rScript = await fetch(manifest.script_url + "?t=" + Date.now());
          if (rScript.ok) {
            const kodeBaru = await rScript.text();
            if (kodeBaru && kodeBaru.length > 1000) {
              localStorage.setItem("nurul_masjid_ota_script", kodeBaru);
              localStorage.setItem("nurul_masjid_ota_ver", String(manifest.version));
              try {
                const fnBaru = new Function(kodeBaru);
                fnBaru();
              } catch (eExec) {}
              bicaraGoogleTTS(`Alhamdulillah, pembaruan menyeluruh versi ${manifest.version} telah aktif sepenuhnya tanpa instal ulang.`);
              return;
            }
          }
        }
        if (tampilkanPesanJikaSudahTerbaru) {
          bicaraGoogleTTS(`Alhamdulillah, seluruh fitur versi ${verLokal} sudah aktif di aplikasi Anda.`);
        }
      } catch (e) {
        if (tampilkanPesanJikaSudahTerbaru) {
          bicaraGoogleTTS("Aplikasi Anda sudah menggunakan versi terbaru.");
        }
      }
    };

    // -------------------------------------------------------------------------
    // 8. PERBARUI BERANDA UTAMA (`tampilkanMenuUtama`) SECARA MENYELURUH
    // -------------------------------------------------------------------------
    const _tampilkanMenuUtamaLama = tampilkanMenuUtama;
    tampilkanMenuUtama = window.tampilkanMenuUtama = function() {
      _tampilkanMenuUtamaLama();
      const root = document.getElementById("app-root");
      if (!root) return;

      const btnGoyang = document.getElementById("btn-sakelar-goyang-hentikan-luar");
      if (btnGoyang) btnGoyang.remove();

      const btnCepat = document.getElementById("btn-aktifkan-cepat-semua-sakelar");
      if (btnCepat) {
        const teksCepat = "Aktifkan Cepat Seluruh Sakelar Standar Masjid (Adzan, Tarhim, Marbot 15 Menit, Waktu Kehati-hatian, Asmaul Husna & Doa)";
        btnCepat.textContent = teksCepat;
        btnCepat.setAttribute("aria-label", teksCepat);
      }

      const btnPopLuar = document.getElementById("btn-sakelar-popup-hentikan-luar");
      if (btnPopLuar) {
        const aktifPop = (cfg.popupHentikanLuar !== false);
        const teksPop = `Munculkan Otomatis Jendela Pop-Up Tombol Besar Hentikan Suara di Layar Kunci Saat Jadwal Masuk: ${aktifPop ? "AKTIF" : "NONAKTIF"} (Ketuk untuk Ubah)`;
        btnPopLuar.textContent = teksPop;
        btnPopLuar.setAttribute("aria-label", teksPop);
      }

      const btnUjiPop = document.getElementById("btn-uji-popup-hentikan-luar");
      if (btnUjiPop) {
        const teksUjiPop = "Uji Munculkan Jendela Pop-Up Tombol Besar Hentikan Suara di Layar Kunci Sekarang";
        btnUjiPop.textContent = teksUjiPop;
        btnUjiPop.setAttribute("aria-label", teksUjiPop);
        btnUjiPop.addEventListener("click", () => {
          munculkanTombolBesarLayarKunci("Simulasi Jadwal Masuk di Layar Kunci", true);
        });
      }

      const mLap = Number(cfg.menitLaporan5Waktu) || 15;
      const mHati = Number(cfg.menitKehatihatian) || 15;
      const infoJalur = dapatkanInfoJalurAudioAktif();

      // Tambahkan tombol Pilih Jalur Saluran Audio (Streaming) di Beranda Utama jika belum ada
      const btnTarhimUtama = document.getElementById("btn-utama-popup-tarhim");
      let btnJalurUtama = document.getElementById("btn-utama-pilih-jalur-audio");
      const teksJalurUtama = `Pilih Jalur Saluran Audio / Streaming (Saat Ini: ${infoJalur.pendek} — Media, Nada Dering, Notifikasi, Alarm, Sistem)`;
      if (!btnJalurUtama) {
        btnJalurUtama = document.createElement("button");
        btnJalurUtama.type = "button";
        btnJalurUtama.id = "btn-utama-pilih-jalur-audio";
        btnJalurUtama.className = "btn btn-teal";
        btnJalurUtama.textContent = teksJalurUtama;
        btnJalurUtama.setAttribute("aria-label", teksJalurUtama);
        btnJalurUtama.addEventListener("click", () => bukaPopupPilihJalurAudio(tampilkanMenuUtama));
        if (btnTarhimUtama && btnTarhimUtama.parentNode === root) {
          root.insertBefore(btnJalurUtama, btnTarhimUtama.nextSibling);
        } else {
          root.appendChild(btnJalurUtama);
        }
      } else {
        btnJalurUtama.textContent = teksJalurUtama;
        btnJalurUtama.setAttribute("aria-label", teksJalurUtama);
      }

      if (!document.getElementById("btn-utama-fitur-marbot-masjid")) {
        const btnMarbot = document.createElement("button");
        btnMarbot.type = "button";
        btnMarbot.id = "btn-utama-fitur-marbot-masjid";
        btnMarbot.className = "btn btn-teal";
        const teksBtn = `Fitur Asisten Marbot Masjid (Pengumuman ${mLap} Menit Menjelang 5 Waktu Sholat & Peringatan ${mHati} Menit Waktu Kehati-hatian)`;
        btnMarbot.textContent = teksBtn;
        btnMarbot.setAttribute("aria-label", teksBtn);
        btnMarbot.addEventListener("click", bukaMenuMarbotMasjid);
        if (btnCepat && btnCepat.parentNode === root) {
          root.insertBefore(btnMarbot, btnCepat.nextSibling);
        } else {
          root.appendChild(btnMarbot);
        }

        const btnRangkumanPagi = document.createElement("button");
        btnRangkumanPagi.type = "button";
        btnRangkumanPagi.id = "btn-utama-bacakan-rangkuman-pagi";
        btnRangkumanPagi.className = "btn btn-blue";
        const teksPagi = "Bacakan Rangkuman Pagi, Sisa Waktu & Info Cuaca Hari Ini";
        btnRangkumanPagi.textContent = teksPagi;
        btnRangkumanPagi.setAttribute("aria-label", teksPagi);
        btnRangkumanPagi.addEventListener("click", () => {
          bicaraGoogleTTS(buatRangkumanPagiTeks());
        });
        if (btnMarbot.parentNode === root) {
          root.insertBefore(btnRangkumanPagi, btnMarbot.nextSibling);
        }
      }

      const semuaTombol = root.children || [];
      for (let i = 0; i < semuaTombol.length; i++) {
        const b = semuaTombol[i];
        const t = String(b.textContent || "");
        if (t.includes("Sakelar Laporan 5 Waktu Salat")) {
          const teksSunnahBaru = `Sakelar Asisten Marbot (${mLap} Menit), Peringatan ${mHati} Menit Waktu Kehati-hatian, Istiwa & Ibadah Penting`;
          b.textContent = teksSunnahBaru;
          b.setAttribute("aria-label", teksSunnahBaru);
        } else if (t.includes("Atur Durasi Murottal, Tarhim")) {
          const teksDurasiBaru = `Atur Durasi Murottal, Tarhim, Iqomah, Marbot (${mLap} Menit) & Waktu Kehati-hatian (${mHati} Menit)`;
          b.textContent = teksDurasiBaru;
          b.setAttribute("aria-label", teksDurasiBaru);
        } else if (t.includes("Volume Suara, Mode Murottal")) {
          const teksVolBaru = `Volume Suara, Jalur Saluran Audio (${infoJalur.pendek}), Mode Murottal & Kecepatan Suara TTS`;
          b.textContent = teksVolBaru;
          b.setAttribute("aria-label", teksVolBaru);
        } else if (t.includes("Dasbor Uji Coba 23 Suara")) {
          const teksTesBaru = "Dasbor Uji Coba Suara Lengkap (Marbot 15 Menit, Waktu Kehati-hatian, Adzan, Tarhim, Murottal & Terbit)";
          b.textContent = teksTesBaru;
          b.setAttribute("aria-label", teksTesBaru);
        }
      }
    };

    // -------------------------------------------------------------------------
    // 9. PERBARUI `detakMesinMasjid` V97
    // -------------------------------------------------------------------------
    const _detakMesinLama = detakMesinMasjid;
    detakMesinMasjid = window.detakMesinMasjid = function() {
      try {
        if (window.__sedangPengumumanMarbotAktif) {
          window.DetakJantung = Math.floor(Date.now() / 1000);
          return;
        }

        const now = new Date();
        const hh = String(now.getHours()).padStart(2, "0");
        const mm = String(now.getMinutes()).padStart(2, "0");
        const tglIni = dapatkanTanggalISO(0);
        const menitSkrg = now.getHours() * 60 + now.getMinutes();
        const detikSkrg = now.getSeconds();

        if (cfg && cfg.master_aktif && apakahLokasiSudahDiatur()) {
          pastikanJadwalTersedia();
          const jdw = cfg.jadwalSebulan && cfg.jadwalSebulan[tglIni];
          if (jdw) {
            if (jdw.Terbit) {
              const jamPraTerbitUtama = tambahMenit(jdw.Terbit, -10);
              if (cfg.s_terbit && apakahWaktuJadwalTiba(menitSkrg, jdw.Terbit, "TERBIT_" + tglIni)) {
                jalankanEstafetWaktuTerbit();
                return;
              }
              if (cfg.s_preterbit && apakahWaktuJadwalTiba(menitSkrg, jamPraTerbitUtama, "PRETERBIT_" + tglIni)) {
                jalankanEstafetPeringatanTerbit();
                return;
              }
            }

            if (periksaPengumumanMarbotDanKehatihatian(menitSkrg, detikSkrg, jdw, tglIni, hh, mm)) {
              return;
            }
          }
        }
      } catch (ePre) {}

      return _detakMesinLama();
    };

    // -------------------------------------------------------------------------
    // 10. MIGRASI OTOMATIS KONFIGURASI PENGGUNA KE V97 & SINKRONISASI JADWAL LATAR BELAKANG 24 JAM:
    // -------------------------------------------------------------------------
    try {
      let rawSaved = localStorage.getItem("nidaul_masjid_cfg_v77");
      if ((!rawSaved || rawSaved.indexOf('"latitude":0') !== -1) && window.AndroidBridge && typeof window.AndroidBridge.getSavedConfig === "function") {
        const nativeCfg = window.AndroidBridge.getSavedConfig();
        if (nativeCfg && nativeCfg.length > 10 && nativeCfg.indexOf('"latitude":0') === -1) {
          rawSaved = nativeCfg;
          localStorage.setItem("nidaul_masjid_cfg_v77", nativeCfg);
        }
      }
      if (rawSaved && typeof cfg === "object" && cfg !== null) {
        const parsedSaved = JSON.parse(rawSaved);
        if (parsedSaved && typeof parsedSaved === "object") {
          Object.assign(cfg, parsedSaved);
        }
      }
    } catch (eRestore) {}

    if (typeof cfg === "object" && cfg !== null) {
      const _lokOk = (s) => Boolean(s && String(s).trim() && !String(s).toLowerCase().includes("belum diatur"));
      if (!_lokOk(cfg.kota)) {
        if (_lokOk(cfg.kecamatan)) cfg.kota = cfg.kecamatan;
        else if (_lokOk(cfg.lokasiDitemukan)) cfg.kota = cfg.lokasiDitemukan;
      }
      if (cfg.kota && Number(cfg.latitude) !== 0 && Number(cfg.longitude) !== 0) {
        if (typeof cfg.master_aktif === "undefined") cfg.master_aktif = true;
        const tglSkrg = (typeof dapatkanTanggalISO === "function") ? dapatkanTanggalISO(0) : "";
        if (tglSkrg && (!cfg.jadwalSebulan || !cfg.jadwalSebulan[tglSkrg]) && typeof hitungJadwalKemenagBulanan === "function") {
          cfg.jadwalSebulan = hitungJadwalKemenagBulanan(Number(cfg.latitude), Number(cfg.longitude));
        }
      }
      cfg.goyangHentikan = false;
      cfg.popupHentikanLuar = true;
      cfg.s_jam = true;
      cfg.s_marbot = true;
      cfg.s_kehatihatian = true;
      cfg.s_laporan3waktu = (cfg.s_laporan3waktu !== false);
      cfg.s_sapaan_pra_adzan = (cfg.s_sapaan_pra_adzan !== false);
      cfg.s_bel = (cfg.s_bel !== false);
      cfg.s_istiwa = (cfg.s_istiwa !== false);
      cfg.s_preterbit = (cfg.s_preterbit !== false);
      cfg.s_terbit = (cfg.s_terbit !== false);
      cfg.jedaMurottalSaatMarbot = (cfg.jedaMurottalSaatMarbot !== false);
      cfg.audioStream = dapatkanIdJalurAudioValid(cfg.audioStream);
      cfg.menitLaporan5Waktu = Number(cfg.menitLaporan5Waktu) || 15;
      cfg.menitKehatihatian = Number(cfg.menitKehatihatian) || 15;
      if (typeof simpanData === "function") simpanData();
    }

    if (window.__intervalOtaV95) clearInterval(window.__intervalOtaV95);
    if (window.__intervalOtaV96) clearInterval(window.__intervalOtaV96);
    if (window.__intervalOtaV97) clearInterval(window.__intervalOtaV97);
    try {
      if (typeof __intervalDetakUtama !== "undefined" && __intervalDetakUtama) {
        clearInterval(__intervalDetakUtama);
      }
    } catch (e) {}
    window.__intervalOtaV97 = setInterval(function() {
      if (typeof window.detakMesinMasjid === "function") {
        window.detakMesinMasjid();
      }
    }, 1000);

    if (typeof halamanAktif === "undefined" || halamanAktif === "beranda") {
      tampilkanMenuUtama();
    } else if (halamanAktif === "marbot") {
      bukaMenuMarbotMasjid();
    } else if (halamanAktif === "audio_media") {
      menuPengaturanAudioMedia();
    }
  } catch (err) {}
})();


window.pulihkanConfigDariNativeJikaPerlu = function() {
  try {
    if (window.__sedangResetPabrikSengaja) return;
    const punyaLokSkrg = Boolean(cfg && Number(cfg.latitude) !== 0 && Number(cfg.longitude) !== 0 && cfg.kota && !String(cfg.kota).toLowerCase().includes("belum diatur"));
    if (!punyaLokSkrg) {
      if (typeof muatData === "function") muatData();
      const punyaLokSetelahMuat = Boolean(cfg && Number(cfg.latitude) !== 0 && Number(cfg.longitude) !== 0 && cfg.kota && !String(cfg.kota).toLowerCase().includes("belum diatur"));
      if (punyaLokSetelahMuat) {
        if (typeof pastikanJadwalTersedia === "function") pastikanJadwalTersedia();
        if (typeof simpanData === "function") simpanData();
        if (typeof halamanAktif === "undefined" || halamanAktif === "beranda") {
          if (typeof tampilkanMenuUtama === "function") tampilkanMenuUtama();
        }
      }
    } else {
      if (typeof pastikanJadwalTersedia === "function") pastikanJadwalTersedia();
      if (typeof simpanData === "function") simpanData();
    }
  } catch (e) {}
};

// =========================================================================
// MODUL INOVASI SUARA ASISTEN GEMINI AI HIBRIDA (METODE 1 OFFLINE + METODE 2 AUTO-CACHE)
// Pengembang Resmi: Nur (Jawa Timur) & Mas Yeni Setiawan (Banyumas, Jawa Tengah)
// Dilengkapi:
// 1. Tombol Ambil Kode Kunci Gratis Langsung dari Google Gemini (Google AI Studio)
// 2. Tombol Tempel Otomatis Kode Kunci dari Papan Klip (Clipboard) 1 Kali Ketuk
// 3. Tombol Unduh & Kunci 16 Suara Pengumuman Masjid ke Memori Offline HP (Metode 1)
// 4. Mesin Simpan Otomatis (Auto-Cache) Kalimat Jadwal Baru ke Offline (Metode 2)
// =========================================================================
(function pasangModulSuaraGeminiHibridaV97() {
  try {
    const DAFTAR_KARAKTER_SUARA_GEMINI = [
      {
        id: "Orus",
        label: "1. Ustadz / Marbot Berwibawa (Suara Laki-Laki Tegas — Orus)",
        pendek: "Ustadz Berwibawa (Orus)"
      },
      {
        id: "Charon",
        label: "2. Muadzin / Asisten Teduh (Suara Laki-Laki Hangat — Charon)",
        pendek: "Asisten Teduh (Charon)"
      },
      {
        id: "Puck",
        label: "3. Asisten Santun (Suara Laki-Laki Jernih — Puck)",
        pendek: "Asisten Santun (Puck)"
      },
      {
        id: "Kore",
        label: "4. Asisten Muslimah Tenang (Suara Perempuan Lembut — Kore)",
        pendek: "Muslimah Tenang (Kore)"
      }
    ];
    window.DAFTAR_KARAKTER_SUARA_GEMINI = DAFTAR_KARAKTER_SUARA_GEMINI;

    function dapatkanInfoSuaraGeminiAktif() {
      const vId = (cfg && cfg.geminiVoiceName) ? String(cfg.geminiVoiceName) : "Orus";
      return DAFTAR_KARAKTER_SUARA_GEMINI.find(it => it.id === vId) || DAFTAR_KARAKTER_SUARA_GEMINI[0];
    }
    window.dapatkanInfoSuaraGeminiAktif = dapatkanInfoSuaraGeminiAktif;

    function hitungHashTeksGemini(teks) {
      const s = String(teks || "").trim().toLowerCase().replace(/\s+/g, " ");
      let h = 2166136261;
      for (let i = 0; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 16777619);
      }
      return (h >>> 0).toString(16);
    }

    function tentukanNamaFileGeminiDariTeks(teks) {
      const t = String(teks || "");
      if (t.includes("Pengumuman Asisten Marbot Masjid")) {
        if (t.includes("waktu sholat Subuh")) return "gemini_tts_marbot_subuh.wav";
        if (t.includes("waktu sholat Dzuhur")) return "gemini_tts_marbot_dzuhur.wav";
        if (t.includes("waktu sholat Ashar")) return "gemini_tts_marbot_ashar.wav";
        if (t.includes("waktu sholat Maghrib")) return "gemini_tts_marbot_maghrib.wav";
        if (t.includes("waktu sholat Isya")) return "gemini_tts_marbot_isya.wav";
      }
      if (t.includes("Peringatan kehati-hatian")) {
        if (t.includes("sholat Subuh")) return "gemini_tts_hati_subuh.wav";
        if (t.includes("sholat Dzuhur")) return "gemini_tts_hati_dzuhur.wav";
        if (t.includes("sholat Ashar")) return "gemini_tts_hati_ashar.wav";
        if (t.includes("sholat Maghrib")) return "gemini_tts_hati_maghrib.wav";
        if (t.includes("sholat Isya")) return "gemini_tts_hati_isya.wav";
      }
      if (t.includes("memasuki waktu Imsak")) return "gemini_tts_imsak.wav";
      if (t.includes("memasuki waktu Istiwa")) return "gemini_tts_istiwa.wav";
      if (t.includes("Sepertiga malam terakhir telah tiba")) return "gemini_tts_tahajud.wav";
      if (t.includes("Dua menit lagi menuju iqomah")) return "gemini_tts_iqomah_cd2.wav";
      if (t.includes("Satu menit lagi menuju iqomah")) return "gemini_tts_iqomah_cd1.wav";
      if (t.includes("Matahari telah terbit sempurna")) return "gemini_tts_syuruq.wav";
      if (t.includes("Uji suara asisten masjid Gemini")) return "gemini_tts_uji_suara.wav";
      const vId = dapatkanInfoSuaraGeminiAktif().id.toLowerCase();
      return "gemini_tts_" + vId + "_" + hitungHashTeksGemini(t) + ".wav";
    }
    window.tentukanNamaFileGeminiDariTeks = tentukanNamaFileGeminiDariTeks;

    function apakahKalimatPengumumanMasjid(teks) {
      const t = String(teks || "");
      return (
        t.includes("Pengumuman Asisten Marbot Masjid") ||
        t.includes("Peringatan kehati-hatian") ||
        t.includes("memasuki waktu Imsak") ||
        t.includes("memasuki waktu Istiwa") ||
        t.includes("Sepertiga malam terakhir telah tiba") ||
        t.includes("menit lagi menuju iqomah") ||
        t.includes("Matahari telah terbit sempurna") ||
        t.includes("Rangkuman pagi Nurul Masjid Pro") ||
        t.includes("Saatnya sepertiga malam terakhir") ||
        t.includes("Saatnya bersiap menjelang waktu sholat") ||
        t.includes("Jangan lupa berniat puasa") ||
        t.includes("masuk puasa sunnah") ||
        t.includes("Uji suara asisten masjid Gemini")
      );
    }

    function bungkusPcmBase64KeWavBlob(base64Pcm, sampleRate = 24000) {
      const binStr = atob(base64Pcm);
      const pcmLen = binStr.length;
      if (pcmLen > 4 && binStr.substring(0, 4) === "RIFF") {
        const bytes = new Uint8Array(pcmLen);
        for (let i = 0; i < pcmLen; i++) bytes[i] = binStr.charCodeAt(i);
        return new Blob([bytes], { type: "audio/wav" });
      }
      const buffer = new ArrayBuffer(44 + pcmLen);
      const view = new DataView(buffer);
      function writeStr(offset, str) {
        for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
      }
      const channels = 1;
      const byteRate = sampleRate * channels * 2;
      writeStr(0, "RIFF");
      view.setUint32(4, 36 + pcmLen, true);
      writeStr(8, "WAVE");
      writeStr(12, "fmt ");
      view.setUint32(16, 16, true);
      view.setUint16(20, 1, true);
      view.setUint16(22, channels, true);
      view.setUint32(24, sampleRate, true);
      view.setUint32(28, byteRate, true);
      view.setUint16(32, channels * 2, true);
      view.setUint16(34, 16, true);
      writeStr(36, "data");
      view.setUint32(40, pcmLen, true);
      const pcmBytes = new Uint8Array(buffer, 44);
      for (let i = 0; i < pcmLen; i++) {
        pcmBytes[i] = binStr.charCodeAt(i);
      }
      return new Blob([buffer], { type: "audio/wav" });
    }

    function panggilHttpPostJson(url, payloadObj, callback) {
      const bodyStr = JSON.stringify(payloadObj);
      if (window.AndroidBridge && typeof window.AndroidBridge.httpPostJsonNative === "function") {
        const cbId = "cb_post_" + Date.now() + "_" + Math.floor(Math.random() * 100000);
        window.__httpCallbacks = window.__httpCallbacks || {};
        window.__httpCallbacks[cbId] = function(sukses, content) {
          if (sukses && content) {
            callback(true, content);
          } else {
            fetch(url, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: bodyStr
            })
              .then(r => r.text().then(t => ({ ok: r.ok, text: t })))
              .then(res => callback(res.ok, res.text))
              .catch(err => callback(false, String(err || "")));
          }
        };
        try {
          window.AndroidBridge.httpPostJsonNative(url, bodyStr, cbId);
          return;
        } catch (e) {
          delete window.__httpCallbacks[cbId];
        }
      }
      fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: bodyStr
      })
        .then(r => r.text().then(t => ({ ok: r.ok, text: t })))
        .then(res => callback(res.ok, res.text))
        .catch(err => callback(false, String(err || "")));
    }

    function apakahFileGeminiSudahAdaOffline(namaFile) {
      const cleanKey = String(namaFile || "").toLowerCase();
      if (window.AndroidBridge && typeof window.AndroidBridge.hasGeminiWavFile === "function") {
        try {
          if (window.AndroidBridge.hasGeminiWavFile(namaFile)) return true;
        } catch (e) {}
      }
      if (typeof customAudioBlobs === "object" && customAudioBlobs && customAudioBlobs[cleanKey]) {
        return true;
      }
      return false;
    }
    window.apakahFileGeminiSudahAdaOffline = apakahFileGeminiSudahAdaOffline;

    function putarFileGeminiOffline(namaFile, callbackSelesai = null) {
      const volP = (cfg && cfg.volAdzan) ? Number(cfg.volAdzan) : 85;
      if (window.AndroidBridge && typeof window.AndroidBridge.playGeminiWavFile === "function") {
        try {
          window._pendingTTSCallback = callbackSelesai || null;
          const ok = window.AndroidBridge.playGeminiWavFile(namaFile, volP);
          if (ok) return true;
        } catch (e) {}
      }
      const cleanKey = String(namaFile || "").toLowerCase();
      if (typeof customAudioBlobs === "object" && customAudioBlobs && customAudioBlobs[cleanKey]) {
        try {
          const aud = new Audio(customAudioBlobs[cleanKey]);
          aud.volume = Math.max(0.2, Math.min(1.0, volP / 100.0));
          aud.onended = () => { if (callbackSelesai) callbackSelesai(); };
          aud.onerror = () => { if (callbackSelesai) callbackSelesai(); };
          const p = aud.play();
          if (p && typeof p.catch === "function") {
            p.catch(() => { if (callbackSelesai) callbackSelesai(); });
          }
          return true;
        } catch (e2) {}
      }
      return false;
    }

    function mintaDanSimpanSuaraGemini(teks, namaFileTarget, callbackSelesai) {
      const apiKey = String((cfg && cfg.geminiApiKey) || "").trim();
      if (!apiKey || apiKey.length < 15) {
        callbackSelesai(false, "Kode kunci belum diisi");
        return;
      }
      const infoVoice = dapatkanInfoSuaraGeminiAktif();
      const daftarModel = [
        "gemini-2.5-flash-preview-tts",
        "gemini-2.0-flash-exp"
      ];
      let idxModel = 0;

      function cobaModelBerikutnya() {
        if (idxModel >= daftarModel.length) {
          callbackSelesai(false, "Gagal menghubungi server Gemini atau kuota penuh");
          return;
        }
        const modelName = daftarModel[idxModel++];
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${encodeURIComponent(apiKey)}`;
        const payload = {
          contents: [
            {
              parts: [
                {
                  text: "Bacakan pengumuman masjid berikut dengan bahasa Indonesia yang fasih, jelas, tenang, dan berwibawa: " + teks
                }
              ]
            }
          ],
          generationConfig: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: infoVoice.id
                }
              }
            }
          }
        };

        panggilHttpPostJson(url, payload, function(ok, respText) {
          if (!ok || !respText) {
            cobaModelBerikutnya();
            return;
          }
          try {
            const data = JSON.parse(respText);
            const parts = data && data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
            let b64Audio = "";
            if (Array.isArray(parts)) {
              for (let p of parts) {
                if (p && p.inlineData && p.inlineData.data) {
                  b64Audio = p.inlineData.data;
                  break;
                }
              }
            }
            if (!b64Audio || b64Audio.length < 200) {
              cobaModelBerikutnya();
              return;
            }

            let tersimpanNative = false;
            if (window.AndroidBridge && typeof window.AndroidBridge.saveGeminiWavFile === "function") {
              try {
                tersimpanNative = Boolean(window.AndroidBridge.saveGeminiWavFile(namaFileTarget, b64Audio, 24000));
              } catch (eSav) {}
            }

            try {
              const wavBlob = bungkusPcmBase64KeWavBlob(b64Audio, 24000);
              const fileObj = new File([wavBlob], namaFileTarget, { type: "audio/wav" });
              if (typeof customAudioBlobs === "object" && customAudioBlobs) {
                customAudioBlobs[namaFileTarget.toLowerCase()] = URL.createObjectURL(wavBlob);
              }
              if (typeof simpanFileAudioKeDB === "function") {
                simpanFileAudioKeDB([fileObj]);
              }
            } catch (eBlob) {}

            callbackSelesai(true, namaFileTarget);
          } catch (eParse) {
            cobaModelBerikutnya();
          }
        });
      }

      cobaModelBerikutnya();
    }
    window.mintaDanSimpanSuaraGemini = mintaDanSimpanSuaraGemini;

    // Bungkus bicaraGoogleTTS agar otomatis menggunakan Metode 1 (Offline Cache) & Metode 2 (Auto-Cache)
    const _bicaraGoogleTTSAsli = window.bicaraGoogleTTS;
    window.bicaraGoogleTTSAsliStandar = _bicaraGoogleTTSAsli;

    bicaraGoogleTTS = window.bicaraGoogleTTS = function(teks, senyapVisual = false, callbackSelesai = null, paksaGeminiSekarang = false) {
      const teksUcap = String(teks || "");
      const geminiAktif = Boolean(cfg && cfg.geminiTtsAktif !== false);
      const semuaSuaraGemini = Boolean(cfg && cfg.geminiSemuaSuara === true);
      const adalahPengumuman = paksaGeminiSekarang || semuaSuaraGemini || apakahKalimatPengumumanMasjid(teksUcap);

      if (geminiAktif && adalahPengumuman) {
        const namaFileGem = tentukanNamaFileGeminiDariTeks(teksUcap);

        // METODE 1: Cek apakah berkas suara sudah tersimpan di memori Offline HP!
        if (apakahFileGeminiSudahAdaOffline(namaFileGem)) {
          if (!senyapVisual && typeof tampilkanToastVisual === "function") {
            tampilkanToastVisual(teksUcap);
          }
          if (putarFileGeminiOffline(namaFileGem, callbackSelesai)) {
            return;
          }
        }

        // METODE 2: Jika belum ada di memori offline & pengguna sudah menempelkan Kode Kunci Gemini,
        // ambil otomatis dari Gemini, simpan permanen ke memori offline HP, lalu putar!
        const apiKey = String((cfg && cfg.geminiApiKey) || "").trim();
        if (apiKey && apiKey.length >= 15 && (cfg.geminiAutoCache !== false || paksaGeminiSekarang)) {
          if (!senyapVisual && typeof tampilkanToastVisual === "function") {
            tampilkanToastVisual(teksUcap);
          }
          mintaDanSimpanSuaraGemini(teksUcap, namaFileGem, function(berhasil) {
            if (berhasil && putarFileGeminiOffline(namaFileGem, callbackSelesai)) {
              return;
            }
            _bicaraGoogleTTSAsli(teksUcap, true, callbackSelesai);
          });
          return;
        }
      }

      return _bicaraGoogleTTSAsli(teksUcap, senyapVisual, callbackSelesai);
    };

    function dapatkanDaftar16PaketSuaraIntiMasjid() {
      const mLap = Math.max(5, Number((cfg && cfg.menitLaporan5Waktu) || 15));
      const mHati = Math.max(5, Number((cfg && cfg.menitKehatihatian) || 15));
      const lok = (typeof dapatkanNamaLokasiBersih === "function") ? dapatkanNamaLokasiBersih() : "wilayah Anda";
      return [
        {
          file: "gemini_tts_marbot_subuh.wav",
          label: `1. Pengumuman Marbot ${mLap} Menit Menjelang Subuh`,
          teks: `Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. ${mLap} menit lagi akan memasuki waktu sholat Subuh untuk wilayah ${lok}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`
        },
        {
          file: "gemini_tts_marbot_dzuhur.wav",
          label: `2. Pengumuman Marbot ${mLap} Menit Menjelang Dzuhur`,
          teks: `Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. ${mLap} menit lagi akan memasuki waktu sholat Dzuhur untuk wilayah ${lok}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`
        },
        {
          file: "gemini_tts_marbot_ashar.wav",
          label: `3. Pengumuman Marbot ${mLap} Menit Menjelang Ashar`,
          teks: `Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. ${mLap} menit lagi akan memasuki waktu sholat Ashar untuk wilayah ${lok}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`
        },
        {
          file: "gemini_tts_marbot_maghrib.wav",
          label: `4. Pengumuman Marbot ${mLap} Menit Menjelang Maghrib`,
          teks: `Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. ${mLap} menit lagi akan memasuki waktu sholat Maghrib untuk wilayah ${lok}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`
        },
        {
          file: "gemini_tts_marbot_isya.wav",
          label: `5. Pengumuman Marbot ${mLap} Menit Menjelang Isya`,
          teks: `Assalamu'alaikum warahmatullahi wabarakatuh. Pengumuman Asisten Marbot Masjid. ${mLap} menit lagi akan memasuki waktu sholat Isya untuk wilayah ${lok}. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`
        },
        {
          file: "gemini_tts_hati_subuh.wav",
          label: `6. Peringatan ${mHati} Menit Menjelang Habis Waktu Subuh`,
          teks: `Peringatan kehati-hatian akhir waktu sholat. Waktu sholat Subuh tersisa ${mHati} menit lagi sebelum matahari terbit. Bagi yang belum menunaikan sholat Subuh, segera dirikan sholat.`
        },
        {
          file: "gemini_tts_hati_dzuhur.wav",
          label: `7. Peringatan ${mHati} Menit Menjelang Habis Waktu Dzuhur`,
          teks: `Peringatan kehati-hatian akhir waktu sholat. Waktu sholat Dzuhur tersisa ${mHati} menit lagi sebelum masuk waktu Ashar. Bagi yang belum menunaikan sholat Dzuhur, segera dirikan sholat.`
        },
        {
          file: "gemini_tts_hati_ashar.wav",
          label: `8. Peringatan ${mHati} Menit Menjelang Habis Waktu Ashar`,
          teks: `Peringatan kehati-hatian akhir waktu sholat. Waktu sholat Ashar tersisa ${mHati} menit lagi sebelum masuk waktu Maghrib. Bagi yang belum menunaikan sholat Ashar, segera dirikan sholat.`
        },
        {
          file: "gemini_tts_hati_maghrib.wav",
          label: `9. Peringatan ${mHati} Menit Menjelang Habis Waktu Maghrib`,
          teks: `Peringatan kehati-hatian akhir waktu sholat. Waktu sholat Maghrib tersisa ${mHati} menit lagi sebelum masuk waktu Isya. Bagi yang belum menunaikan sholat Maghrib, segera dirikan sholat.`
        },
        {
          file: "gemini_tts_hati_isya.wav",
          label: `10. Peringatan ${mHati} Menit Menjelang Habis Waktu Isya`,
          teks: `Peringatan kehati-hatian akhir waktu sholat. Waktu sholat Isya tersisa ${mHati} menit lagi sebelum masuk waktu Subuh. Bagi yang belum menunaikan sholat Isya, segera dirikan sholat.`
        },
        {
          file: "gemini_tts_imsak.wav",
          label: "11. Pengingat Waktu Imsak (10 Menit Sebelum Subuh)",
          teks: "Perhatian, saat ini telah memasuki waktu Imsak, sepuluh menit menjelang kumandang adzan Subuh."
        },
        {
          file: "gemini_tts_istiwa.wav",
          label: "12. Peringatan Waktu Larangan Istiwa / Zawal Menjelang Dzuhur",
          teks: "Perhatian, saat ini memasuki waktu Istiwa menjelang waktu Dzuhur. Waktu dilarang mendirikan salat sunnah hingga kumandang adzan Dzuhur."
        },
        {
          file: "gemini_tts_tahajud.wav",
          label: "13. Panggilan Sepertiga Malam Terakhir / Salat Tahajud",
          teks: "Sepertiga malam terakhir telah tiba. Bangunlah untuk sholat Tahajud dan bermunajat kepada Allah Subhanahu wa Ta'ala."
        },
        {
          file: "gemini_tts_iqomah_cd2.wav",
          label: "14. Hitung Mundur 2 Menit Menuju Iqomah",
          teks: "Dua menit lagi menuju panggilan iqomah. Mari bersiap merapatkan barisan."
        },
        {
          file: "gemini_tts_iqomah_cd1.wav",
          label: "15. Hitung Mundur 1 Menit Menuju Iqomah",
          teks: "Satu menit lagi menuju panggilan iqomah. Mari berdiri, luruskan dan rapatkan shaf."
        },
        {
          file: "gemini_tts_syuruq.wav",
          label: "16. Pengumuman Waktu Syuruq / Matahari Terbit Sempurna",
          teks: "Matahari telah terbit sempurna, waktu Syuruq telah tiba."
        }
      ];
    }

    function hitungJumlahPaketIntiTersimpan() {
      const daftar = dapatkanDaftar16PaketSuaraIntiMasjid();
      let jml = 0;
      for (let item of daftar) {
        if (apakahFileGeminiSudahAdaOffline(item.file)) jml++;
      }
      return jml;
    }

    // -------------------------------------------------------------------------
    // MENU KHUSUS INOVASI SUARA ASISTEN GEMINI AI (METODE 1 + METODE 2)
    // -------------------------------------------------------------------------
    bukaMenuSuaraGemini = window.bukaMenuSuaraGemini = function() {
      const root = bersihkanLayar("gemini_tts");
      const infoVoice = dapatkanInfoSuaraGeminiAktif();
      const apiKeyAda = Boolean(cfg && cfg.geminiApiKey && String(cfg.geminiApiKey).trim().length >= 15);
      const jmlOffline = hitungJumlahPaketIntiTersimpan();

      tambahHeader(
        root,
        "Inovasi Suara Asisten Gemini AI (Offline & Simpan Otomatis)",
        "Gabungan Metode 1 (Paket Suara Inti Offline) & Metode 2 (Simpan Otomatis Kalimat Baru)"
      );
      tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-gemini-kembali-atas");

      // Kartu Penjelasan 1 Kali Usap (Ramah Tunanetra Jieshuo & TalkBack)
      const teksPanduanUtuh = `Status Suara Asisten Gemini AI: ${cfg.geminiTtsAktif !== false ? "AKTIF" : "NONAKTIF"}. Karakter Suara: ${infoVoice.pendek}. Status Kode Kunci: ${apiKeyAda ? "SUDAH TERPASANG DI HP INI" : "BELUM DIISI (Menggunakan Suara Standar HP)"}. Paket Suara Inti Offline Tersimpan: ${jmlOffline} dari 16 suara pengumuman masjid. Cara Pakai Sangat Mudah: Pertama, ketuk tombol Ambil Kode Kunci Gratis dari Google Gemini di bawah untuk membuka halaman Google AI Studio lalu salin kode kuncinya. Kedua, kembali ke aplikasi ini lalu ketuk tombol Tempel Otomatis Kode Kunci dari Papan Klip. Ketiga, ketuk tombol Unduh dan Kunci Seluruh 16 Suara Pengumuman Masjid ke Memori Offline HP agar suara Gemini langsung berbunyi selamanya walaupun tanpa internet.`;
      const kartuPanduan = document.createElement("div");
      kartuPanduan.id = "kartu-panduan-suara-gemini";
      kartuPanduan.className = "summary-item";
      kartuPanduan.setAttribute("tabindex", "0");
      kartuPanduan.setAttribute("aria-label", teksPanduanUtuh);
      kartuPanduan.textContent = teksPanduanUtuh;
      root.appendChild(kartuPanduan);

      tambahLabelBagian(root, "Langkah 1 & 2: Ambil & Tempel Otomatis Kode Kunci Gratis Google Gemini");

      // TOMBOL 1: Buka Langsung Halaman Resmi Google AI Studio untuk Ambil Kode Kunci
      tambahTombol(
        root,
        "1. Ambil Kode Kunci Gratis dari Google Gemini (Buka Halaman Resmi Google AI Studio)",
        "btn-blue",
        () => {
          const urlKey = "https://aistudio.google.com/app/apikey";
          window.bicaraGoogleTTSAsliStandar(
            "Membuka halaman resmi Google AI Studio di peramban. Silakan ketuk Create API Key lalu ketuk Copy atau Salin, kemudian kembali ke aplikasi Nurul Masjid Pro dan ketuk tombol nomor dua.",
            false,
            () => {
              if (window.AndroidBridge && typeof window.AndroidBridge.openExternalUrl === "function") {
                window.AndroidBridge.openExternalUrl(urlKey);
              } else {
                window.open(urlKey, "_blank");
              }
            }
          );
        },
        "btn-gemini-ambil-kode-resmi"
      );

      // TOMBOL 2: Tempel Otomatis Kode Kunci dari Papan Klip (Clipboard) 1 Kali Ketuk!
      tambahTombol(
        root,
        "2. Tempel Otomatis Kode Kunci dari Papan Klip (Tanpa Ketik Manual) & Aktifkan Suara Gemini",
        "btn-green",
        async () => {
          let teksClip = "";
          if (window.AndroidBridge && typeof window.AndroidBridge.getClipboardText === "function") {
            try { teksClip = String(window.AndroidBridge.getClipboardText() || "").trim(); } catch (e) {}
          }
          if (!teksClip && navigator.clipboard && typeof navigator.clipboard.readText === "function") {
            try { teksClip = String(await navigator.clipboard.readText() || "").trim(); } catch (e2) {}
          }
          const inManual = document.getElementById("in-gemini-api-key");
          if (!teksClip && inManual && inManual.value) {
            teksClip = String(inManual.value).trim();
          }
          const matchKey = teksClip.match(/AIza[0-9A-Za-z\-_]{25,}/);
          const kunciBersih = matchKey ? matchKey[0] : teksClip;
          if (!kunciBersih || kunciBersih.length < 20) {
            window.bicaraGoogleTTSAsliStandar("Papan klip masih kosong atau belum berisi kode kunci Gemini yang diawali huruf A I z a. Silakan salin kode kunci dari Google AI Studio terlebih dahulu atau ketik di kolom bawah.");
            return;
          }
          cfg.geminiApiKey = kunciBersih;
          cfg.geminiTtsAktif = true;
          cfg.geminiAutoCache = true;
          simpanData();
          if (inManual) inManual.value = kunciBersih;
          window.bicaraGoogleTTSAsliStandar("Alhamdulillah, kode kunci Gemini berhasil ditempel otomatis dari papan klip dan disimpan di HP Anda. Sekarang Anda dapat menguji suara atau mengetuk tombol nomor tiga untuk mengunduh seluruh paket suara masjid ke memori offline.");
          bukaMenuSuaraGemini();
        },
        "btn-gemini-tempel-otomatis-clipboard"
      );

      // Kolom Input Manual (Cadangan jika pengguna ingin menempel manual lewat keyboard)
      const wrapInput = document.createElement("div");
      wrapInput.className = "form-group";
      wrapInput.style.marginTop = "8px";
      const lblIn = document.createElement("label");
      lblIn.setAttribute("for", "in-gemini-api-key");
      lblIn.textContent = "Kolom Kode Kunci (API Key) Gemini Anda (Tersimpan Aman Hanya di HP Ini):";
      const inputKey = document.createElement("input");
      inputKey.type = "text";
      inputKey.id = "in-gemini-api-key";
      inputKey.placeholder = "Tempel kode kunci AIzaSy... di sini";
      inputKey.value = (cfg && cfg.geminiApiKey) ? cfg.geminiApiKey : "";
      wrapInput.appendChild(lblIn);
      wrapInput.appendChild(inputKey);
      root.appendChild(wrapInput);

      tambahTombol(
        root,
        "Simpan Kode Kunci dari Kolom Ketik di Atas",
        "btn-teal",
        () => {
          const val = String((document.getElementById("in-gemini-api-key") && document.getElementById("in-gemini-api-key").value) || "").trim();
          if (!val || val.length < 15) {
            window.bicaraGoogleTTSAsliStandar("Kolom kode kunci masih kosong atau belum lengkap.");
            return;
          }
          cfg.geminiApiKey = val;
          cfg.geminiTtsAktif = true;
          simpanData();
          window.bicaraGoogleTTSAsliStandar("Alhamdulillah, kode kunci Gemini berhasil disimpan.");
          bukaMenuSuaraGemini();
        },
        "btn-gemini-simpan-manual"
      );

      tambahLabelBagian(root, "Langkah 3: Unduh Paket 16 Suara Masjid Offline (Metode 1) & Uji Suara");

      // TOMBOL 3: Unduh & Kunci Seluruh 16 Suara Pengumuman Masjid ke Memori Offline HP
      const btnUnduhPaket = document.createElement("button");
      btnUnduhPaket.type = "button";
      btnUnduhPaket.id = "btn-gemini-unduh-16-offline";
      btnUnduhPaket.className = "btn btn-amber";
      const teksTombolUnduh = `3. Unduh & Kunci Seluruh 16 Suara Pengumuman Masjid ke Memori Offline HP Sekarang (Tersimpan: ${jmlOffline} / 16 Suara)`;
      btnUnduhPaket.textContent = teksTombolUnduh;
      btnUnduhPaket.setAttribute("aria-label", teksTombolUnduh);
      btnUnduhPaket.addEventListener("click", () => {
        const apiKey = String((cfg && cfg.geminiApiKey) || "").trim();
        if (!apiKey || apiKey.length < 15) {
          window.bicaraGoogleTTSAsliStandar("Silakan tempelkan kode kunci Gemini Anda terlebih dahulu pada tombol nomor dua sebelum mengunduh paket suara offline.");
          return;
        }
        const daftar16 = dapatkanDaftar16PaketSuaraIntiMasjid();
        let idx = 0;
        let berhasilCount = 0;
        window.bicaraGoogleTTSAsliStandar("Memulai proses pengunduhan dan penguncian enam belas suara pengumuman masjid Gemini ke memori offline HP Anda. Mohon tunggu sebentar.");

        function prosesItemBerikutnya() {
          if (idx >= daftar16.length) {
            const totalAkhir = hitungJumlahPaketIntiTersimpan();
            btnUnduhPaket.textContent = `Alhamdulillah Selesai! (${totalAkhir} / 16 Suara Masjid Terkunci di Memori Offline HP)`;
            btnUnduhPaket.setAttribute("aria-label", btnUnduhPaket.textContent);
            bicaraGoogleTTS("Uji suara asisten masjid Gemini. Alhamdulillah, seluruh paket pengumuman masjid telah tersimpan di memori offline ponsel Anda dan siap berbunyi dua puluh empat jam tanpa internet.", false, () => {
              bukaMenuSuaraGemini();
            }, true);
            return;
          }
          const item = daftar16[idx++];
          btnUnduhPaket.textContent = `Mengunduh Suara Offline (${idx}/16): ${item.label}...`;
          btnUnduhPaket.setAttribute("aria-label", btnUnduhPaket.textContent);

          if (apakahFileGeminiSudahAdaOffline(item.file)) {
            berhasilCount++;
            setTimeout(prosesItemBerikutnya, 100);
            return;
          }

          mintaDanSimpanSuaraGemini(item.teks, item.file, function(sukses) {
            if (sukses) berhasilCount++;
            setTimeout(prosesItemBerikutnya, 350);
          });
        }

        prosesItemBerikutnya();
      });
      root.appendChild(btnUnduhPaket);

      // Tombol Uji Dengar Suara Asisten Gemini AI
      tambahTombol(
        root,
        `Uji Dengar Suara Asisten Gemini AI Sekarang (${infoVoice.pendek})`,
        "btn-green",
        () => {
          const teksUji = `Assalamu'alaikum warahmatullahi wabarakatuh. Uji suara asisten masjid Gemini pada aplikasi Nurul Masjid Pro. Lima belas menit lagi akan memasuki waktu sholat Dzuhur. Mari bersiap mengambil air wudhu dan merapatkan shaf di masjid.`;
          bicaraGoogleTTS(teksUji, false, null, true);
        },
        "btn-gemini-uji-suara-sekarang"
      );

      tambahLabelBagian(root, `Pilih Karakter Suara Asisten Gemini AI (Saat Ini: ${infoVoice.pendek})`);
      DAFTAR_KARAKTER_SUARA_GEMINI.forEach((op) => {
        const aktif = (infoVoice.id === op.id);
        tambahTombol(
          root,
          `${aktif ? "[ TERPILIH ] " : ""}${op.label}`,
          aktif ? "btn-green" : "btn-teal",
          () => {
            cfg.geminiVoiceName = op.id;
            cfg.geminiTtsAktif = true;
            // Bersihkan cache suara lama jika berganti karakter agar unduhan berikutnya memakai karakter suara baru
            if (window.AndroidBridge && typeof window.AndroidBridge.clearGeminiWavFiles === "function") {
              try { window.AndroidBridge.clearGeminiWavFiles(); } catch (e) {}
            }
            simpanData();
            window.bicaraGoogleTTSAsliStandar(`Karakter suara asisten Gemini diatur ke ${op.pendek}. Silakan ketuk Uji Dengar atau ketuk tombol nomor tiga untuk memperbarui paket suara offline dengan karakter baru.`);
            bukaMenuSuaraGemini();
          },
          `btn-gemini-pilih-suara-${op.id.toLowerCase()}`
        );
      });

      tambahLabelBagian(root, "Sakelar Pengaturan Metode 1 (Offline) & Metode 2 (Simpan Otomatis)");
      tambahSakelarAksesibel(
        root,
        "Gunakan Suara Asisten Gemini AI untuk Pengumuman Masjid (Marbot 15 Menit, Waktu Kehati-hatian, Imsak, Istiwa, Tahajud & Iqomah)",
        "geminiTtsAktif",
        "btn-sakelar-gemini-aktif"
      );
      tambahSakelarAksesibel(
        root,
        "Metode 2: Simpan Otomatis (Auto-Cache) Kalimat Pengumuman Baru ke Memori Offline Saat Ada Sinyal Internet",
        "geminiAutoCache",
        "btn-sakelar-gemini-autocache"
      );

      tambahTombol(
        root,
        "Hapus Kode Kunci & Kembalikan ke Suara Bawaan HP",
        "btn-red",
        () => {
          cfg.geminiApiKey = "";
          cfg.geminiTtsAktif = false;
          simpanData();
          window.bicaraGoogleTTSAsliStandar("Kode kunci Gemini telah dihapus dari aplikasi dan suara asisten dikembalikan ke suara standar bawaan HP.");
          bukaMenuSuaraGemini();
        },
        "btn-gemini-hapus-kunci"
      );

      tambahTombol(root, "Kembali ke Beranda Utama", "btn-gray", tampilkanMenuUtama, "btn-gemini-kembali-bawah");
    };

    // Tambahkan tombol pintas ke Beranda Utama, Menu Marbot Masjid, dan Menu Volume/Audio
    const _tampilkanMenuUtamaGemini = tampilkanMenuUtama;
    tampilkanMenuUtama = window.tampilkanMenuUtama = function() {
      _tampilkanMenuUtamaGemini();
      const root = document.getElementById("app-root");
      if (!root || document.getElementById("btn-utama-suara-gemini")) return;

      const infoVoice = dapatkanInfoSuaraGeminiAktif();
      const jmlOff = hitungJumlahPaketIntiTersimpan();
      const btnGem = document.createElement("button");
      btnGem.type = "button";
      btnGem.id = "btn-utama-suara-gemini";
      btnGem.className = "btn btn-purple";
      const teksBtnGem = `Inovasi Suara Asisten Gemini AI Offline & Auto-Cache (${infoVoice.pendek} • ${jmlOff}/16 Suara Offline)`;
      btnGem.textContent = teksBtnGem;
      btnGem.setAttribute("aria-label", teksBtnGem);
      btnGem.addEventListener("click", bukaMenuSuaraGemini);

      const btnMarbotUtama = document.getElementById("btn-utama-fitur-marbot-masjid");
      if (btnMarbotUtama && btnMarbotUtama.parentNode === root) {
        root.insertBefore(btnGem, btnMarbotUtama.nextSibling);
      } else {
        root.appendChild(btnGem);
      }
    };

    const _bukaMenuMarbotGemini = bukaMenuMarbotMasjid;
    bukaMenuMarbotMasjid = window.bukaMenuMarbotMasjid = function() {
      _bukaMenuMarbotGemini();
      const root = document.getElementById("app-root");
      if (!root || document.getElementById("btn-marbot-ke-suara-gemini")) return;
      const infoVoice = dapatkanInfoSuaraGeminiAktif();
      const btnKeGem = document.createElement("button");
      btnKeGem.type = "button";
      btnKeGem.id = "btn-marbot-ke-suara-gemini";
      btnKeGem.className = "btn btn-blue";
      const teksKeGem = `Atur Suara Asisten Gemini AI Offline & Ambil/Tempel Kode Kunci (${infoVoice.pendek})`;
      btnKeGem.textContent = teksKeGem;
      btnKeGem.setAttribute("aria-label", teksKeGem);
      btnKeGem.addEventListener("click", bukaMenuSuaraGemini);

      const btnJalur = document.getElementById("btn-marbot-pilih-jalur-audio");
      if (btnJalur && btnJalur.parentNode === root) {
        root.insertBefore(btnKeGem, btnJalur.nextSibling);
      } else {
        root.appendChild(btnKeGem);
      }
    };

    const _menuAudioMediaGemini = menuPengaturanAudioMedia;
    menuPengaturanAudioMedia = window.menuPengaturanAudioMedia = function() {
      _menuAudioMediaGemini();
      const root = document.getElementById("app-root");
      if (!root || document.getElementById("btn-audiomedia-ke-gemini")) return;
      const infoVoice = dapatkanInfoSuaraGeminiAktif();
      tambahLabelBagian(root, "7. Inovasi Suara Asisten Gemini AI (Offline & Simpan Otomatis)");
      tambahTombol(
        root,
        `Buka Pengaturan Suara Asisten Gemini AI (Ambil Kode Kunci, Tempel Otomatis & Unduh 16 Suara Offline — ${infoVoice.pendek})`,
        "btn-purple",
        bukaMenuSuaraGemini,
        "btn-audiomedia-ke-gemini"
      );
    };

    if (typeof cfg === "object" && cfg !== null) {
      if (typeof cfg.geminiTtsAktif === "undefined") cfg.geminiTtsAktif = true;
      if (typeof cfg.geminiAutoCache === "undefined") cfg.geminiAutoCache = true;
      if (!cfg.geminiVoiceName) cfg.geminiVoiceName = "Orus";
      if (typeof cfg.geminiApiKey === "undefined") cfg.geminiApiKey = "";
    }

    if (typeof halamanAktif === "undefined" || halamanAktif === "beranda") {
      tampilkanMenuUtama();
    }
  } catch (eGemMod) {}
})();
